package model

// APIResponse adalah envelope standar untuk semua response API (AC-03)
type APIResponse[T any] struct {
	Status  int         `json:"status"`
	Success bool        `json:"success"`
	Data    T           `json:"data,omitempty"`
	Errors  []ErrorItem `json:"errors"`
	Detail  string      `json:"detail,omitempty"`
	Title   string      `json:"title,omitempty"`
}

// ErrorItem merepresentasikan satu error dalam response
type ErrorItem struct {
	Location string `json:"location,omitempty"`
	Message  string `json:"message"`
	Value    any    `json:"value,omitempty"`
}

// PaginationMeta untuk metadata pagination (TSD 7.2)
type PaginationMeta struct {
	CurrentPage int `json:"current_page"`
	PerPage     int `json:"per_page"`
	Total       int `json:"total"`
	LastPage    int `json:"last_page"`
}

// NewSuccessResponse helper untuk membuat success response
func NewSuccessResponse[T any](status int, title string, detail string, data T) APIResponse[T] {
	return APIResponse[T]{
		Status:  status,
		Success: true,
		Data:    data,
		Errors:  []ErrorItem{},
		Detail:  detail,
		Title:   title,
	}
}

// NewErrorResponse helper untuk membuat error response
func NewErrorResponse[T any](status int, title string, detail string, errors []ErrorItem) APIResponse[T] {
	if errors == nil {
		errors = []ErrorItem{}
	}
	var zero T
	return APIResponse[T]{
		Status:  status,
		Success: false,
		Data:    zero,
		Errors:  errors,
		Detail:  detail,
		Title:   title,
	}
}

// PaginatedResponse wrapper untuk response dengan pagination
type PaginatedResponse[T any] struct {
	Meta PaginationMeta `json:"meta"`
	Data T              `json:"data"`
}

// NewPaginatedResponse helper untuk membuat paginated response
func NewPaginatedResponse[T any](data T, currentPage, perPage, total int) PaginatedResponse[T] {
	lastPage := total / perPage
	if total%perPage != 0 {
		lastPage++
	}
	if lastPage == 0 {
		lastPage = 1
	}

	return PaginatedResponse[T]{
		Meta: PaginationMeta{
			CurrentPage: currentPage,
			PerPage:     perPage,
			Total:       total,
			LastPage:    lastPage,
		},
		Data: data,
	}
}

// Error codes constants (dari TSD Error Dictionary)
const (
	ErrAuthUnauthorized     = "ERR-AUTH-01"
	ErrAuthForbidden        = "ERR-AUTH-03"
	ErrDataNotFound         = "ERR-DATA-01"
	ErrValidationRequired   = "ERR-VAL-03"
	ErrValidationOutOfBound = "ERR-VAL-05"
	ErrValidationReference  = "ERR-VAL-06"
	ErrValidationEnum       = "ERR-VAL-07"
	ErrSystem               = "ERR-SYS-01"
)

// Standard error messages
var ErrorMessages = map[string]string{
	ErrAuthUnauthorized:     "Anda harus login untuk mengakses halaman ini.",
	ErrAuthForbidden:        "Anda tidak memiliki izin untuk mengakses ini.",
	ErrDataNotFound:         "Data tidak ditemukan.",
	ErrValidationRequired:   "Field wajib diisi atau nilai tidak valid.",
	ErrValidationOutOfBound: "Nilai di luar batas yang diperbolehkan.",
	ErrValidationReference:  "Data referensi tidak ditemukan.",
	ErrValidationEnum:       "Nilai ENUM tidak valid.",
	ErrSystem:               "Terjadi kesalahan sistem. Mohon coba kembali.",
}