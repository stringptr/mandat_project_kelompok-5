package handler

import (
	"context"
	"net/http"
	"strings"

	"github.com/danielgtaylor/huma/v2"
	"myproject/internal/model"
	"myproject/internal/service"
)

// ArtikelHandler struct untuk mengelola handler artikel
type ArtikelHandler struct {
	service service.ArtikelService
}

// NewArtikelHandler membuat instance handler
func NewArtikelHandler(service service.ArtikelService) *ArtikelHandler {
	return &ArtikelHandler{service: service}
}

// RegisterRoutes mendaftarkan semua route artikel ke Huma
func (h *ArtikelHandler) RegisterRoutes(api huma.API) {
	// GET /api/v1/artikel - Public list (semua role terautentikasi)
	huma.Register(api, huma.Operation{
		OperationID: "get-artikel-list",
		Method:      "GET",
		Path:        "/api/v1/artikel",
		Summary:     "Mendapatkan daftar artikel yang dipublikasikan",
		Tags:        []string{"Artikel"},
		Security: []map[string][]string{
			{"bearerAuth": {}},
		},
	}, h.GetArtikelList)
	
	// GET /api/v1/artikel/{id} - Detail artikel (semua role terautentikasi)
	huma.Register(api, huma.Operation{
		OperationID: "get-artikel-detail",
		Method:      "GET",
		Path:        "/api/v1/artikel/{id}",
		Summary:     "Mendapatkan detail artikel",
		Tags:        []string{"Artikel"},
		Security: []map[string][]string{
			{"bearerAuth": {}},
		},
	}, h.GetArtikelDetail)
	
	// POST /api/v1/artikel - Create artikel (Bidan only)
	huma.Register(api, huma.Operation{
		OperationID: "create-artikel",
		Method:      "POST",
		Path:        "/api/v1/artikel",
		Summary:     "Membuat artikel baru (Bidan)",
		Tags:        []string{"Artikel"},
		Security: []map[string][]string{
			{"bearerAuth": {}},
		},
	}, h.CreateArtikel)
	
	// PATCH /api/v1/artikel/{id} - Update artikel (Bidan only, own article)
	huma.Register(api, huma.Operation{
		OperationID: "update-artikel",
		Method:      "PATCH",
		Path:        "/api/v1/artikel/{id}",
		Summary:     "Memperbarui artikel Draft (Bidan)",
		Tags:        []string{"Artikel"},
		Security: []map[string][]string{
			{"bearerAuth": {}},
		},
	}, h.UpdateArtikel)
	
	// DELETE /api/v1/artikel/{id} - Delete artikel (Dinkes only)
	huma.Register(api, huma.Operation{
		OperationID: "delete-artikel",
		Method:      "DELETE",
		Path:        "/api/v1/artikel/{id}",
		Summary:     "Menghapus artikel (Dinas Kesehatan)",
		Tags:        []string{"Artikel"},
		Security: []map[string][]string{
			{"bearerAuth": {}},
		},
	}, h.DeleteArtikel)
	
	// PATCH /api/v1/artikel/{id}/review - Review artikel (Dinkes only)
	huma.Register(api, huma.Operation{
		OperationID: "review-artikel",
		Method:      "PATCH",
		Path:        "/api/v1/artikel/{id}/review",
		Summary:     "Review dan setujui/tolak artikel (Dinas Kesehatan)",
		Tags:        []string{"Artikel"},
		Security: []map[string][]string{
			{"bearerAuth": {}},
		},
	}, h.ReviewArtikel)
	
	// GET /api/v1/artikel/pending - Pending list (Dinkes only)
	huma.Register(api, huma.Operation{
		OperationID: "get-artikel-pending",
		Method:      "GET",
		Path:        "/api/v1/artikel/pending",
		Summary:     "Mendapatkan artikel menunggu review (Dinas Kesehatan)",
		Tags:        []string{"Artikel"},
		Security: []map[string][]string{
			{"bearerAuth": {}},
		},
	}, h.GetArtikelPending)
}

// GetArtikelList handler untuk GET /api/v1/artikel
func (h *ArtikelHandler) GetArtikelList(ctx context.Context, input *struct {
	model.ArtikelListRequest
}) (*model.APIResponse[model.PaginatedResponse[[]model.ArtikelItem]], error) {
	// Extract JWT dari context (disuntikkan oleh middleware)
	idUser := getIDUserFromContext(ctx)
	if idUser == 0 {
		resp := model.NewErrorResponse[model.PaginatedResponse[[]model.ArtikelItem]](http.StatusUnauthorized, "Unauthorized", 
			model.ErrorMessages[model.ErrAuthUnauthorized], 
			[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}})
		return &resp, nil
	}
	
	// Service call
	articles, total, err := h.service.GetArtikelList(ctx, input.Page, input.PerPage, input.Kategori, input.Q)
	if err != nil {
		return handleServiceError[model.PaginatedResponse[[]model.ArtikelItem]](err), nil
	}
	
	// Map ke response
	summaries := make([]model.ArtikelItem, len(articles))
	for i, art := range articles {
		kategori := ""
		if art.Kategori != nil {
			kategori = *art.Kategori
		}
		
		summaries[i] = model.ArtikelItem{
			IDArtikel:      int(art.IDArtikel),
			Judul:          art.Judul,
			Kategori:       &kategori,
			Ringkasan:      art.Ringkasan,
			NamaPenulis:    art.NamaPenulis,
			TanggalPublish: art.TanggalPublish,
		}
	}
	
	// Build paginated response
	paginatedData := model.NewPaginatedResponse(summaries, input.Page, input.PerPage, total)
	resp := model.NewSuccessResponse(http.StatusOK, "OK", 
		"Daftar artikel berhasil diambil.", paginatedData)
	
	return &resp, nil
}

// GetArtikelDetail handler untuk GET /api/v1/artikel/{id}
func (h *ArtikelHandler) GetArtikelDetail(ctx context.Context, input *struct {
	ID int `path:"id"`
}) (*model.APIResponse[model.ArtikelDetailResponse], error) {
	// Validasi autentikasi
	idUser := getIDUserFromContext(ctx)
	if idUser == 0 {
		resp := model.NewErrorResponse[model.ArtikelDetailResponse](http.StatusUnauthorized, "Unauthorized", 
			model.ErrorMessages[model.ErrAuthUnauthorized], 
			[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}})
		return &resp, nil
	}
	
	// Service call
	artikel, err := h.service.GetArtikelByID(ctx, input.ID)
	if err != nil {
		return handleServiceError[model.ArtikelDetailResponse](err), nil
	}
	
	// Map ke response
	kategori := ""
	if artikel.Kategori != nil {
		kategori = *artikel.Kategori
	}
	
	namaVerifikator := ""
	if artikel.NamaVerifikator != nil {
		namaVerifikator = *artikel.NamaVerifikator
	}
	
	tanggalPublish := ""
	if artikel.TanggalPublish != nil {
		tanggalPublish = *artikel.TanggalPublish
	}
	
	response := model.ArtikelDetailResponse{
		IDArtikel:       int(artikel.IDArtikel),
		Judul:           artikel.Judul,
		IsiArtikel:      artikel.IsiArtikel,
		Kategori:        &kategori,
		NamaPenulis:     artikel.NamaPenulis,
		NamaVerifikator: &namaVerifikator,
		TanggalPublish:  &tanggalPublish,
		CreatedAt:       artikel.CreatedAt.Time,
		UpdatedAt:       artikel.UpdatedAt.Time,
	}
	
	resp := model.NewSuccessResponse(http.StatusOK, "OK", 
		"Detail artikel berhasil diambil.", response)
	return &resp, nil
}

// CreateArtikel handler untuk POST /api/v1/artikel
func (h *ArtikelHandler) CreateArtikel(ctx context.Context, input *struct {
	Body model.CreateArtikelBody
}) (*model.APIResponse[model.CreateArtikelResponse], error) {
	// Validasi autentikasi
	idUser := getIDUserFromContext(ctx)
	if idUser == 0 {
		resp := model.NewErrorResponse[model.CreateArtikelResponse](http.StatusUnauthorized, "Unauthorized", 
			model.ErrorMessages[model.ErrAuthUnauthorized], 
			[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}})
		return &resp, nil
	}
	
	// Validasi role: hanya Bidan
	role := getRoleFromContext(ctx)
	if role != "BIDAN" {
		resp := model.NewErrorResponse[model.CreateArtikelResponse](http.StatusForbidden, "Forbidden", 
			model.ErrorMessages[model.ErrAuthForbidden], 
			[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthForbidden]}})
		return &resp, nil
	}
	
	// Service call
	idArtikel, err := h.service.CreateArtikel(ctx, idUser, input.Body.Judul, input.Body.IsiArtikel, input.Body.Kategori)
	if err != nil {
		return handleServiceError[model.CreateArtikelResponse](err), nil
	}
	
	response := model.CreateArtikelResponse{
		IDArtikel:     idArtikel,
		StatusArtikel: "Draft",
		Detail:        "Artikel berhasil diajukan dan menunggu review Dinas Kesehatan.",
	}
	
	resp := model.NewSuccessResponse(http.StatusCreated, "Created", 
		"Artikel berhasil dibuat.", response)
	return &resp, nil
}

// UpdateArtikel handler untuk PATCH /api/v1/artikel/{id}
func (h *ArtikelHandler) UpdateArtikel(ctx context.Context, input *struct {
	ID   int `path:"id"`
	Body model.UpdateArtikelBody
}) (*model.APIResponse[model.UpdateArtikelResponse], error) {
	// Validasi autentikasi
	idUser := getIDUserFromContext(ctx)
	if idUser == 0 {
		resp := model.NewErrorResponse[model.UpdateArtikelResponse](http.StatusUnauthorized, "Unauthorized", 
			model.ErrorMessages[model.ErrAuthUnauthorized], 
			[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}})
		return &resp, nil
	}
	
	// Validasi role: hanya Bidan
	role := getRoleFromContext(ctx)
	if role != "BIDAN" {
		resp := model.NewErrorResponse[model.UpdateArtikelResponse](http.StatusForbidden, "Forbidden", 
			model.ErrorMessages[model.ErrAuthForbidden], 
			[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthForbidden]}})
		return &resp, nil
	}
	
	// Service call
	err := h.service.UpdateArtikel(ctx, input.ID, idUser, input.Body.Judul, input.Body.IsiArtikel, input.Body.Kategori)
	if err != nil {
		return handleServiceError[model.UpdateArtikelResponse](err), nil
	}
	
	response := model.UpdateArtikelResponse{
		IDArtikel:     input.ID,
		StatusArtikel: "Draft",
	}
	
	resp := model.NewSuccessResponse(http.StatusOK, "OK", 
		"Artikel berhasil diperbarui.", response)
	return &resp, nil
}

// DeleteArtikel handler untuk DELETE /api/v1/artikel/{id}
func (h *ArtikelHandler) DeleteArtikel(ctx context.Context, input *struct {
	ID int `path:"id"`
}) (*model.APIResponse[any], error) {
	// Validasi autentikasi
	idUser := getIDUserFromContext(ctx)
	if idUser == 0 {
		resp := model.NewErrorResponse[any](http.StatusUnauthorized, "Unauthorized", 
			model.ErrorMessages[model.ErrAuthUnauthorized], 
			[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}})
		return &resp, nil
	}
	
	// Validasi role: hanya Dinas Kesehatan
	role := getRoleFromContext(ctx)
	if role != "DINKES" {
		resp := model.NewErrorResponse[any](http.StatusForbidden, "Forbidden", 
			model.ErrorMessages[model.ErrAuthForbidden], 
			[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthForbidden]}})
		return &resp, nil
	}
	
	// Service call
	err := h.service.DeleteArtikel(ctx, input.ID)
	if err != nil {
		return handleServiceError[any](err), nil
	}
	
	resp := model.NewSuccessResponse[any](http.StatusOK, "OK", 
		"Artikel berhasil dihapus.", nil)
	return &resp, nil
}

// ReviewArtikel handler untuk PATCH /api/v1/artikel/{id}/review
func (h *ArtikelHandler) ReviewArtikel(ctx context.Context, input *struct {
	ID   int `path:"id"`
	Body model.ReviewArtikelBody
}) (*model.APIResponse[model.ReviewArtikelResponse], error) {
	// Validasi autentikasi
	idUser := getIDUserFromContext(ctx)
	if idUser == 0 {
		resp := model.NewErrorResponse[model.ReviewArtikelResponse](http.StatusUnauthorized, "Unauthorized", 
			model.ErrorMessages[model.ErrAuthUnauthorized], 
			[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}})
		return &resp, nil
	}
	
	// Validasi role: hanya Dinas Kesehatan
	role := getRoleFromContext(ctx)
	if role != "DINKES" {
		resp := model.NewErrorResponse[model.ReviewArtikelResponse](http.StatusForbidden, "Forbidden", 
			model.ErrorMessages[model.ErrAuthForbidden], 
			[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthForbidden]}})
		return &resp, nil
	}
	
	// Validasi aksi
	if input.Body.Aksi != "setujui" && input.Body.Aksi != "tolak" {
		resp := model.NewErrorResponse[model.ReviewArtikelResponse](http.StatusUnprocessableEntity, "Unprocessable Content", 
			"Terdapat kesalahan pada pengisian data.", 
			[]model.ErrorItem{
				{
					Location: "body.aksi",
					Message:  model.ErrorMessages[model.ErrValidationEnum],
					Value:    input.Body.Aksi,
				},
			})
		return &resp, nil
	}
	
	// Validasi: jika tolak, catatan_review wajib diisi
	if input.Body.Aksi == "tolak" && (input.Body.CatatanReview == nil || *input.Body.CatatanReview == "") {
		resp := model.NewErrorResponse[model.ReviewArtikelResponse](http.StatusUnprocessableEntity, "Unprocessable Content", 
			"Terdapat kesalahan pada pengisian data.", 
			[]model.ErrorItem{
				{
					Location: "body.catatan_review",
					Message:  "Catatan review wajib diisi jika artikel ditolak.",
					Value:    "",
				},
			})
		return &resp, nil
	}
	
	// Service call
	catatanReview := ""
	if input.Body.CatatanReview != nil {
		catatanReview = *input.Body.CatatanReview
	}
	
	err := h.service.ReviewArtikel(ctx, input.ID, idUser, input.Body.Aksi, catatanReview)
	if err != nil {
		return handleServiceError[model.ReviewArtikelResponse](err), nil
	}
	
	// Response berbeda untuk setujui vs tolak
	statusArtikel := "Dipublikasikan"
	var tanggalPublish *string = nil
	
	if input.Body.Aksi == "setujui" {
		// Tanggal publish diset oleh SP dengan CURRENT_DATE
		tanggalPublishVal := "2026-06-10" // Placeholder: idealnya dari DB response
		tanggalPublish = &tanggalPublishVal
	} else {
		statusArtikel = "Ditolak"
	}
	
	response := model.ReviewArtikelResponse{
		IDArtikel:      input.ID,
		StatusArtikel:  statusArtikel,
		TanggalPublish: tanggalPublish,
	}
	
	detail := "Artikel berhasil disetujui dan dipublikasikan."
	if input.Body.Aksi == "tolak" {
		detail = "Artikel ditolak."
	}
	
	resp := model.NewSuccessResponse(http.StatusOK, "OK", detail, response)
	return &resp, nil
}

// GetArtikelPending handler untuk GET /api/v1/artikel/pending
func (h *ArtikelHandler) GetArtikelPending(ctx context.Context, input *struct {
	Page    int `query:"page" default:"1"`
	PerPage int `query:"per_page" default:"15"`
}) (*model.APIResponse[model.PaginatedResponse[[]model.ArtikelPendingItem]], error) {
	// Validasi autentikasi & role
	idUser := getIDUserFromContext(ctx)
	if idUser == 0 {
		resp := model.NewErrorResponse[model.PaginatedResponse[[]model.ArtikelPendingItem]](http.StatusUnauthorized, "Unauthorized",
			model.ErrorMessages[model.ErrAuthUnauthorized],
			[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}})
		return &resp, nil
	}
	
	// Validasi role: hanya Dinas Kesehatan
	role := getRoleFromContext(ctx)
	if role != "DINKES" {
		resp := model.NewErrorResponse[model.PaginatedResponse[[]model.ArtikelPendingItem]](http.StatusForbidden, "Forbidden",
			model.ErrorMessages[model.ErrAuthForbidden],
			[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthForbidden]}})
		return &resp, nil
	}
	
	// Service call
	articles, total, err := h.service.GetArtikelPending(ctx, input.Page, input.PerPage)
	if err != nil {
		return handleServiceError[model.PaginatedResponse[[]model.ArtikelPendingItem]](err), nil
	}
	
	// Map ke response
	summaries := make([]model.ArtikelPendingItem, len(articles))
	for i, art := range articles {
		summaries[i] = model.ArtikelPendingItem{
			IDArtikel:     int(art.IDArtikel),
			Judul:         art.Judul,
			NamaPenulis:   art.NamaPenulis,
			CreatedAt:     art.CreatedAt.Time,
			StatusArtikel: art.StatusArtikel,
		}
	}
	
	// Build paginated response
	paginatedData := model.NewPaginatedResponse(summaries, input.Page, input.PerPage, total)
	resp := model.NewSuccessResponse(http.StatusOK, "OK",
		"Daftar artikel menunggu review berhasil diambil.", paginatedData)
	
	return &resp, nil
}

// handleServiceError mapping error dari service ke response (generic)
func handleServiceError[T any](err error) *model.APIResponse[T] {
	errMsg := err.Error()

	if strings.HasPrefix(errMsg, "ERR-AUTH-01") {
		resp := model.NewErrorResponse[T](http.StatusUnauthorized, "Unauthorized",
			model.ErrorMessages[model.ErrAuthUnauthorized],
			[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}})
		return &resp
	}

	if strings.HasPrefix(errMsg, "ERR-AUTH-03") {
		resp := model.NewErrorResponse[T](http.StatusForbidden, "Forbidden",
			model.ErrorMessages[model.ErrAuthForbidden],
			[]model.ErrorItem{{Message: strings.TrimPrefix(errMsg, "ERR-AUTH-03: ")}})
		return &resp
	}

	if strings.HasPrefix(errMsg, "ERR-DATA-02") {
		resp := model.NewErrorResponse[T](http.StatusNotFound, "Not Found",
			strings.TrimPrefix(errMsg, "ERR-DATA-02: "),
			[]model.ErrorItem{{Message: "Resource not found"}})
		return &resp
	}

	if strings.HasPrefix(errMsg, "ERR-VAL-03") {
		resp := model.NewErrorResponse[T](http.StatusUnprocessableEntity, "Unprocessable Content",
			"Terdapat kesalahan pada pengisian berkas. Mohon dicek ulang.",
			[]model.ErrorItem{{Message: strings.TrimPrefix(errMsg, "ERR-VAL-03: ")}})
		return &resp
	}

	// Default: internal server error
	resp := model.NewErrorResponse[T](http.StatusInternalServerError, "Internal Server Error",
		"Terjadi kesalahan. Mohon dicoba kembali.",
		[]model.ErrorItem{{Message: "Internal server error"}})
	return &resp
}