package repository

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	"github.com/go-jet/jet/v2/postgres"
	"github.com/jackc/pgx/v5/pgxpool"
    "github.com/jackc/pgx/v5/stdlib"
	"myproject/internal/infrastructure/jet/imunisasi/public/model"
	"myproject/internal/infrastructure/jet/imunisasi/public/table"
)

// ArtikelRepository interface untuk operasi database artikel
type ArtikelRepository interface {
	// GetArtikelList mendapatkan list artikel yang dipublikasikan dengan pagination
	GetArtikelList(ctx context.Context, page, perPage int, kategori, search string) ([]ArtikelView, int, error)
	
	// GetArtikelByID mendapatkan detail artikel berdasarkan ID
	GetArtikelByID(ctx context.Context, id int) (*ArtikelDetailView, error)
	
	// CreateArtikel membuat artikel baru dengan status Draft
	CreateArtikel(ctx context.Context, artikel *model.Artikel) (int, error)
	
	// UpdateArtikel update artikel (hanya jika status Draft)
	UpdateArtikel(ctx context.Context, id int, judul, isiArtikel, kategori *string) error
	
	// DeleteArtikel hapus artikel permanen
	DeleteArtikel(ctx context.Context, id int) error
	
	// ReviewArtikel panggil SP untuk approve/reject artikel
	ReviewArtikel(ctx context.Context, idArtikel, idVerifikator int, aksi, catatanReview string) (string, error)
	
	// GetArtikelPending mendapatkan list artikel menunggu review
	GetArtikelPending(ctx context.Context, page, perPage int) ([]ArtikelPendingView, int, error)
	
	// GetArtikelForUpdate mendapatkan artikel untuk validasi update (cek status & owner)
	GetArtikelForUpdate(ctx context.Context, id, idPenulis int) (*model.Artikel, error)
}

// ArtikelView representasi view v_artikel_publik
type ArtikelView struct {
	IDArtikel      int32
	Judul          string
	Kategori       *string
	Ringkasan      string
	NamaPenulis    string
	TanggalPublish *string
	StatusArtikel  string
}

// ArtikelDetailView representasi view v_artikel_detail
type ArtikelDetailView struct {
	IDArtikel       int32
	Judul           string
	IsiArtikel      string
	Kategori        *string
	NamaPenulis     string
	NamaVerifikator *string
	TanggalPublish  *string
	CreatedAt       sql.NullTime
	UpdatedAt       sql.NullTime
}

// ArtikelPendingView representasi artikel pending
type ArtikelPendingView struct {
	IDArtikel     int32
	Judul         string
	NamaPenulis   string
	CreatedAt     sql.NullTime
	StatusArtikel string
}

type artikelRepository struct {
	pool *pgxpool.Pool
	db *sql.DB
}

// NewArtikelRepository membuat instance repository
func NewArtikelRepository(pool *pgxpool.Pool) ArtikelRepository {
    db := stdlib.OpenDBFromPool(pool)
    return &artikelRepository{
        pool: pool,
        db:   db,
	}
}

// GetArtikelList implementasi dengan Jet
func (r *artikelRepository) GetArtikelList(ctx context.Context, page, perPage int, kategori, search string) ([]ArtikelView, int, error) {
	offset := (page - 1) * perPage
	
	// Base query dari view v_artikel_publik (via JOIN manual karena view belum ter-generate)
	// Query SELECT dengan filter status Dipublikasikan
	stmt := postgres.SELECT(
		table.Artikel.IDArtikel,
		table.Artikel.Judul,
		table.Artikel.Kategori,
		postgres.RawString("LEFT(artikel.isi_artikel, 200)").AS("ringkasan"),
		table.UserAccount.AllColumns.As("penulis"),
		table.Artikel.TanggalPublish,
		table.Artikel.StatusArtikel,
	).FROM(
		table.Artikel.
			INNER_JOIN(table.UserAccount, table.UserAccount.IDUser.EQ(table.Artikel.IDPenulis)),
	).WHERE(
		table.Artikel.StatusArtikel.EQ(postgres.String("Dipublikasikan")),
	)
	
	// Filter kategori jika ada
	if kategori != "" {
		stmt = stmt.WHERE(table.Artikel.Kategori.EQ(postgres.String(kategori)))
	}
	
	// Filter search di judul atau isi artikel
	if search != "" {
		searchPattern := "%" + search + "%"
		stmt = stmt.WHERE(
			postgres.OR(
				table.Artikel.Judul.LIKE(postgres.String(searchPattern)),
				table.Artikel.IsiArtikel.LIKE(postgres.String(searchPattern)),
			),
		)
	}
	
	// Count total untuk pagination
	var total int64
	countStmt := stmt
	err := countStmt.Query(r.db, &total)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to count artikel: %w", err)
	}
	
	// Apply pagination
	stmt = stmt.
		ORDER_BY(table.Artikel.TanggalPublish.DESC()).
		LIMIT(int64(perPage)).
		OFFSET(int64(offset))
	
	var results []struct {
		model.Artikel
		Penulis   model.UserAccount
		Ringkasan string
	}
	
	err = stmt.Query(r.db, &results)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to query artikel list: %w", err)
	}
	
	// Map ke ArtikelView
	views := make([]ArtikelView, len(results))
	for i, res := range results {
		tanggalPublish := ""
		if res.TanggalPublish != nil {
			tanggalPublish = res.TanggalPublish.Format("2006-01-02")
		}
		
		statusArtikel := ""
		if res.StatusArtikel != nil {
			statusArtikel = *res.StatusArtikel
		}
		
		views[i] = ArtikelView{
			IDArtikel:      res.IDArtikel,
			Judul:          res.Judul,
			Kategori:       res.Kategori,
			Ringkasan:      res.Ringkasan,
			NamaPenulis:    res.Penulis.Nama,
			TanggalPublish: &tanggalPublish,
			StatusArtikel:  statusArtikel,
		}
	}
	
	return views, int(total), nil
}

// GetArtikelByID implementasi dengan Jet
func (r *artikelRepository) GetArtikelByID(ctx context.Context, id int) (*ArtikelDetailView, error) {
	// Create alias for verifikator table
	verifikator := table.UserAccount.AS("verifikator")
	
	// Query dari v_artikel_detail (simulasi dengan JOIN)
	stmt := postgres.SELECT(
		table.Artikel.IDArtikel,
		table.Artikel.Judul,
		table.Artikel.IsiArtikel,
		table.Artikel.Kategori,
		table.UserAccount.AllColumns.As("penulis"),
		verifikator.Nama.AS("nama_verifikator"),
		table.Artikel.TanggalPublish,
		table.Artikel.CreatedAt,
		table.Artikel.UpdatedAt,
	).FROM(
		table.Artikel.
			INNER_JOIN(table.UserAccount, table.UserAccount.IDUser.EQ(table.Artikel.IDPenulis)).
			LEFT_JOIN(verifikator, verifikator.IDUser.EQ(table.Artikel.IDVerifikator)),
	).WHERE(
		table.Artikel.IDArtikel.EQ(postgres.Int32(int32(id))),
	)
	
	var result struct {
		model.Artikel
		Penulis         model.UserAccount
		NamaVerifikator *string
	}
	
	err := stmt.Query(r.db, &result)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil // Not found
		}
		return nil, fmt.Errorf("failed to query artikel detail: %w", err)
	}
	
	tanggalPublish := ""
	if result.TanggalPublish != nil {
		tanggalPublish = result.TanggalPublish.Format("2006-01-02")
	}
	
	return &ArtikelDetailView{
		IDArtikel:       result.IDArtikel,
		Judul:           result.Judul,
		IsiArtikel:      result.IsiArtikel,
		Kategori:        result.Kategori,
		NamaPenulis:     result.Penulis.Nama,
		NamaVerifikator: result.NamaVerifikator,
		TanggalPublish:  &tanggalPublish,
		CreatedAt:       sql.NullTime{Time: result.CreatedAt, Valid: true},
		UpdatedAt:       sql.NullTime{Time: result.UpdatedAt, Valid: true},
	}, nil
}

// CreateArtikel implementasi dengan Jet
func (r *artikelRepository) CreateArtikel(ctx context.Context, artikel *model.Artikel) (int, error) {
	stmt := table.Artikel.
		INSERT(
			table.Artikel.Judul,
			table.Artikel.IsiArtikel,
			table.Artikel.Kategori,
			table.Artikel.StatusArtikel,
			table.Artikel.IDPenulis,
		).
		VALUES(
			artikel.Judul,
			artikel.IsiArtikel,
			artikel.Kategori,
			"Draft", // Status default (AC)
			artikel.IDPenulis,
		).
		RETURNING(table.Artikel.IDArtikel)
	
	var id int32
	err := stmt.Query(r.db, &id)
	if err != nil {
		return 0, fmt.Errorf("failed to create artikel: %w", err)
	}
	
	return int(id), nil
}

// UpdateArtikel implementasi dengan Jet
func (r *artikelRepository) UpdateArtikel(ctx context.Context, id int, judul, isiArtikel, kategori *string) error {
	// Build dynamic update
	updateMap := make(map[postgres.Column]interface{})
	
	if judul != nil {
		updateMap[table.Artikel.Judul] = *judul
	}
	if isiArtikel != nil {
		updateMap[table.Artikel.IsiArtikel] = *isiArtikel
	}
	if kategori != nil {
		updateMap[table.Artikel.Kategori] = *kategori
	}
	
	// Selalu update timestamp
	updateMap[table.Artikel.UpdatedAt] = postgres.NOW()
	
	if len(updateMap) == 1 { // Hanya updated_at
		return nil // Tidak ada yang diupdate
	}
	
	stmt := table.Artikel.
		UPDATE().
		SET(updateMap).
		WHERE(table.Artikel.IDArtikel.EQ(postgres.Int32(int32(id))))
	
	result, err := stmt.Exec(r.db)
	if err != nil {
		return fmt.Errorf("failed to update artikel: %w", err)
	}
	
	rows, _ := result.RowsAffected()
	if rows == 0 {
		return fmt.Errorf("artikel not found")
	}
	
	return nil
}

// DeleteArtikel implementasi dengan Jet
func (r *artikelRepository) DeleteArtikel(ctx context.Context, id int) error {
	stmt := table.Artikel.
		DELETE().
		WHERE(table.Artikel.IDArtikel.EQ(postgres.Int32(int32(id))))
	
	result, err := stmt.Exec(r.db)
	if err != nil {
		return fmt.Errorf("failed to delete artikel: %w", err)
	}
	
	rows, _ := result.RowsAffected()
	if rows == 0 {
		return fmt.Errorf("artikel not found")
	}
	
	return nil
}

// ReviewArtikel implementasi SP call menggunakan raw pgx (Jet tidak support SP)
func (r *artikelRepository) ReviewArtikel(ctx context.Context, idArtikel, idVerifikator int, aksi, catatanReview string) (string, error) {
    var result string
    query := `CALL sp_review_artikel($1, $2, $3, $4, $5)`

    _, err := r.pool.Exec(ctx, query, idArtikel, idVerifikator, aksi, catatanReview, &result)
    if err != nil {
        if strings.Contains(err.Error(), "ARTIKEL_NOT_FOUND") {
            return "ARTIKEL_NOT_FOUND", nil
        }
        if strings.Contains(err.Error(), "INVALID_STATUS") {
            return "INVALID_STATUS", nil
        }
        return "", fmt.Errorf("failed to call sp_review_artikel: %w", err)
    }

    return result, nil
}

// GetArtikelPending implementasi dengan Jet
func (r *artikelRepository) GetArtikelPending(ctx context.Context, page, perPage int) ([]ArtikelPendingView, int, error) {
	offset := (page - 1) * perPage
	
	stmt := postgres.SELECT(
		table.Artikel.IDArtikel,
		table.Artikel.Judul,
		table.UserAccount.Nama.AS("nama_penulis"),
		table.Artikel.CreatedAt,
		table.Artikel.StatusArtikel,
	).FROM(
		table.Artikel.
			INNER_JOIN(table.UserAccount, table.UserAccount.IDUser.EQ(table.Artikel.IDPenulis)),
	).WHERE(
		table.Artikel.StatusArtikel.EQ(postgres.String("Menunggu Review")),
	)
	
	// Count total
	var total int64
	err := stmt.Query(r.db, &total)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to count pending artikel: %w", err)
	}
	
	// Apply pagination
	stmt = stmt.
		ORDER_BY(table.Artikel.CreatedAt.DESC()).
		LIMIT(int64(perPage)).
		OFFSET(int64(offset))
	
	var results []struct {
		IDArtikel     int32
		Judul         string
		NamaPenulis   string
		CreatedAt     sql.NullTime
		StatusArtikel string
	}
	
	err = stmt.Query(r.db, &results)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to query pending artikel: %w", err)
	}
	
	views := make([]ArtikelPendingView, len(results))
	for i, res := range results {
		views[i] = ArtikelPendingView{
			IDArtikel:     res.IDArtikel,
			Judul:         res.Judul,
			NamaPenulis:   res.NamaPenulis,
			CreatedAt:     res.CreatedAt,
			StatusArtikel: res.StatusArtikel,
		}
	}
	
	return views, int(total), nil
}

// GetArtikelForUpdate mendapatkan artikel untuk validasi
func (r *artikelRepository) GetArtikelForUpdate(ctx context.Context, id, idPenulis int) (*model.Artikel, error) {
	stmt := postgres.SELECT(
		table.Artikel.AllColumns,
	).FROM(
		table.Artikel,
	).WHERE(
		table.Artikel.IDArtikel.EQ(postgres.Int32(int32(id))).
			AND(table.Artikel.IDPenulis.EQ(postgres.Int32(int32(idPenulis)))),
	)
	
	var artikel model.Artikel
	err := stmt.Query(r.db, &artikel)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil
		}
		return nil, fmt.Errorf("failed to get artikel for update: %w", err)
	}
	
	return &artikel, nil
}
