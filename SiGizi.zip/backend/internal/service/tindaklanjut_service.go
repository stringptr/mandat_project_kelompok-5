package service

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"myproject/internal/model"
	"myproject/internal/repository"
)

// TindakLanjutService interface untuk business logic modul tindak lanjut
type TindakLanjutService interface {
	// GetPasienTindakLanjutList mengambil daftar pasien yang memerlukan tindak lanjut
	GetPasienTindakLanjutList(ctx context.Context, req model.PasienTindakLanjutListRequest, idUser int, role string) (*model.PaginatedResponse[model.PasienTindakLanjutListResponse], []model.ErrorItem, error)

	// GetDetailPasienTindakLanjut mengambil detail pasien dan riwayat pemeriksaan
	GetDetailPasienTindakLanjut(ctx context.Context, idPasien int, idUser int, role string) (*model.DetailPasienTindakLanjutResponse, []model.ErrorItem, error)

	// CreateTindakLanjut membuat tindak lanjut dan rujukan
	CreateTindakLanjut(ctx context.Context, req model.CreateTindakLanjutBody, idUser int, role string) (*model.CreateTindakLanjutResponse, []model.ErrorItem, error)

	// UpdateStatusRujukan mengubah status rujukan
	UpdateStatusRujukan(ctx context.Context, idRujukan int, req model.UpdateStatusRujukanBody, idUser int, role string) (*model.UpdateStatusRujukanResponse, []model.ErrorItem, error)

	// GetDetailTindakLanjut mengambil detail tindak lanjut untuk ibu/wali
	GetDetailTindakLanjut(ctx context.Context, idTindakLanjut int, idUser int, role string) (*model.DetailTindakLanjutResponse, []model.ErrorItem, error)

	// GetStatusTindakLanjutList mengambil status tindak lanjut untuk kader
	GetStatusTindakLanjutList(ctx context.Context, req model.StatusTindakLanjutListRequest, idUser int, role string) (*model.PaginatedResponse[model.StatusTindakLanjutListResponse], []model.ErrorItem, error)

	// GetLaporanTindakLanjut mengambil laporan rekap untuk dinkes
	GetLaporanTindakLanjut(ctx context.Context, req model.LaporanTindakLanjutRequest, idUser int, role string) (*model.LaporanTindakLanjutResponse, []model.ErrorItem, error)
}

// tindakLanjutService implementasi TindakLanjutService
type tindakLanjutService struct {
	repo repository.TindakLanjutRepository
}

// NewTindakLanjutService membuat instance baru TindakLanjutService
func NewTindakLanjutService(repo repository.TindakLanjutRepository) TindakLanjutService {
	return &tindakLanjutService{repo: repo}
}

// GetPasienTindakLanjutList implementasi business logic untuk list pasien
func (s *tindakLanjutService) GetPasienTindakLanjutList(ctx context.Context, req model.PasienTindakLanjutListRequest, idUser int, role string) (*model.PaginatedResponse[model.PasienTindakLanjutListResponse], []model.ErrorItem, error) {
	// Validasi role - hanya Bidan yang bisa akses
	if role != "BIDAN" {
		return nil, []model.ErrorItem{
			{Message: model.ErrorMessages[model.ErrAuthForbidden]},
		}, nil
	}

	// Validasi ENUM status_pasien jika diberikan
	if req.StatusPasien != "" {
		validStatuses := []string{"Dalam Pemantauan", "Membaik", "Perlu Rujukan", "Selesai Pemantauan"}
		if !containsString(validStatuses, req.StatusPasien) {
			return nil, []model.ErrorItem{
				{
					Location: "query.status_pasien",
					Message:  model.ErrorMessages[model.ErrValidationEnum],
					Value:    req.StatusPasien,
				},
			}, nil
		}
	}

	// Build filter
	filter := model.TindakLanjutFilter{
		Page:         req.Page,
		PerPage:      req.PerPage,
		Q:            req.Q,
		StatusPasien: req.StatusPasien,
	}

	// Query repository
	items, total, err := s.repo.GetPasienTindakLanjutList(ctx, filter)
	if err != nil {
		return nil, nil, err
	}

	// Build response
	response := model.NewPaginatedResponse(
		model.PasienTindakLanjutListResponse{Pasien: items},
		req.Page,
		req.PerPage,
		total,
	)

	return &response, nil, nil
}

// GetDetailPasienTindakLanjut implementasi business logic untuk detail pasien
func (s *tindakLanjutService) GetDetailPasienTindakLanjut(ctx context.Context, idPasien int, idUser int, role string) (*model.DetailPasienTindakLanjutResponse, []model.ErrorItem, error) {
	// Validasi role - hanya Bidan yang bisa akses
	if role != "BIDAN" {
		return nil, []model.ErrorItem{
			{Message: model.ErrorMessages[model.ErrAuthForbidden]},
		}, nil
	}

	// Query repository
	detail, err := s.repo.GetDetailPasienTindakLanjut(ctx, idPasien)
	if err != nil {
		return nil, nil, err
	}

	// Check not found
	if detail == nil {
		return nil, []model.ErrorItem{
			{Message: model.ErrorMessages[model.ErrDataNotFound]},
		}, nil
	}

	return detail, nil, nil
}

// CreateTindakLanjut implementasi business logic untuk membuat tindak lanjut
func (s *tindakLanjutService) CreateTindakLanjut(ctx context.Context, req model.CreateTindakLanjutBody, idUser int, role string) (*model.CreateTindakLanjutResponse, []model.ErrorItem, error) {
	// Validasi role - hanya Bidan yang bisa akses
	if role != "BIDAN" {
		return nil, []model.ErrorItem{
			{Message: model.ErrorMessages[model.ErrAuthForbidden]},
		}, nil
	}

	// Validasi business rules
	var errItems []model.ErrorItem

	// Validasi ENUM jenis_tindakan
	validJenisTindakan := []string{
		"Konseling Gizi",
		"Jadwal Ulang Pemeriksaan",
		"Rujukan Rumah Sakit",
		"Rujukan Puskesmas",
	}
	if !containsString(validJenisTindakan, req.JenisTindakan) {
		errItems = append(errItems, model.ErrorItem{
			Location: "body.jenis_tindakan",
			Message:  model.ErrorMessages[model.ErrValidationEnum],
			Value:    req.JenisTindakan,
		})
	}

	// Validasi khusus untuk rujukan
	isRujukan := req.JenisTindakan == "Rujukan Rumah Sakit" || req.JenisTindakan == "Rujukan Puskesmas"
	if isRujukan {
		// id_faskes wajib diisi
		if req.IDFaskes == nil {
			errItems = append(errItems, model.ErrorItem{
				Location: "body.id_faskes",
				Message:  "Lokasi rujukan/faskes wajib diisi untuk jenis tindakan rujukan.",
				Value:    nil,
			})
		}

		// alasan_rujukan wajib diisi
		if req.AlasanRujukan == nil || *req.AlasanRujukan == "" {
			errItems = append(errItems, model.ErrorItem{
				Location: "body.alasan_rujukan",
				Message:  "Alasan rujukan wajib diisi.",
				Value:    "",
			})
		}
	}

	// Return jika ada validation errors
	if len(errItems) > 0 {
		return nil, errItems, nil
	}

	// Parse jadwal_kontrol jika ada
	var jadwalKontrol *time.Time
	if req.JadwalKontrol != nil && *req.JadwalKontrol != "" {
		parsed, err := time.Parse("2006-01-02", *req.JadwalKontrol)
		if err != nil {
			return nil, []model.ErrorItem{
				{
					Location: "body.jadwal_kontrol",
					Message:  "Format tanggal tidak valid, gunakan YYYY-MM-DD.",
					Value:    *req.JadwalKontrol,
				},
			}, nil
		}
		jadwalKontrol = &parsed
	}

	// Build params untuk stored procedure
	params := repository.CreateTindakLanjutParams{
		IDHasilPemeriksaan: req.IDHasilPemeriksaan,
		IDBidan:            idUser,
		JenisTindakan:      req.JenisTindakan,
		CatatanMedis:       req.CatatanMedis,
		Rekomendasi:        req.Rekomendasi,
		JadwalKontrol:      jadwalKontrol,
		AlasanRujukan:      req.AlasanRujukan,
		IDFaskes:           req.IDFaskes,
	}

	// Panggil repository untuk execute SP
	result, err := s.repo.CreateTindakLanjutRujukan(ctx, params)
	if err != nil {
		return nil, nil, err
	}

	// Mapping hasil SP ke ErrorItem
	switch result.PResult {
	case "PEMERIKSAAN_NOT_FOUND":
		return nil, []model.ErrorItem{
			{
				Location: "body.id_hasil_pemeriksaan",
				Message:  "Data hasil pemeriksaan tidak ditemukan.",
				Value:    req.IDHasilPemeriksaan,
			},
		}, nil

	case "FASKES_NOT_FOUND":
		return nil, []model.ErrorItem{
			{
				Location: "body.id_faskes",
				Message:  "Fasilitas kesehatan tidak ditemukan.",
				Value:    req.IDFaskes,
			},
		}, nil

	case "ALREADY_HAS_TINDAK_LANJUT":
		return nil, []model.ErrorItem{
			{
				Location: "body.id_hasil_pemeriksaan",
				Message:  "Pemeriksaan ini sudah memiliki tindak lanjut yang aktif.",
				Value:    req.IDHasilPemeriksaan,
			},
		}, nil

	case "SUCCESS":
		// Tentukan status_pasien berdasarkan jenis_tindakan
		statusPasien := "Dalam Pemantauan"
		if isRujukan {
			statusPasien = "Perlu Rujukan"
		}

		return &model.CreateTindakLanjutResponse{
			IDTindakLanjut: result.PIdTindakLanjut,
			IDRujukan:      result.PIdRujukan,
			StatusPasien:   statusPasien,
		}, nil, nil

	default:
		return nil, nil, fmt.Errorf("unexpected SP result: %s", result.PResult)
	}
}

// UpdateStatusRujukan implementasi business logic untuk update status rujukan
func (s *tindakLanjutService) UpdateStatusRujukan(ctx context.Context, idRujukan int, req model.UpdateStatusRujukanBody, idUser int, role string) (*model.UpdateStatusRujukanResponse, []model.ErrorItem, error) {
	// Validasi role - hanya Bidan yang bisa akses
	if role != "BIDAN" {
		return nil, []model.ErrorItem{
			{Message: model.ErrorMessages[model.ErrAuthForbidden]},
		}, nil
	}

	// Validasi ENUM status_rujukan
	validStatusRujukan := []string{
		"Menunggu Konfirmasi",
		"Diproses",
		"Diterima",
		"Selesai",
	}
	if !containsString(validStatusRujukan, req.StatusRujukan) {
		return nil, []model.ErrorItem{
			{
				Location: "body.status_rujukan",
				Message:  model.ErrorMessages[model.ErrValidationEnum],
				Value:    req.StatusRujukan,
			},
		}, nil
	}

	// Validasi transisi status via function
	validation, err := s.repo.ValidateStatusRujukanTransition(ctx, idRujukan, req.StatusRujukan)
	if err != nil {
		return nil, nil, err
	}

	if !validation.IsValid {
		return nil, []model.ErrorItem{
			{
				Location: "body.status_rujukan",
				Message:  "Transisi status rujukan tidak valid.",
				Value:    req.StatusRujukan,
			},
		}, nil
	}

	// Update status rujukan
	err = s.repo.UpdateStatusRujukan(ctx, idRujukan, req.StatusRujukan, idUser)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, []model.ErrorItem{
				{Message: model.ErrorMessages[model.ErrDataNotFound]},
			}, nil
		}
		return nil, nil, err
	}

	return &model.UpdateStatusRujukanResponse{
		IDRujukan:     idRujukan,
		StatusRujukan: req.StatusRujukan,
	}, nil, nil
}

// GetDetailTindakLanjut implementasi business logic untuk detail tindak lanjut
func (s *tindakLanjutService) GetDetailTindakLanjut(ctx context.Context, idTindakLanjut int, idUser int, role string) (*model.DetailTindakLanjutResponse, []model.ErrorItem, error) {
	// Validasi role - hanya Ibu/Wali yang bisa akses
	if role != "IBU" && role != "WALI" {
		return nil, []model.ErrorItem{
			{Message: model.ErrorMessages[model.ErrAuthForbidden]},
		}, nil
	}

	// Query repository
	detail, err := s.repo.GetDetailTindakLanjut(ctx, idTindakLanjut)
	if err != nil {
		return nil, nil, err
	}

	// Check not found
	if detail == nil {
		return nil, []model.ErrorItem{
			{Message: model.ErrorMessages[model.ErrDataNotFound]},
		}, nil
	}

	return detail, nil, nil
}

// GetStatusTindakLanjutList implementasi business logic untuk status tindak lanjut
func (s *tindakLanjutService) GetStatusTindakLanjutList(ctx context.Context, req model.StatusTindakLanjutListRequest, idUser int, role string) (*model.PaginatedResponse[model.StatusTindakLanjutListResponse], []model.ErrorItem, error) {
	// Validasi role - hanya Kader yang bisa akses
	if role != "KADER" {
		return nil, []model.ErrorItem{
			{Message: model.ErrorMessages[model.ErrAuthForbidden]},
		}, nil
	}

	// Validasi ENUM status_rujukan jika diberikan
	if req.StatusRujukan != "" {
		validStatusRujukan := []string{
			"Menunggu Konfirmasi",
			"Diproses",
			"Diterima",
			"Selesai",
		}
		if !containsString(validStatusRujukan, req.StatusRujukan) {
			return nil, []model.ErrorItem{
				{
					Location: "query.status_rujukan",
					Message:  model.ErrorMessages[model.ErrValidationEnum],
					Value:    req.StatusRujukan,
				},
			}, nil
		}
	}

	// Build filter
	filter := model.StatusTindakLanjutFilter{
		Page:          req.Page,
		PerPage:       req.PerPage,
		StatusRujukan: req.StatusRujukan,
	}

	// Query repository
	items, total, err := s.repo.GetStatusTindakLanjutList(ctx, filter)
	if err != nil {
		return nil, nil, err
	}

	// Build response
	response := model.NewPaginatedResponse(
		model.StatusTindakLanjutListResponse{Pasien: items},
		req.Page,
		req.PerPage,
		total,
	)

	return &response, nil, nil
}

// GetLaporanTindakLanjut implementasi business logic untuk laporan
func (s *tindakLanjutService) GetLaporanTindakLanjut(ctx context.Context, req model.LaporanTindakLanjutRequest, idUser int, role string) (*model.LaporanTindakLanjutResponse, []model.ErrorItem, error) {
	// Validasi role - hanya Dinas Kesehatan yang bisa akses
	if role != "DINKES" {
		return nil, []model.ErrorItem{
			{Message: model.ErrorMessages[model.ErrAuthForbidden]},
		}, nil
	}

	// Validasi business rules
	var errItems []model.ErrorItem

	// Validasi bulan (1-12)
	if req.Bulan != nil {
		if *req.Bulan < 1 || *req.Bulan > 12 {
			errItems = append(errItems, model.ErrorItem{
				Location: "query.bulan",
				Message:  "Nilai bulan harus antara 1 hingga 12.",
				Value:    *req.Bulan,
			})
		}
	}

	// Return jika ada validation errors
	if len(errItems) > 0 {
		return nil, errItems, nil
	}

	// Set default values
	bulan := time.Now().Month()
	if req.Bulan != nil {
		bulan = time.Month(*req.Bulan)
	}

	tahun := time.Now().Year()
	if req.Tahun != nil {
		tahun = *req.Tahun
	}

	// Build filter
	filter := model.LaporanFilter{
		Bulan:      int(bulan),
		Tahun:      tahun,
		IDPosyandu: req.IDPosyandu,
	}

	// Query repository
	items, err := s.repo.GetLaporanTindakLanjut(ctx, filter)
	if err != nil {
		return nil, nil, err
	}

	// Build response
	response := model.LaporanTindakLanjutResponse{
		Periode: model.PeriodeInfo{
			Bulan: int(bulan),
			Tahun: tahun,
		},
		Laporan:   items,
		TotalData: len(items),
	}

	return &response, nil, nil
}

// Helper function untuk cek apakah value ada dalam slice
func containsString(slice []string, value string) bool {
	for _, item := range slice {
		if item == value {
			return true
		}
	}
	return false
}
