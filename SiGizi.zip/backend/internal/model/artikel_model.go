package model

import "time"

// ============= REQUEST STRUCTS (ARTIKEL) =============

// ArtikelListRequest untuk GET /api/v1/artikel
type ArtikelListRequest struct {
	Page     int    `query:"page" default:"1" minimum:"1"`
	PerPage  int    `query:"per_page" default:"15" minimum:"1" maximum:"100"`
	Kategori string `query:"kategori"`
	Q        string `query:"q"` // pencarian judul/konten
}

// CreateArtikelBody untuk POST /api/v1/artikel
type CreateArtikelBody struct {
	Judul     string  `json:"judul" maxLength:"255" required:"true"`
	IsiArtikel string `json:"isi_artikel" required:"true"`
	Kategori  *string `json:"kategori" maxLength:"100"`
	// Thumbnail dihandle sebagai multipart file upload
}

// UpdateArtikelBody untuk PATCH /api/v1/artikel/{id}
type UpdateArtikelBody struct {
	Judul      *string `json:"judul" maxLength:"255"`
	IsiArtikel *string `json:"isi_artikel"`
	Kategori   *string `json:"kategori" maxLength:"100"`
}

// ReviewArtikelBody untuk PATCH /api/v1/artikel/{id}/review
type ReviewArtikelBody struct {
	Aksi          string  `json:"aksi" enum:"setujui,tolak" required:"true"`
	CatatanReview *string `json:"catatan_review" maxLength:"1000"`
}

// ArtikelPendingRequest untuk GET /api/v1/artikel/pending
type ArtikelPendingRequest struct {
	Page    int `query:"page" default:"1" minimum:"1"`
	PerPage int `query:"per_page" default:"15" minimum:"1" maximum:"100"`
}

// ============= RESPONSE STRUCTS (ARTIKEL) =============

// ArtikelItem untuk list artikel
type ArtikelItem struct {
	IDArtikel      int     `json:"id_artikel"`
	Judul          string  `json:"judul"`
	Kategori       *string `json:"kategori,omitempty"`
	Ringkasan      string  `json:"ringkasan"`
	NamaPenulis    string  `json:"nama_penulis"`
	TanggalPublish *string `json:"tanggal_publish,omitempty"`
	ThumbnailURL   *string `json:"thumbnail_url,omitempty"`
}

// ArtikelListResponse untuk GET /api/v1/artikel
type ArtikelListResponse struct {
	Artikel []ArtikelItem `json:"artikel"`
}

// ArtikelDetailResponse untuk GET /api/v1/artikel/{id}
type ArtikelDetailResponse struct {
	IDArtikel        int     `json:"id_artikel"`
	Judul            string  `json:"judul"`
	IsiArtikel       string  `json:"isi_artikel"`
	Kategori         *string `json:"kategori,omitempty"`
	NamaPenulis      string  `json:"nama_penulis"`
	NamaVerifikator  *string `json:"nama_verifikator,omitempty"`
	TanggalPublish   *string `json:"tanggal_publish,omitempty"`
	CreatedAt        time.Time `json:"created_at"`
	UpdatedAt        time.Time `json:"updated_at"`
}

// CreateArtikelResponse untuk POST /api/v1/artikel
type CreateArtikelResponse struct {
	IDArtikel     int    `json:"id_artikel"`
	StatusArtikel string `json:"status_artikel"`
	Detail        string `json:"detail"`
}

// ReviewArtikelResponse untuk PATCH /api/v1/artikel/{id}/review
type ReviewArtikelResponse struct {
	IDArtikel      int     `json:"id_artikel"`
	StatusArtikel  string  `json:"status_artikel"`
	TanggalPublish *string `json:"tanggal_publish,omitempty"`
}

// ArtikelPendingItem untuk list pending
type ArtikelPendingItem struct {
	IDArtikel    int       `json:"id_artikel"`
	Judul        string    `json:"judul"`
	NamaPenulis  string    `json:"nama_penulis"`
	CreatedAt    time.Time `json:"created_at"`
	StatusArtikel string   `json:"status_artikel"`
}

// ArtikelPendingResponse untuk GET /api/v1/artikel/pending
type ArtikelPendingResponse struct {
	Artikel []ArtikelPendingItem `json:"artikel"`
}

// UpdateArtikelResponse untuk PATCH /api/v1/artikel/{id}
type UpdateArtikelResponse struct {
        IDArtikel     int    `json:"id_artikel"`
        StatusArtikel string `json:"status_artikel"`
}

// DeleteArtikelResponse untuk DELETE /api/v1/artikel/{id}
type DeleteArtikelResponse struct {
        IDArtikel int    `json:"id_artikel"`
        Detail    string `json:"detail"`
}
