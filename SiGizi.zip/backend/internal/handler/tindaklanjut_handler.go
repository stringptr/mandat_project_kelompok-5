package handler

import (
	"context"
	"net/http"

	"myproject/internal/model"
	"myproject/internal/service"

	"github.com/danielgtaylor/huma/v2"
)

// TindakLanjutHandler handles HTTP routing for tindak lanjut endpoints
type TindakLanjutHandler struct {
	service service.TindakLanjutService
}

// NewTindakLanjutHandler creates new instance
func NewTindakLanjutHandler(service service.TindakLanjutService) *TindakLanjutHandler {
	return &TindakLanjutHandler{service: service}
}

// RegisterRoutes registers all tindak lanjut endpoints with Huma
func (h *TindakLanjutHandler) RegisterRoutes(api huma.API) {
	// Submodul Tindak Lanjut
	huma.Register(api, huma.Operation{
		OperationID: "get-pasien-tindak-lanjut-list",
		Method:      http.MethodGet,
		Path:        "/api/v1/tindak-lanjut/pasien",
		Summary:     "Daftar Pasien yang Memerlukan Tindak Lanjut",
		Description: "Mengambil daftar pasien yang memerlukan tindak lanjut dengan filter dan pagination (Role: Bidan)",
		Tags:        []string{"Tindak Lanjut"},
	}, h.GetPasienTindakLanjutList)

	huma.Register(api, huma.Operation{
		OperationID: "get-detail-pasien-tindak-lanjut",
		Method:      http.MethodGet,
		Path:        "/api/v1/tindak-lanjut/pasien/{id}",
		Summary:     "Detail Pasien dan Riwayat Pemeriksaan",
		Description: "Mengambil detail pasien beserta riwayat pemeriksaan lengkap (Role: Bidan)",
		Tags:        []string{"Tindak Lanjut"},
	}, h.GetDetailPasienTindakLanjut)

	huma.Register(api, huma.Operation{
		OperationID: "create-tindak-lanjut",
		Method:      http.MethodPost,
		Path:        "/api/v1/tindak-lanjut",
		Summary:     "Membuat Tindak Lanjut dan Rujukan",
		Description: "Membuat tindak lanjut untuk pasien, bisa berupa konseling, jadwal ulang, atau rujukan (Role: Bidan)",
		Tags:        []string{"Tindak Lanjut"},
	}, h.CreateTindakLanjut)

	huma.Register(api, huma.Operation{
		OperationID: "update-status-rujukan",
		Method:      http.MethodPatch,
		Path:        "/api/v1/rujukan/{id}/status",
		Summary:     "Mengubah Status Rujukan",
		Description: "Mengubah status rujukan dengan validasi transisi status (Role: Bidan)",
		Tags:        []string{"Tindak Lanjut"},
	}, h.UpdateStatusRujukan)

	huma.Register(api, huma.Operation{
		OperationID: "get-detail-tindak-lanjut",
		Method:      http.MethodGet,
		Path:        "/api/v1/tindak-lanjut/{id}",
		Summary:     "Detail Tindak Lanjut (untuk Ibu/Wali)",
		Description: "Mengambil detail tindak lanjut pasien untuk ditampilkan kepada ibu/wali (Role: Ibu/Wali)",
		Tags:        []string{"Tindak Lanjut"},
	}, h.GetDetailTindakLanjut)

	huma.Register(api, huma.Operation{
		OperationID: "get-status-tindak-lanjut-list",
		Method:      http.MethodGet,
		Path:        "/api/v1/tindak-lanjut/status",
		Summary:     "Status Tindak Lanjut Pasien (untuk Kader)",
		Description: "Mengambil status tindak lanjut pasien untuk monitoring oleh kader posyandu (Role: Kader)",
		Tags:        []string{"Tindak Lanjut"},
	}, h.GetStatusTindakLanjutList)

	// Submodul Laporan
	huma.Register(api, huma.Operation{
		OperationID: "get-laporan-tindak-lanjut",
		Method:      http.MethodGet,
		Path:        "/api/v1/laporan/tindak-lanjut",
		Summary:     "Laporan Rekap Tindak Lanjut dan Rujukan",
		Description: "Mengambil laporan rekap tindak lanjut dan rujukan per wilayah (Role: Dinas Kesehatan)",
		Tags:        []string{"Laporan"},
	}, h.GetLaporanTindakLanjut)
}

// ============================================================================
// REQUEST/RESPONSE WRAPPERS FOR HUMA
// ============================================================================

// GetPasienTindakLanjutListInput wraps request for GET /api/v1/tindak-lanjut/pasien
type GetPasienTindakLanjutListInput struct {
	Query model.PasienTindakLanjutListRequest
}

// GetPasienTindakLanjutListOutput wraps response for GET /api/v1/tindak-lanjut/pasien
type GetPasienTindakLanjutListOutput struct {
	Body model.APIResponse[model.PaginatedResponse[model.PasienTindakLanjutListResponse]]
}

// GetDetailPasienTindakLanjutInput wraps request for GET /api/v1/tindak-lanjut/pasien/{id}
type GetDetailPasienTindakLanjutInput struct {
	ID int `path:"id" minimum:"1" doc:"ID Pasien"`
}

// GetDetailPasienTindakLanjutOutput wraps response for GET /api/v1/tindak-lanjut/pasien/{id}
type GetDetailPasienTindakLanjutOutput struct {
	Body model.APIResponse[model.DetailPasienTindakLanjutResponse]
}

// CreateTindakLanjutInput wraps request for POST /api/v1/tindak-lanjut
type CreateTindakLanjutInput struct {
	Body model.CreateTindakLanjutBody
}

// CreateTindakLanjutOutput wraps response for POST /api/v1/tindak-lanjut
type CreateTindakLanjutOutput struct {
	Body model.APIResponse[model.CreateTindakLanjutResponse]
}

// UpdateStatusRujukanInput wraps request for PATCH /api/v1/rujukan/{id}/status
type UpdateStatusRujukanInput struct {
	ID   int                             `path:"id" minimum:"1" doc:"ID Rujukan"`
	Body model.UpdateStatusRujukanBody
}

// UpdateStatusRujukanOutput wraps response for PATCH /api/v1/rujukan/{id}/status
type UpdateStatusRujukanOutput struct {
	Body model.APIResponse[model.UpdateStatusRujukanResponse]
}

// GetDetailTindakLanjutInput wraps request for GET /api/v1/tindak-lanjut/{id}
type GetDetailTindakLanjutInput struct {
	ID int `path:"id" minimum:"1" doc:"ID Tindak Lanjut"`
}

// GetDetailTindakLanjutOutput wraps response for GET /api/v1/tindak-lanjut/{id}
type GetDetailTindakLanjutOutput struct {
	Body model.APIResponse[model.DetailTindakLanjutResponse]
}

// GetStatusTindakLanjutListInput wraps request for GET /api/v1/tindak-lanjut/status
type GetStatusTindakLanjutListInput struct {
	Query model.StatusTindakLanjutListRequest
}

// GetStatusTindakLanjutListOutput wraps response for GET /api/v1/tindak-lanjut/status
type GetStatusTindakLanjutListOutput struct {
	Body model.APIResponse[model.PaginatedResponse[model.StatusTindakLanjutListResponse]]
}

// GetLaporanTindakLanjutInput wraps request for GET /api/v1/laporan/tindak-lanjut
type GetLaporanTindakLanjutInput struct {
	Query model.LaporanTindakLanjutRequest
}

// GetLaporanTindakLanjutOutput wraps response for GET /api/v1/laporan/tindak-lanjut
type GetLaporanTindakLanjutOutput struct {
	Body model.APIResponse[model.LaporanTindakLanjutResponse]
}

// ============================================================================
// HANDLER IMPLEMENTATIONS
// ============================================================================

// GetPasienTindakLanjutList handler for GET /api/v1/tindak-lanjut/pasien
func (h *TindakLanjutHandler) GetPasienTindakLanjutList(ctx context.Context, input *GetPasienTindakLanjutListInput) (*GetPasienTindakLanjutListOutput, error) {
	// Extract JWT claims from context (injected by middleware)
	idUser := getIDUserFromContext(ctx)
	role := getRoleFromContext(ctx)

	// Check auth
	if idUser == 0 {
		return &GetPasienTindakLanjutListOutput{
			Body: model.NewErrorResponse[model.PaginatedResponse[model.PasienTindakLanjutListResponse]](
				401,
				"Unauthorized",
				model.ErrorMessages[model.ErrAuthUnauthorized],
				[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}},
			),
		}, nil
	}

	// Call service
	result, errItems, err := h.service.GetPasienTindakLanjutList(ctx, input.Query, idUser, role)
	if err != nil {
		return &GetPasienTindakLanjutListOutput{
			Body: model.NewErrorResponse[model.PaginatedResponse[model.PasienTindakLanjutListResponse]](
				500,
				"Internal Server Error",
				model.ErrorMessages[model.ErrSystem],
				[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrSystem]}},
			),
		}, nil
	}

	// Check for business logic errors
	if len(errItems) > 0 {
		// Check error type for proper status code
		for _, e := range errItems {
			if e.Message == model.ErrorMessages[model.ErrAuthForbidden] {
				return &GetPasienTindakLanjutListOutput{
					Body: model.NewErrorResponse[model.PaginatedResponse[model.PasienTindakLanjutListResponse]](
						403,
						"Forbidden",
						model.ErrorMessages[model.ErrAuthForbidden],
						errItems,
					),
				}, nil
			}
		}
		// Validation errors
		return &GetPasienTindakLanjutListOutput{
			Body: model.NewErrorResponse[model.PaginatedResponse[model.PasienTindakLanjutListResponse]](
				422,
				"Unprocessable Content",
				"Terdapat kesalahan pada pengisian data.",
				errItems,
			),
		}, nil
	}

	// Success response
	return &GetPasienTindakLanjutListOutput{
		Body: model.NewSuccessResponse(
			200,
			"OK",
			"Daftar pasien yang memerlukan tindak lanjut berhasil diambil.",
			*result,
		),
	}, nil
}

// GetDetailPasienTindakLanjut handler for GET /api/v1/tindak-lanjut/pasien/{id}
func (h *TindakLanjutHandler) GetDetailPasienTindakLanjut(ctx context.Context, input *GetDetailPasienTindakLanjutInput) (*GetDetailPasienTindakLanjutOutput, error) {
	// Extract JWT claims
	idUser := getIDUserFromContext(ctx)
	role := getRoleFromContext(ctx)

	// Check auth
	if idUser == 0 {
		return &GetDetailPasienTindakLanjutOutput{
			Body: model.NewErrorResponse[model.DetailPasienTindakLanjutResponse](
				401,
				"Unauthorized",
				model.ErrorMessages[model.ErrAuthUnauthorized],
				[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}},
			),
		}, nil
	}

	// Call service
	result, errItems, err := h.service.GetDetailPasienTindakLanjut(ctx, input.ID, idUser, role)
	if err != nil {
		return &GetDetailPasienTindakLanjutOutput{
			Body: model.NewErrorResponse[model.DetailPasienTindakLanjutResponse](
				500,
				"Internal Server Error",
				model.ErrorMessages[model.ErrSystem],
				[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrSystem]}},
			),
		}, nil
	}

	// Check for errors
	if len(errItems) > 0 {
		for _, e := range errItems {
			if e.Message == model.ErrorMessages[model.ErrAuthForbidden] {
				return &GetDetailPasienTindakLanjutOutput{
					Body: model.NewErrorResponse[model.DetailPasienTindakLanjutResponse](403, "Forbidden", model.ErrorMessages[model.ErrAuthForbidden], errItems),
				}, nil
			}
			if e.Message == model.ErrorMessages[model.ErrDataNotFound] {
				return &GetDetailPasienTindakLanjutOutput{
					Body: model.NewErrorResponse[model.DetailPasienTindakLanjutResponse](404, "Not Found", "Data tidak ditemukan.", errItems),
				}, nil
			}
		}
	}

	// Success response
	return &GetDetailPasienTindakLanjutOutput{
		Body: model.NewSuccessResponse(
			200,
			"OK",
			"Detail pasien berhasil diambil.",
			*result,
		),
	}, nil
}

// CreateTindakLanjut handler for POST /api/v1/tindak-lanjut
func (h *TindakLanjutHandler) CreateTindakLanjut(ctx context.Context, input *CreateTindakLanjutInput) (*CreateTindakLanjutOutput, error) {
	// Extract JWT claims
	idUser := getIDUserFromContext(ctx)
	role := getRoleFromContext(ctx)

	// Check auth
	if idUser == 0 {
		return &CreateTindakLanjutOutput{
			Body: model.NewErrorResponse[model.CreateTindakLanjutResponse](
				401,
				"Unauthorized",
				model.ErrorMessages[model.ErrAuthUnauthorized],
				[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}},
			),
		}, nil
	}

	// Call service
	result, errItems, err := h.service.CreateTindakLanjut(ctx, input.Body, idUser, role)
	if err != nil {
		return &CreateTindakLanjutOutput{
			Body: model.NewErrorResponse[model.CreateTindakLanjutResponse](
				500,
				"Internal Server Error",
				model.ErrorMessages[model.ErrSystem],
				[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrSystem]}},
			),
		}, nil
	}

	// Check for errors
	if len(errItems) > 0 {
		for _, e := range errItems {
			if e.Message == model.ErrorMessages[model.ErrAuthForbidden] {
				return &CreateTindakLanjutOutput{
					Body: model.NewErrorResponse[model.CreateTindakLanjutResponse](403, "Forbidden", model.ErrorMessages[model.ErrAuthForbidden], errItems),
				}, nil
			}
			if e.Message == model.ErrorMessages[model.ErrDataNotFound] || e.Location == "body.id_hasil_pemeriksaan" || e.Location == "body.id_faskes" {
				// Check if it's reference not found error
				if e.Location == "body.id_faskes" || e.Location == "body.id_hasil_pemeriksaan" {
					return &CreateTindakLanjutOutput{
						Body: model.NewErrorResponse[model.CreateTindakLanjutResponse](404, "Not Found", "Data tidak ditemukan.", errItems),
					}, nil
				}
			}
		}
		// Validation errors
		return &CreateTindakLanjutOutput{
			Body: model.NewErrorResponse[model.CreateTindakLanjutResponse](
				422,
				"Unprocessable Content",
				"Terdapat kesalahan pada pengisian data.",
				errItems,
			),
		}, nil
	}

	// Success response
	return &CreateTindakLanjutOutput{
		Body: model.NewSuccessResponse(
			201,
			"Created",
			"Tindak lanjut berhasil dibuat dan notifikasi telah dikirim.",
			*result,
		),
	}, nil
}

// UpdateStatusRujukan handler for PATCH /api/v1/rujukan/{id}/status
func (h *TindakLanjutHandler) UpdateStatusRujukan(ctx context.Context, input *UpdateStatusRujukanInput) (*UpdateStatusRujukanOutput, error) {
	// Extract JWT claims
	idUser := getIDUserFromContext(ctx)
	role := getRoleFromContext(ctx)

	// Check auth
	if idUser == 0 {
		return &UpdateStatusRujukanOutput{
			Body: model.NewErrorResponse[model.UpdateStatusRujukanResponse](
				401,
				"Unauthorized",
				model.ErrorMessages[model.ErrAuthUnauthorized],
				[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}},
			),
		}, nil
	}

	// Call service
	result, errItems, err := h.service.UpdateStatusRujukan(ctx, input.ID, input.Body, idUser, role)
	if err != nil {
		return &UpdateStatusRujukanOutput{
			Body: model.NewErrorResponse[model.UpdateStatusRujukanResponse](
				500,
				"Internal Server Error",
				model.ErrorMessages[model.ErrSystem],
				[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrSystem]}},
			),
		}, nil
	}

	// Check for errors
	if len(errItems) > 0 {
		for _, e := range errItems {
			if e.Message == model.ErrorMessages[model.ErrAuthForbidden] {
				return &UpdateStatusRujukanOutput{
					Body: model.NewErrorResponse[model.UpdateStatusRujukanResponse](403, "Forbidden", model.ErrorMessages[model.ErrAuthForbidden], errItems),
				}, nil
			}
			if e.Message == model.ErrorMessages[model.ErrDataNotFound] {
				return &UpdateStatusRujukanOutput{
					Body: model.NewErrorResponse[model.UpdateStatusRujukanResponse](404, "Not Found", "Data tidak ditemukan.", errItems),
				}, nil
			}
		}
		// Validation errors
		return &UpdateStatusRujukanOutput{
			Body: model.NewErrorResponse[model.UpdateStatusRujukanResponse](
				422,
				"Unprocessable Content",
				"Terdapat kesalahan pada pengisian data.",
				errItems,
			),
		}, nil
	}

	// Success response
	return &UpdateStatusRujukanOutput{
		Body: model.NewSuccessResponse(
			200,
			"OK",
			"Status rujukan berhasil diperbarui.",
			*result,
		),
	}, nil
}

// GetDetailTindakLanjut handler for GET /api/v1/tindak-lanjut/{id}
func (h *TindakLanjutHandler) GetDetailTindakLanjut(ctx context.Context, input *GetDetailTindakLanjutInput) (*GetDetailTindakLanjutOutput, error) {
	// Extract JWT claims
	idUser := getIDUserFromContext(ctx)
	role := getRoleFromContext(ctx)

	// Check auth
	if idUser == 0 {
		return &GetDetailTindakLanjutOutput{
			Body: model.NewErrorResponse[model.DetailTindakLanjutResponse](
				401,
				"Unauthorized",
				model.ErrorMessages[model.ErrAuthUnauthorized],
				[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}},
			),
		}, nil
	}

	// Call service
	result, errItems, err := h.service.GetDetailTindakLanjut(ctx, input.ID, idUser, role)
	if err != nil {
		return &GetDetailTindakLanjutOutput{
			Body: model.NewErrorResponse[model.DetailTindakLanjutResponse](
				500,
				"Internal Server Error",
				model.ErrorMessages[model.ErrSystem],
				[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrSystem]}},
			),
		}, nil
	}

	// Check for errors
	if len(errItems) > 0 {
		for _, e := range errItems {
			if e.Message == model.ErrorMessages[model.ErrAuthForbidden] {
				return &GetDetailTindakLanjutOutput{
					Body: model.NewErrorResponse[model.DetailTindakLanjutResponse](403, "Forbidden", model.ErrorMessages[model.ErrAuthForbidden], errItems),
				}, nil
			}
			if e.Message == model.ErrorMessages[model.ErrDataNotFound] {
				return &GetDetailTindakLanjutOutput{
					Body: model.NewErrorResponse[model.DetailTindakLanjutResponse](404, "Not Found", "Data tidak ditemukan.", errItems),
				}, nil
			}
		}
	}

	// Success response
	return &GetDetailTindakLanjutOutput{
		Body: model.NewSuccessResponse[model.DetailTindakLanjutResponse](
			200,
			"OK",
			"Detail tindak lanjut pasien berhasil diambil.",
			*result,
		),
	}, nil
}

// GetStatusTindakLanjutList handler for GET /api/v1/tindak-lanjut/status
func (h *TindakLanjutHandler) GetStatusTindakLanjutList(ctx context.Context, input *GetStatusTindakLanjutListInput) (*GetStatusTindakLanjutListOutput, error) {
	// Extract JWT claims
	idUser := getIDUserFromContext(ctx)
	role := getRoleFromContext(ctx)

	// Check auth
	if idUser == 0 {
		return &GetStatusTindakLanjutListOutput{
			Body: model.NewErrorResponse[model.PaginatedResponse[model.StatusTindakLanjutListResponse]](
				401,
				"Unauthorized",
				model.ErrorMessages[model.ErrAuthUnauthorized],
				[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}},
			),
		}, nil
	}

	// Call service
	result, errItems, err := h.service.GetStatusTindakLanjutList(ctx, input.Query, idUser, role)
	if err != nil {
		return &GetStatusTindakLanjutListOutput{
			Body: model.NewErrorResponse[model.PaginatedResponse[model.StatusTindakLanjutListResponse]](
				500,
				"Internal Server Error",
				model.ErrorMessages[model.ErrSystem],
				[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrSystem]}},
			),
		}, nil
	}

	// Check for errors
	if len(errItems) > 0 {
		for _, e := range errItems {
			if e.Message == model.ErrorMessages[model.ErrAuthForbidden] {
				return &GetStatusTindakLanjutListOutput{
					Body: model.NewErrorResponse[model.PaginatedResponse[model.StatusTindakLanjutListResponse]](403, "Forbidden", model.ErrorMessages[model.ErrAuthForbidden], errItems),
				}, nil
			}
		}
		// Validation errors
		return &GetStatusTindakLanjutListOutput{
			Body: model.NewErrorResponse[model.PaginatedResponse[model.StatusTindakLanjutListResponse]](
				422,
				"Unprocessable Content",
				"Terdapat kesalahan pada pengisian data.",
				errItems,
			),
		}, nil
	}

	// Success response
	return &GetStatusTindakLanjutListOutput{
		Body: model.NewSuccessResponse(
			200,
			"OK",
			"Status tindak lanjut pasien berhasil diambil.",
			*result,
		),
	}, nil
}

// GetLaporanTindakLanjut handler for GET /api/v1/laporan/tindak-lanjut
func (h *TindakLanjutHandler) GetLaporanTindakLanjut(ctx context.Context, input *GetLaporanTindakLanjutInput) (*GetLaporanTindakLanjutOutput, error) {
	// Extract JWT claims
	idUser := getIDUserFromContext(ctx)
	role := getRoleFromContext(ctx)

	// Check auth
	if idUser == 0 {
		return &GetLaporanTindakLanjutOutput{
			Body: model.NewErrorResponse[model.LaporanTindakLanjutResponse](
				401,
				"Unauthorized",
				model.ErrorMessages[model.ErrAuthUnauthorized],
				[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrAuthUnauthorized]}},
			),
		}, nil
	}

	// Call service
	result, errItems, err := h.service.GetLaporanTindakLanjut(ctx, input.Query, idUser, role)
	if err != nil {
		return &GetLaporanTindakLanjutOutput{
			Body: model.NewErrorResponse[model.LaporanTindakLanjutResponse](
				500,
				"Internal Server Error",
				model.ErrorMessages[model.ErrSystem],
				[]model.ErrorItem{{Message: model.ErrorMessages[model.ErrSystem]}},
			),
		}, nil
	}

	// Check for errors
	if len(errItems) > 0 {
		for _, e := range errItems {
			if e.Message == model.ErrorMessages[model.ErrAuthForbidden] {
				return &GetLaporanTindakLanjutOutput{
					Body: model.NewErrorResponse[model.LaporanTindakLanjutResponse](403, "Forbidden", model.ErrorMessages[model.ErrAuthForbidden], errItems),
				}, nil
			}
		}
		// Validation errors
		return &GetLaporanTindakLanjutOutput{
			Body: model.NewErrorResponse[model.LaporanTindakLanjutResponse](
				422,
				"Unprocessable Content",
				"Terdapat kesalahan pada pengisian data.",
				errItems,
			),
		}, nil
	}

	// Success response
	return &GetLaporanTindakLanjutOutput{
		Body: model.NewSuccessResponse(
			200,
			"OK",
			"Laporan tindak lanjut dan rujukan berhasil diambil.",
			*result,
		),
	}, nil
}
