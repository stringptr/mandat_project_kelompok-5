package service

import (
	"context"
	"fmt"
	"strings"

	"myproject/internal/model"
	"myproject/internal/repository"

	"github.com/xuri/excelize/v2"
)

// MonitoringService interface untuk business logic
type MonitoringService interface {
	// Pasien operations
	GetPasienList(ctx context.Context, req model.PasienListRequest) (*model.PaginatedResponse[model.PasienListResponse], error)
	GetPasienDetail(ctx context.Context, idPasien int) (*model.PasienDetailResponse, error)
	SearchPasien(ctx context.Context, query string) (*model.PasienSearchResponse, error)
	GetStatistik(ctx context.Context, req model.StatistikRequest) (*model.StatistikResponse, error)
	GetStatistikBulanan(ctx context.Context, req model.StatistikBulananRequest) (*model.StatistikBulananResponse, error)
	GenerateExcel(ctx context.Context, req model.ExportRequest) ([]byte, error)

	// Pemeriksaan operations
	CreatePemeriksaan(ctx context.Context, req model.InputPemeriksaanBody, idPetugasInput int) (*model.HasilPemeriksaanResponse, []model.ErrorItem, error)
	GetPemeriksaanDetail(ctx context.Context, idHasil int) (*model.DetailPemeriksaanResponse, error)
	UpdatePemeriksaan(ctx context.Context, idHasil int, req model.UpdatePemeriksaanBody, idUser int) (*model.UpdatePemeriksaanResponse, []model.ErrorItem, error)
	DeletePemeriksaan(ctx context.Context, idHasil int, idUser int) (string, error)
	VerifikasiPemeriksaan(ctx context.Context, idHasil int, body model.VerifikasiPemeriksaanBody, idVerifikator int, role string) (*model.VerifikasiPemeriksaanResponse, []model.ErrorItem, error)
	GetPemeriksaanPending(ctx context.Context, req model.PemeriksaanPendingRequest) (*model.PaginatedResponse[model.PemeriksaanPendingResponse], error)

	// Imunisasi operations
	GetJadwalImunisasiList(ctx context.Context, req model.JadwalImunisasiListRequest) (*model.PaginatedResponse[model.JadwalImunisasiListResponse], error)
	CreateJadwalImunisasi(ctx context.Context, req model.InputJadwalImunisasiBody, idUser int) (*model.CreateJadwalImunisasiResponse, []model.ErrorItem, error)
	UpdateRealisasiImunisasi(ctx context.Context, idImunisasi int, body model.RealisasiImunisasiBody, idUser int) (*model.RealisasiImunisasiResponse, error)
}

type monitoringService struct {
	repo repository.MonitoringRepository
}

// NewMonitoringService creates new instance
func NewMonitoringService(repo repository.MonitoringRepository) MonitoringService {
	return &monitoringService{repo: repo}
}

// CreatePemeriksaan validates and creates new pemeriksaan
func (s *monitoringService) CreatePemeriksaan(ctx context.Context, req model.InputPemeriksaanBody, idPetugasInput int) (*model.HasilPemeriksaanResponse, []model.ErrorItem, error) {
	// Business validation (AC-02: Business logic di Service)
	var errors []model.ErrorItem

	// Validasi berat badan (ERR-VAL-05)
	if req.BeratBadan < 1 || req.BeratBadan > 30 {
		errors = append(errors, model.ErrorItem{
			Location: "body.berat_badan",
			Message:  model.ErrorMessages[model.ErrValidationOutOfBound],
			Value:    req.BeratBadan,
		})
	}

	// Validasi tinggi badan (ERR-VAL-05)
	if req.TinggiBadan < 40 || req.TinggiBadan > 120 {
		errors = append(errors, model.ErrorItem{
			Location: "body.tinggi_badan",
			Message:  model.ErrorMessages[model.ErrValidationOutOfBound],
			Value:    req.TinggiBadan,
		})
	}

	if len(errors) > 0 {
		return nil, errors, nil
	}

	// Call repository
	result, err := s.repo.CreatePemeriksaan(ctx, req, idPetugasInput)
	if err != nil {
		// Map SP error codes to ErrorItem
		if strings.Contains(err.Error(), "DUPLICATE_SCHEDULE") {
			return nil, []model.ErrorItem{
				{
					Location: "body.id_jadwal_imunisasi",
					Message:  "Jadwal imunisasi ini sudah memiliki data pemeriksaan.",
					Value:    req.IDJadwalImunisasi,
				},
			}, nil
		}
		if strings.Contains(err.Error(), "INVALID_DATA") {
			return nil, []model.ErrorItem{
				{
					Location: "body",
					Message:  model.ErrorMessages[model.ErrValidationOutOfBound],
					Value:    nil,
				},
			}, nil
		}
		return nil, nil, err
	}

	return result, nil, nil
}

// VerifikasiPemeriksaan validates and verifies pemeriksaan (BIDAN only)
func (s *monitoringService) VerifikasiPemeriksaan(ctx context.Context, idHasil int, body model.VerifikasiPemeriksaanBody, idVerifikator int, role string) (*model.VerifikasiPemeriksaanResponse, []model.ErrorItem, error) {
	// Business validation
	var errors []model.ErrorItem

	// Check role BIDAN (ERR-AUTH-03)
	if role != "BIDAN" {
		return nil, []model.ErrorItem{
			{
				Location: "",
				Message:  model.ErrorMessages[model.ErrAuthForbidden],
				Value:    nil,
			},
		}, nil
	}

	// Validasi aksi (ERR-VAL-03)
	if body.Aksi != "setujui" && body.Aksi != "tolak" {
		errors = append(errors, model.ErrorItem{
			Location: "body.aksi",
			Message:  model.ErrorMessages[model.ErrValidationRequired],
			Value:    body.Aksi,
		})
	}

	// Validasi catatan wajib jika aksi = tolak
	if body.Aksi == "tolak" && (body.CatatanVerifikasi == nil || *body.CatatanVerifikasi == "") {
		errors = append(errors, model.ErrorItem{
			Location: "body.catatan_verifikasi",
			Message:  "Catatan verifikasi wajib diisi saat menolak pemeriksaan.",
			Value:    "",
		})
	}

	if len(errors) > 0 {
		return nil, errors, nil
	}

	// Call repository
	result, err := s.repo.VerifikasiPemeriksaan(ctx, idHasil, idVerifikator, body.CatatanVerifikasi)
	if err != nil {
		// Map errors
		if strings.Contains(err.Error(), "NOT_FOUND") {
			return nil, []model.ErrorItem{
				{
					Location: "path.id",
					Message:  model.ErrorMessages[model.ErrDataNotFound],
					Value:    idHasil,
				},
			}, nil
		}
		if strings.Contains(err.Error(), "ALREADY_VERIFIED") {
			return nil, []model.ErrorItem{
				{
					Location: "path.id",
					Message:  "Data pemeriksaan ini sudah pernah diverifikasi.",
					Value:    idHasil,
				},
			}, nil
		}
		return nil, nil, err
	}

	return result, nil, nil
}

// GenerateExcel creates Excel file for export
func (s *monitoringService) GenerateExcel(ctx context.Context, req model.ExportRequest) ([]byte, error) {
	// Get data from repository
	data, err := s.repo.GetAllForExport(ctx, req)
	if err != nil {
		return nil, err
	}

	// Create new Excel file
	f := excelize.NewFile()
	sheetName := "Monitoring Gizi"
	index, err := f.NewSheet(sheetName)
	if err != nil {
		return nil, fmt.Errorf("failed to create sheet: %w", err)
	}

	// Set headers
	headers := []string{"No", "Nama Pasien", "NIK", "Tanggal Pemeriksaan", "BB (kg)", "TB (cm)", "Status Gizi", "Status Stunting", "Status Verifikasi", "Nama Petugas"}
	for i, header := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(sheetName, cell, header)
	}

	// Set data rows
	for i, row := range data {
		rowNum := i + 2
		f.SetCellValue(sheetName, fmt.Sprintf("A%d", rowNum), row.No)
		f.SetCellValue(sheetName, fmt.Sprintf("B%d", rowNum), row.NamaPasien)
		f.SetCellValue(sheetName, fmt.Sprintf("C%d", rowNum), row.NIK)
		f.SetCellValue(sheetName, fmt.Sprintf("D%d", rowNum), row.TanggalPemeriksaan)
		f.SetCellValue(sheetName, fmt.Sprintf("E%d", rowNum), row.BeratBadan)
		f.SetCellValue(sheetName, fmt.Sprintf("F%d", rowNum), row.TinggiBadan)
		f.SetCellValue(sheetName, fmt.Sprintf("G%d", rowNum), row.StatusGizi)
		f.SetCellValue(sheetName, fmt.Sprintf("H%d", rowNum), row.StatusStunting)
		f.SetCellValue(sheetName, fmt.Sprintf("I%d", rowNum), row.StatusVerifikasi)
		f.SetCellValue(sheetName, fmt.Sprintf("J%d", rowNum), row.NamaPetugas)
	}

	f.SetActiveSheet(index)

	// Write to buffer
	buffer, err := f.WriteToBuffer()
	if err != nil {
		return nil, fmt.Errorf("failed to write to buffer: %w", err)
	}

	return buffer.Bytes(), nil
}

// GetPasienList retrieves paginated patient list
func (s *monitoringService) GetPasienList(ctx context.Context, req model.PasienListRequest) (*model.PaginatedResponse[model.PasienListResponse], error) {
	items, total, err := s.repo.GetPasienList(ctx, req)
	if err != nil {
		return nil, err
	}

	response := model.NewPaginatedResponse(
		model.PasienListResponse{Pasien: items},
		req.Page,
		req.PerPage,
		total,
	)

	return &response, nil
}

// GetPasienDetail retrieves detailed patient information
func (s *monitoringService) GetPasienDetail(ctx context.Context, idPasien int) (*model.PasienDetailResponse, error) {
	return s.repo.GetPasienDetail(ctx, idPasien)
}

// SearchPasien searches for patient
func (s *monitoringService) SearchPasien(ctx context.Context, query string) (*model.PasienSearchResponse, error) {
	// Validation
	if query == "" {
		return nil, fmt.Errorf("query empty")
	}
	return s.repo.SearchPasien(ctx, query)
}

// GetStatistik retrieves dashboard statistics
func (s *monitoringService) GetStatistik(ctx context.Context, req model.StatistikRequest) (*model.StatistikResponse, error) {
	return s.repo.GetStatistik(ctx, req)
}

// GetStatistikBulanan retrieves monthly statistics
func (s *monitoringService) GetStatistikBulanan(ctx context.Context, req model.StatistikBulananRequest) (*model.StatistikBulananResponse, error) {
	return s.repo.GetStatistikBulanan(ctx, req)
}

// GetPemeriksaanDetail retrieves detailed examination
func (s *monitoringService) GetPemeriksaanDetail(ctx context.Context, idHasil int) (*model.DetailPemeriksaanResponse, error) {
	return s.repo.GetPemeriksaanDetail(ctx, idHasil)
}

// UpdatePemeriksaan validates and updates examination
func (s *monitoringService) UpdatePemeriksaan(ctx context.Context, idHasil int, req model.UpdatePemeriksaanBody, idUser int) (*model.UpdatePemeriksaanResponse, []model.ErrorItem, error) {
	// Business validation
	var errors []model.ErrorItem

	// Validasi berat badan jika diisi
	if req.BeratBadan != nil && (*req.BeratBadan < 1 || *req.BeratBadan > 30) {
		errors = append(errors, model.ErrorItem{
			Location: "body.berat_badan",
			Message:  model.ErrorMessages[model.ErrValidationOutOfBound],
			Value:    *req.BeratBadan,
		})
	}

	// Validasi tinggi badan jika diisi
	if req.TinggiBadan != nil && (*req.TinggiBadan < 40 || *req.TinggiBadan > 120) {
		errors = append(errors, model.ErrorItem{
			Location: "body.tinggi_badan",
			Message:  model.ErrorMessages[model.ErrValidationOutOfBound],
			Value:    *req.TinggiBadan,
		})
	}

	if len(errors) > 0 {
		return nil, errors, nil
	}

	// Call repository
	result, err := s.repo.UpdatePemeriksaan(ctx, idHasil, req, idUser)
	if err != nil {
		// Map SP error codes
		if strings.Contains(err.Error(), "NOT_FOUND_OR_LOCKED") {
			return nil, []model.ErrorItem{
				{
					Location: "path.id",
					Message:  "Data pemeriksaan yang sudah diverifikasi tidak dapat diubah.",
					Value:    idHasil,
				},
			}, nil
		}
		if strings.Contains(err.Error(), "INVALID_DATA") {
			return nil, []model.ErrorItem{
				{
					Location: "body",
					Message:  model.ErrorMessages[model.ErrValidationOutOfBound],
					Value:    nil,
				},
			}, nil
		}
		return nil, nil, err
	}

	return result, nil, nil
}

// DeletePemeriksaan deletes examination
func (s *monitoringService) DeletePemeriksaan(ctx context.Context, idHasil int, idUser int) (string, error) {
	err := s.repo.DeletePemeriksaan(ctx, idHasil, idUser)
	if err != nil {
		// Map errors
		if strings.Contains(err.Error(), "NOT_FOUND_OR_FORBIDDEN") {
			return "", fmt.Errorf("NOT_FOUND_OR_FORBIDDEN")
		}
		return "", err
	}

	return "Data pemeriksaan berhasil dihapus. Data tindak lanjut yang terkait juga telah dihapus secara permanen.", nil
}

// GetPemeriksaanPending retrieves pending examinations
func (s *monitoringService) GetPemeriksaanPending(ctx context.Context, req model.PemeriksaanPendingRequest) (*model.PaginatedResponse[model.PemeriksaanPendingResponse], error) {
	items, total, err := s.repo.GetPemeriksaanPending(ctx, req)
	if err != nil {
		return nil, err
	}

	response := model.NewPaginatedResponse(
		model.PemeriksaanPendingResponse{PemeriksaanPending: items},
		req.Page,
		req.PerPage,
		total,
	)

	return &response, nil
}

// GetJadwalImunisasiList retrieves paginated immunization schedule
func (s *monitoringService) GetJadwalImunisasiList(ctx context.Context, req model.JadwalImunisasiListRequest) (*model.PaginatedResponse[model.JadwalImunisasiListResponse], error) {
	items, total, err := s.repo.GetJadwalImunisasiList(ctx, req)
	if err != nil {
		return nil, err
	}

	response := model.NewPaginatedResponse(
		model.JadwalImunisasiListResponse{Jadwal: items},
		req.Page,
		req.PerPage,
		total,
	)

	return &response, nil
}

// CreateJadwalImunisasi validates and creates immunization schedule
func (s *monitoringService) CreateJadwalImunisasi(ctx context.Context, req model.InputJadwalImunisasiBody, idUser int) (*model.CreateJadwalImunisasiResponse, []model.ErrorItem, error) {
	// Call repository
	result, err := s.repo.CreateJadwalImunisasi(ctx, req, idUser)
	if err != nil {
		// Map SP error codes
		if strings.Contains(err.Error(), "PATIENT_NOT_FOUND") {
			return nil, []model.ErrorItem{
				{
					Location: "body.id_pasien",
					Message:  "Pasien tidak ditemukan.",
					Value:    req.IDPasien,
				},
			}, nil
		}
		if strings.Contains(err.Error(), "DUPLICATE_SCHEDULE") {
			return nil, []model.ErrorItem{
				{
					Location: "body.tanggal_jadwal",
					Message:  "Jadwal imunisasi dengan vaksin dan tanggal tersebut sudah ada.",
					Value:    req.TanggalJadwal,
				},
			}, nil
		}
		return nil, nil, err
	}

	return result, nil, nil
}

// UpdateRealisasiImunisasi updates immunization realization
func (s *monitoringService) UpdateRealisasiImunisasi(ctx context.Context, idImunisasi int, body model.RealisasiImunisasiBody, idUser int) (*model.RealisasiImunisasiResponse, error) {
	result, err := s.repo.UpdateRealisasiImunisasi(ctx, idImunisasi, body.TanggalRealisasi, idUser)
	if err != nil {
		return nil, err
	}
	return result, nil
}
