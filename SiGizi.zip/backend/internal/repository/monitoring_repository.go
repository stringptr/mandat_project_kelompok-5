package repository

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	"myproject/internal/model"

	"github.com/jackc/pgx/v5/pgxpool"
)

// MonitoringRepository interface untuk database access layer
type MonitoringRepository interface {
	// Pasien operations
	GetPasienList(ctx context.Context, req model.PasienListRequest) ([]model.PasienItem, int, error)
	GetPasienDetail(ctx context.Context, idPasien int) (*model.PasienDetailResponse, error)
	SearchPasien(ctx context.Context, query string) (*model.PasienSearchResponse, error)
	GetStatistik(ctx context.Context, req model.StatistikRequest) (*model.StatistikResponse, error)
	GetStatistikBulanan(ctx context.Context, req model.StatistikBulananRequest) (*model.StatistikBulananResponse, error)
	GetAllForExport(ctx context.Context, req model.ExportRequest) ([]model.ExportRow, error)

	// Pemeriksaan operations
	CreatePemeriksaan(ctx context.Context, req model.InputPemeriksaanBody, idPetugasInput int) (*model.HasilPemeriksaanResponse, error)
	GetPemeriksaanDetail(ctx context.Context, idHasil int) (*model.DetailPemeriksaanResponse, error)
	UpdatePemeriksaan(ctx context.Context, idHasil int, req model.UpdatePemeriksaanBody, idUser int) (*model.UpdatePemeriksaanResponse, error)
	DeletePemeriksaan(ctx context.Context, idHasil int, idUser int) error
	VerifikasiPemeriksaan(ctx context.Context, idHasil int, idVerifikator int, catatan *string) (*model.VerifikasiPemeriksaanResponse, error)
	GetPemeriksaanPending(ctx context.Context, req model.PemeriksaanPendingRequest) ([]model.PemeriksaanPendingItem, int, error)

	// Imunisasi operations
	GetJadwalImunisasiList(ctx context.Context, req model.JadwalImunisasiListRequest) ([]model.JadwalImunisasiItem, int, error)
	CreateJadwalImunisasi(ctx context.Context, req model.InputJadwalImunisasiBody, idUser int) (*model.CreateJadwalImunisasiResponse, error)
	UpdateRealisasiImunisasi(ctx context.Context, idImunisasi int, tanggalRealisasi string, idUser int) (*model.RealisasiImunisasiResponse, error)
}

type monitoringRepository struct {
	db *pgxpool.Pool
}

// NewMonitoringRepository creates new instance
func NewMonitoringRepository(db *pgxpool.Pool) MonitoringRepository {
	return &monitoringRepository{db: db}
}

// GetPasienList retrieves list of patients with filters
func (r *monitoringRepository) GetPasienList(ctx context.Context, req model.PasienListRequest) ([]model.PasienItem, int, error) {
	var conditions []string
	var args []interface{}
	argCounter := 1

	// Base query - join pasien dengan tabel terkait
	baseQuery := `
		SELECT 
			p.id_pasien,
			COALESCE(a.nama_anak, ih.nama_ibu) as nama_pasien,
			COALESCE(ua_anak.nik, ua_ibu.nik) as nik,
			CASE 
				WHEN a.id_anak IS NOT NULL THEN 
					EXTRACT(YEAR FROM AGE(CURRENT_DATE, a.tanggal_lahir_anak))::TEXT || ' tahun'
				WHEN ih.id_ibu_hamil IS NOT NULL THEN 
					EXTRACT(YEAR FROM AGE(CURRENT_DATE, ih.tanggal_lahir))::TEXT || ' tahun'
				ELSE 'N/A'
			END as usia,
			p.jenis_pasien,
			pos.nama_posyandu,
			hp.berat_badan as berat_badan_terakhir,
			hp.tinggi_badan as tinggi_badan_terakhir,
			hp.status_gizi as status_gizi_terakhir,
			hp.status_verifikasi as status_verifikasi_terakhir
		FROM pasien p
		LEFT JOIN anak a ON p.id_anak = a.id_anak
		LEFT JOIN ibu_hamil ih ON p.id_ibu_hamil = ih.id_ibu_hamil
		LEFT JOIN posyandu pos ON p.id_posyandu = pos.id_posyandu
		LEFT JOIN user_account ua_anak ON a.id_wali = ua_anak.id_user
		LEFT JOIN user_account ua_ibu ON ih.id_user = ua_ibu.id_user
		LEFT JOIN LATERAL (
			SELECT berat_badan, tinggi_badan, status_gizi, status_verifikasi
			FROM hasil_pemeriksaan hp2
			JOIN jadwal_imunisasi ji ON hp2.id_jadwal_imunisasi = ji.id_imunisasi
			WHERE ji.id_pasien = p.id_pasien
			ORDER BY hp2.created_at DESC
			LIMIT 1
		) hp ON true
		WHERE 1=1
	`

	// Filter pencarian (nama atau NIK)
	if req.Q != "" {
		conditions = append(conditions, fmt.Sprintf(
			"(LOWER(COALESCE(a.nama_anak, ih.nama_ibu)) LIKE $%d OR LOWER(COALESCE(ua_anak.nik, ua_ibu.nik)) LIKE $%d)",
			argCounter, argCounter,
		))
		args = append(args, "%"+strings.ToLower(req.Q)+"%")
		argCounter++
	}

	// Filter status gizi
	if req.StatusGizi != "" {
		conditions = append(conditions, fmt.Sprintf("hp.status_gizi = $%d", argCounter))
		args = append(args, req.StatusGizi)
		argCounter++
	}

	// Filter posyandu
	if req.IDPosyandu != nil {
		conditions = append(conditions, fmt.Sprintf("p.id_posyandu = $%d", argCounter))
		args = append(args, *req.IDPosyandu)
		argCounter++
	}

	// Gabungkan kondisi WHERE
	if len(conditions) > 0 {
		baseQuery += " AND " + strings.Join(conditions, " AND ")
	}

	// Count total untuk pagination
	countQuery := "SELECT COUNT(*) FROM (" + baseQuery + ") AS count_query"
	var total int
	err := r.db.QueryRow(ctx, countQuery, args...).Scan(&total)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to count pasien: %w", err)
	}

	// Query data dengan pagination
	baseQuery += fmt.Sprintf(" ORDER BY p.id_pasien DESC LIMIT $%d OFFSET $%d", argCounter, argCounter+1)
	args = append(args, req.PerPage, (req.Page-1)*req.PerPage)

	rows, err := r.db.Query(ctx, baseQuery, args...)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to query pasien list: %w", err)
	}
	defer rows.Close()

	var results []model.PasienItem
	for rows.Next() {
		var item model.PasienItem
		err := rows.Scan(
			&item.IDPasien,
			&item.NamaPasien,
			&item.NIK,
			&item.Usia,
			&item.JenisPasien,
			&item.NamaPosyandu,
			&item.BeratBadanTerakhir,
			&item.TinggiBadanTerakhir,
			&item.StatusGiziTerakhir,
			&item.StatusVerifikasiTerakhir,
		)
		if err != nil {
			return nil, 0, fmt.Errorf("failed to scan pasien: %w", err)
		}
		results = append(results, item)
	}

	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("error iterating rows: %w", err)
	}

	return results, total, nil
}

// CreatePemeriksaan calls stored procedure sp__input_pemeriksaan
func (r *monitoringRepository) CreatePemeriksaan(ctx context.Context, req model.InputPemeriksaanBody, idPetugasInput int) (*model.HasilPemeriksaanResponse, error) {
	var pResult, pMessage string
	var pIDHasilPemeriksaan int

	// Default values untuk optional fields
	catatanObs := ""
	if req.CatatanObservasi != nil {
		catatanObs = *req.CatatanObservasi
	}
	rekGizi := ""
	if req.RekomendasiGizi != nil {
		rekGizi = *req.RekomendasiGizi
	}
	catMedis := ""
	if req.CatatanMedis != nil {
		catMedis = *req.CatatanMedis
	}
	jadwalKontrol := sql.NullString{}
	if req.JadwalKontrolBerikutnya != nil {
		jadwalKontrol = sql.NullString{String: *req.JadwalKontrolBerikutnya, Valid: true}
	}
	statusPasien := "Dalam Pemantauan"
	if req.StatusPasien != nil {
		statusPasien = *req.StatusPasien
	}

	query := `CALL sp__input_pemeriksaan($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`
	
	row := r.db.QueryRow(ctx, query,
		idPetugasInput,
		req.IDJadwalImunisasi,
		req.BeratBadan,
		req.TinggiBadan,
		req.LingkarKepala,
		req.TekananDarah,
		catatanObs,
		rekGizi,
		catMedis,
		jadwalKontrol,
		statusPasien,
	)

	err := row.Scan(&pResult, &pMessage, &pIDHasilPemeriksaan)
	if err != nil {
		return nil, fmt.Errorf("SP execution failed: %w", err)
	}

	// Map result codes to response
	if pResult != "SUCCESS" {
		return nil, fmt.Errorf("SP returned: %s - %s", pResult, pMessage)
	}

	// Fetch created record details
	return &model.HasilPemeriksaanResponse{
		IDHasilPemeriksaan: pIDHasilPemeriksaan,
		StatusStunting:     "Normal", // Will be calculated by SP
		StatusGizi:         "Gizi Baik", // Will be calculated by SP
		StatusPasien:       statusPasien,
		CreatedAt:          time.Now(),
	}, nil
}

// GetPasienDetail retrieves detailed patient information
func (r *monitoringRepository) GetPasienDetail(ctx context.Context, idPasien int) (*model.PasienDetailResponse, error) {
	// Query detail pasien
	detailQuery := `
		SELECT 
			p.id_pasien,
			COALESCE(a.nama_anak, ih.nama_ibu) as nama_pasien,
			COALESCE(ua_anak.nik, ua_ibu.nik) as nik,
			COALESCE(a.tanggal_lahir_anak, ih.tanggal_lahir)::TEXT as tanggal_lahir,
			CASE 
				WHEN a.id_anak IS NOT NULL THEN 
					EXTRACT(YEAR FROM AGE(CURRENT_DATE, a.tanggal_lahir_anak))::TEXT || ' tahun'
				WHEN ih.id_ibu_hamil IS NOT NULL THEN 
					EXTRACT(YEAR FROM AGE(CURRENT_DATE, ih.tanggal_lahir))::TEXT || ' tahun'
				ELSE 'N/A'
			END as usia,
			p.jenis_pasien,
			pos.nama_posyandu
		FROM pasien p
		LEFT JOIN anak a ON p.id_anak = a.id_anak
		LEFT JOIN ibu_hamil ih ON p.id_ibu_hamil = ih.id_ibu_hamil
		LEFT JOIN posyandu pos ON p.id_posyandu = pos.id_posyandu
		LEFT JOIN user_account ua_anak ON a.id_wali = ua_anak.id_user
		LEFT JOIN user_account ua_ibu ON ih.id_user = ua_ibu.id_user
		WHERE p.id_pasien = $1
	`

	var detail model.PasienDetailResponse
	err := r.db.QueryRow(ctx, detailQuery, idPasien).Scan(
		&detail.IDPasien,
		&detail.NamaPasien,
		&detail.NIK,
		&detail.TanggalLahir,
		&detail.Usia,
		&detail.JenisPasien,
		&detail.NamaPosyandu,
	)
	if err != nil {
		return nil, fmt.Errorf("failed to get pasien detail: %w", err)
	}

	// Query riwayat pemeriksaan
	riwayatQuery := `
		SELECT 
			hp.id_hasil_pemeriksaan,
			TO_CHAR(hp.created_at, 'YYYY-MM-DD') as tanggal,
			hp.berat_badan,
			hp.tinggi_badan,
			hp.status_gizi,
			hp.status_stunting,
			hp.status_verifikasi
		FROM hasil_pemeriksaan hp
		JOIN jadwal_imunisasi ji ON hp.id_jadwal_imunisasi = ji.id_imunisasi
		WHERE ji.id_pasien = $1
		ORDER BY hp.created_at DESC
		LIMIT 10
	`

	rows, err := r.db.Query(ctx, riwayatQuery, idPasien)
	if err != nil {
		return nil, fmt.Errorf("failed to get riwayat pemeriksaan: %w", err)
	}
	defer rows.Close()

	var riwayat []model.RiwayatPemeriksaanItem
	for rows.Next() {
		var item model.RiwayatPemeriksaanItem
		err := rows.Scan(
			&item.IDHasilPemeriksaan,
			&item.Tanggal,
			&item.BeratBadan,
			&item.TinggiBadan,
			&item.StatusGizi,
			&item.StatusStunting,
			&item.StatusVerifikasi,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan riwayat: %w", err)
		}
		riwayat = append(riwayat, item)
	}

	detail.RiwayatPemeriksaan = riwayat
	return &detail, nil
}

// SearchPasien searches for patient by NIK or name
func (r *monitoringRepository) SearchPasien(ctx context.Context, query string) (*model.PasienSearchResponse, error) {
	searchQuery := `
		SELECT 
			p.id_pasien,
			COALESCE(ua_anak.nik, ua_ibu.nik) as nik,
			COALESCE(a.nama_anak, ih.nama_ibu) as nama,
			COALESCE(a.tanggal_lahir_anak, ih.tanggal_lahir)::TEXT as tanggal_lahir,
			pos.nama_posyandu
		FROM pasien p
		LEFT JOIN anak a ON p.id_anak = a.id_anak
		LEFT JOIN ibu_hamil ih ON p.id_ibu_hamil = ih.id_ibu_hamil
		LEFT JOIN posyandu pos ON p.id_posyandu = pos.id_posyandu
		LEFT JOIN user_account ua_anak ON a.id_wali = ua_anak.id_user
		LEFT JOIN user_account ua_ibu ON ih.id_user = ua_ibu.id_user
		WHERE LOWER(COALESCE(a.nama_anak, ih.nama_ibu)) LIKE $1
		   OR LOWER(COALESCE(ua_anak.nik, ua_ibu.nik)) LIKE $1
		LIMIT 1
	`

	var result model.PasienSearchResponse
	err := r.db.QueryRow(ctx, searchQuery, "%"+strings.ToLower(query)+"%").Scan(
		&result.IDPasien,
		&result.NIK,
		&result.Nama,
		&result.TanggalLahir,
		&result.NamaPosyandu,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("pasien tidak ditemukan")
		}
		return nil, fmt.Errorf("failed to search pasien: %w", err)
	}

	return &result, nil
}

// GetStatistik retrieves dashboard statistics
func (r *monitoringRepository) GetStatistik(ctx context.Context, req model.StatistikRequest) (*model.StatistikResponse, error) {
	var conditions []string
	var args []interface{}
	argCounter := 1

	// Base query untuk agregasi statistik
	query := `
		SELECT 
			COUNT(CASE WHEN hp.status_stunting IN ('Stunting', 'Sangat Pendek') THEN 1 END) as total_stunting,
			COUNT(CASE WHEN hp.status_gizi IN ('Risiko Gizi Lebih', 'Gizi Lebih', 'Obesitas') THEN 1 END) as total_risiko_gizi_lebih,
			COUNT(CASE WHEN hp.status_gizi = 'Gizi Baik' THEN 1 END) as total_gizi_baik,
			COUNT(CASE WHEN hp.status_gizi = 'Gizi Kurang' THEN 1 END) as total_gizi_kurang,
			COUNT(CASE WHEN hp.status_gizi = 'Gizi Buruk' THEN 1 END) as total_gizi_buruk,
			COUNT(DISTINCT ji.id_pasien) as total_pasien
		FROM hasil_pemeriksaan hp
		JOIN jadwal_imunisasi ji ON hp.id_jadwal_imunisasi = ji.id_imunisasi
		JOIN pasien p ON ji.id_pasien = p.id_pasien
		WHERE 1=1
	`

	// Filter posyandu
	if req.IDPosyandu != nil {
		conditions = append(conditions, fmt.Sprintf("p.id_posyandu = $%d", argCounter))
		args = append(args, *req.IDPosyandu)
		argCounter++
	}

	// Filter bulan
	if req.Bulan != nil {
		conditions = append(conditions, fmt.Sprintf("EXTRACT(MONTH FROM hp.created_at) = $%d", argCounter))
		args = append(args, *req.Bulan)
		argCounter++
	}

	// Filter tahun
	if req.Tahun != nil {
		conditions = append(conditions, fmt.Sprintf("EXTRACT(YEAR FROM hp.created_at) = $%d", argCounter))
		args = append(args, *req.Tahun)
		argCounter++
	}

	// Gabungkan kondisi
	if len(conditions) > 0 {
		query += " AND " + strings.Join(conditions, " AND ")
	}

	var stats model.StatistikResponse
	err := r.db.QueryRow(ctx, query, args...).Scan(
		&stats.TotalStuntingTerdeteksi,
		&stats.TotalRisikoGiziLebih,
		&stats.TotalGiziBaik,
		&stats.TotalGiziKurang,
		&stats.TotalGiziBuruk,
		&stats.TotalPasien,
	)

	if err != nil {
		return nil, fmt.Errorf("failed to get statistik: %w", err)
	}

	return &stats, nil
}

// GetStatistikBulanan retrieves monthly growth trend statistics
func (r *monitoringRepository) GetStatistikBulanan(ctx context.Context, req model.StatistikBulananRequest) (*model.StatistikBulananResponse, error) {
	tahun := time.Now().Year()
	if req.Tahun != nil {
		tahun = *req.Tahun
	}

	var conditions []string
	var args []interface{}
	args = append(args, tahun)
	argCounter := 2

	// Base query untuk tren bulanan
	trendQuery := `
		SELECT 
			EXTRACT(MONTH FROM hp.created_at)::INT as bulan,
			TO_CHAR(hp.created_at, 'Month') as nama_bulan,
			COUNT(CASE WHEN hp.status_stunting IN ('Stunting', 'Sangat Pendek') THEN 1 END) as total_stunting,
			COUNT(CASE WHEN hp.status_gizi = 'Gizi Buruk' THEN 1 END) as total_gizi_buruk,
			COUNT(CASE WHEN hp.status_gizi = 'Gizi Baik' THEN 1 END) as total_gizi_baik,
			COUNT(*) as total_pemeriksaan
		FROM hasil_pemeriksaan hp
		JOIN jadwal_imunisasi ji ON hp.id_jadwal_imunisasi = ji.id_imunisasi
		JOIN pasien p ON ji.id_pasien = p.id_pasien
		WHERE EXTRACT(YEAR FROM hp.created_at) = $1
	`

	// Filter posyandu
	if req.IDPosyandu != nil {
		conditions = append(conditions, fmt.Sprintf("p.id_posyandu = $%d", argCounter))
		args = append(args, *req.IDPosyandu)
		argCounter++
	}

	if len(conditions) > 0 {
		trendQuery += " AND " + strings.Join(conditions, " AND ")
	}

	trendQuery += " GROUP BY EXTRACT(MONTH FROM hp.created_at), TO_CHAR(hp.created_at, 'Month') ORDER BY bulan"

	rows, err := r.db.Query(ctx, trendQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to get statistik bulanan: %w", err)
	}
	defer rows.Close()

	var trenBulanan []model.TrenBulananItem
	for rows.Next() {
		var item model.TrenBulananItem
		err := rows.Scan(
			&item.Bulan,
			&item.NamaBulan,
			&item.TotalStunting,
			&item.TotalGiziBuruk,
			&item.TotalGiziBaik,
			&item.TotalPemeriksaan,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan tren bulanan: %w", err)
		}
		trenBulanan = append(trenBulanan, item)
	}

	// Query ringkasan tahunan
	ringkasanQuery := `
		SELECT 
			COUNT(DISTINCT CASE WHEN p.jenis_pasien = 'Ibu Hamil' THEN p.id_pasien END) as total_ibu,
			COUNT(CASE WHEN hp.status_stunting IN ('Stunting', 'Sangat Pendek') THEN 1 END) as total_stunting,
			COUNT(CASE WHEN hp.status_gizi = 'Gizi Buruk' THEN 1 END) as total_gizi_buruk,
			COUNT(*) as total_data
		FROM hasil_pemeriksaan hp
		JOIN jadwal_imunisasi ji ON hp.id_jadwal_imunisasi = ji.id_imunisasi
		JOIN pasien p ON ji.id_pasien = p.id_pasien
		WHERE EXTRACT(YEAR FROM hp.created_at) = $1
	`

	ringkasanArgs := []interface{}{tahun}
	if req.IDPosyandu != nil {
		ringkasanQuery += " AND p.id_posyandu = $2"
		ringkasanArgs = append(ringkasanArgs, *req.IDPosyandu)
	}

	var ringkasan model.RingkasanTahunan
	err = r.db.QueryRow(ctx, ringkasanQuery, ringkasanArgs...).Scan(
		&ringkasan.TotalIbu,
		&ringkasan.TotalStunting,
		&ringkasan.TotalGiziBuruk,
		&ringkasan.TotalData,
	)
	if err != nil {
		return nil, fmt.Errorf("failed to get ringkasan tahunan: %w", err)
	}

	return &model.StatistikBulananResponse{
		Tahun:       tahun,
		Ringkasan:   ringkasan,
		TrenBulanan: trenBulanan,
	}, nil
}

// GetAllForExport retrieves all patient data for Excel export (no pagination)
func (r *monitoringRepository) GetAllForExport(ctx context.Context, req model.ExportRequest) ([]model.ExportRow, error) {
	var conditions []string
	var args []interface{}
	argCounter := 1

	query := `
		SELECT 
			ROW_NUMBER() OVER (ORDER BY hp.created_at DESC) as no,
			COALESCE(a.nama_anak, ih.nama_ibu) as nama_pasien,
			COALESCE(ua_anak.nik, ua_ibu.nik) as nik,
			TO_CHAR(hp.created_at, 'YYYY-MM-DD') as tanggal_pemeriksaan,
			hp.berat_badan,
			hp.tinggi_badan,
			hp.status_gizi,
			hp.status_stunting,
			CASE WHEN hp.status_verifikasi THEN 'Terverifikasi' ELSE 'Belum Verifikasi' END as status_verifikasi,
			COALESCE(ua_petugas.nama, 'N/A') as nama_petugas
		FROM hasil_pemeriksaan hp
		JOIN jadwal_imunisasi ji ON hp.id_jadwal_imunisasi = ji.id_imunisasi
		JOIN pasien p ON ji.id_pasien = p.id_pasien
		LEFT JOIN anak a ON p.id_anak = a.id_anak
		LEFT JOIN ibu_hamil ih ON p.id_ibu_hamil = ih.id_ibu_hamil
		LEFT JOIN user_account ua_anak ON a.id_wali = ua_anak.id_user
		LEFT JOIN user_account ua_ibu ON ih.id_user = ua_ibu.id_user
		LEFT JOIN user_account ua_petugas ON hp.id_petugas_input = ua_petugas.id_user
		WHERE 1=1
	`

	// Filter status gizi
	if req.StatusGizi != nil {
		conditions = append(conditions, fmt.Sprintf("hp.status_gizi = $%d", argCounter))
		args = append(args, *req.StatusGizi)
		argCounter++
	}

	// Filter posyandu
	if req.IDPosyandu != nil {
		conditions = append(conditions, fmt.Sprintf("p.id_posyandu = $%d", argCounter))
		args = append(args, *req.IDPosyandu)
		argCounter++
	}

	// Filter bulan
	if req.Bulan != nil {
		conditions = append(conditions, fmt.Sprintf("EXTRACT(MONTH FROM hp.created_at) = $%d", argCounter))
		args = append(args, *req.Bulan)
		argCounter++
	}

	// Filter tahun
	if req.Tahun != nil {
		conditions = append(conditions, fmt.Sprintf("EXTRACT(YEAR FROM hp.created_at) = $%d", argCounter))
		args = append(args, *req.Tahun)
		argCounter++
	}

	if len(conditions) > 0 {
		query += " AND " + strings.Join(conditions, " AND ")
	}

	query += " ORDER BY hp.created_at DESC"

	rows, err := r.db.Query(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to query export data: %w", err)
	}
	defer rows.Close()

	var results []model.ExportRow
	for rows.Next() {
		var row model.ExportRow
		err := rows.Scan(
			&row.No,
			&row.NamaPasien,
			&row.NIK,
			&row.TanggalPemeriksaan,
			&row.BeratBadan,
			&row.TinggiBadan,
			&row.StatusGizi,
			&row.StatusStunting,
			&row.StatusVerifikasi,
			&row.NamaPetugas,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan export row: %w", err)
		}
		results = append(results, row)
	}

	return results, nil
}

// GetPemeriksaanDetail retrieves detailed examination information
func (r *monitoringRepository) GetPemeriksaanDetail(ctx context.Context, idHasil int) (*model.DetailPemeriksaanResponse, error) {
	query := `
		SELECT 
			hp.id_hasil_pemeriksaan,
			p.id_pasien,
			COALESCE(a.nama_anak, ih.nama_ibu) as nama_pasien,
			hp.berat_badan,
			hp.tinggi_badan,
			hp.lingkar_kepala,
			hp.tekanan_darah,
			hp.status_gizi,
			hp.status_stunting,
			hp.status_pasien,
			hp.catatan_observasi,
			hp.rekomendasi_gizi,
			hp.catatan_medis,
			TO_CHAR(hp.jadwal_kontrol_berikutnya, 'YYYY-MM-DD') as jadwal_kontrol,
			hp.status_verifikasi,
			hp.catatan_verifikasi
		FROM hasil_pemeriksaan hp
		JOIN jadwal_imunisasi ji ON hp.id_jadwal_imunisasi = ji.id_imunisasi
		JOIN pasien p ON ji.id_pasien = p.id_pasien
		LEFT JOIN anak a ON p.id_anak = a.id_anak
		LEFT JOIN ibu_hamil ih ON p.id_ibu_hamil = ih.id_ibu_hamil
		WHERE hp.id_hasil_pemeriksaan = $1
	`

	var detail model.DetailPemeriksaanResponse
	var catatanObs, rekGizi, catMedis, jadwalKontrol, catatanVerif sql.NullString

	err := r.db.QueryRow(ctx, query, idHasil).Scan(
		&detail.IDHasilPemeriksaan,
		&detail.Pasien.IDPasien,
		&detail.Pasien.Nama,
		&detail.Antropometri.BeratBadan,
		&detail.Antropometri.TinggiBadan,
		&detail.Antropometri.LingkarKepala,
		&detail.Antropometri.TekananDarah,
		&detail.StatusKesehatan.StatusGizi,
		&detail.StatusKesehatan.StatusStunting,
		&detail.StatusKesehatan.StatusPasien,
		&catatanObs,
		&rekGizi,
		&catMedis,
		&jadwalKontrol,
		&detail.StatusVerifikasi,
		&catatanVerif,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("pemeriksaan tidak ditemukan")
		}
		return nil, fmt.Errorf("failed to get pemeriksaan detail: %w", err)
	}

	// Map nullable fields
	if catatanObs.Valid {
		detail.CatatanObservasi = &catatanObs.String
	}
	if rekGizi.Valid {
		detail.RekomendasiGizi = &rekGizi.String
	}
	if catMedis.Valid {
		detail.CatatanMedis = &catMedis.String
	}
	if jadwalKontrol.Valid {
		detail.JadwalKontrolBerikutnya = &jadwalKontrol.String
	}
	if catatanVerif.Valid {
		detail.CatatanVerifikasi = &catatanVerif.String
	}

	return &detail, nil
}

// UpdatePemeriksaan calls stored procedure sp__update_pemeriksaan
func (r *monitoringRepository) UpdatePemeriksaan(ctx context.Context, idHasil int, req model.UpdatePemeriksaanBody, idUser int) (*model.UpdatePemeriksaanResponse, error) {
	var pResult, pMessage string

	// Build parameters with optional values
	beratBadan := sql.NullFloat64{}
	if req.BeratBadan != nil {
		beratBadan = sql.NullFloat64{Float64: *req.BeratBadan, Valid: true}
	}
	tinggiBadan := sql.NullFloat64{}
	if req.TinggiBadan != nil {
		tinggiBadan = sql.NullFloat64{Float64: *req.TinggiBadan, Valid: true}
	}
	lingkarKepala := sql.NullFloat64{}
	if req.LingkarKepala != nil {
		lingkarKepala = sql.NullFloat64{Float64: *req.LingkarKepala, Valid: true}
	}
	tekananDarah := sql.NullString{}
	if req.TekananDarah != nil {
		tekananDarah = sql.NullString{String: *req.TekananDarah, Valid: true}
	}
	catatanObs := sql.NullString{}
	if req.CatatanObservasi != nil {
		catatanObs = sql.NullString{String: *req.CatatanObservasi, Valid: true}
	}
	rekGizi := sql.NullString{}
	if req.RekomendasiGizi != nil {
		rekGizi = sql.NullString{String: *req.RekomendasiGizi, Valid: true}
	}
	catMedis := sql.NullString{}
	if req.CatatanMedis != nil {
		catMedis = sql.NullString{String: *req.CatatanMedis, Valid: true}
	}
	jadwalKontrol := sql.NullString{}
	if req.JadwalKontrolBerikutnya != nil {
		jadwalKontrol = sql.NullString{String: *req.JadwalKontrolBerikutnya, Valid: true}
	}

	query := `CALL sp__update_pemeriksaan($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`

	row := r.db.QueryRow(ctx, query,
		idHasil,
		beratBadan,
		tinggiBadan,
		lingkarKepala,
		tekananDarah,
		catatanObs,
		rekGizi,
		catMedis,
		jadwalKontrol,
		idUser,
	)

	err := row.Scan(&pResult, &pMessage)
	if err != nil {
		return nil, fmt.Errorf("SP execution failed: %w", err)
	}

	if pResult != "SUCCESS" {
		return nil, fmt.Errorf("SP returned: %s - %s", pResult, pMessage)
	}

	return &model.UpdatePemeriksaanResponse{
		IDHasilPemeriksaan: idHasil,
		StatusGiziBaru:     "Gizi Baik", // Will be recalculated by SP
		UpdatedAt:          time.Now(),
	}, nil
}

// DeletePemeriksaan calls stored procedure sp__delete_pemeriksaan
func (r *monitoringRepository) DeletePemeriksaan(ctx context.Context, idHasil int, idUser int) error {
	var pResult, pMessage string

	query := `CALL sp__delete_pemeriksaan($1, $2)`

	row := r.db.QueryRow(ctx, query, idHasil, idUser)

	err := row.Scan(&pResult, &pMessage)
	if err != nil {
		return fmt.Errorf("SP execution failed: %w", err)
	}

	if pResult != "SUCCESS" {
		return fmt.Errorf("SP returned: %s - %s", pResult, pMessage)
	}

	return nil
}

// VerifikasiPemeriksaan verifies examination with function call
func (r *monitoringRepository) VerifikasiPemeriksaan(ctx context.Context, idHasil int, idVerifikator int, catatan *string) (*model.VerifikasiPemeriksaanResponse, error) {
	// First, call fn__verivikasi_pemeriksaan to check status
	var fnResult string
	queryFn := `SELECT fn__verivikasi_pemeriksaan($1, $2, $3)`
	
	catatanVal := ""
	if catatan != nil {
		catatanVal = *catatan
	}

	err := r.db.QueryRow(ctx, queryFn, idHasil, idVerifikator, catatanVal).Scan(&fnResult)
	if err != nil {
		return nil, fmt.Errorf("function call failed: %w", err)
	}

	if fnResult == "NOT_FOUND" {
		return nil, fmt.Errorf("NOT_FOUND")
	}
	if fnResult == "ALREADY_VERIFIED" {
		return nil, fmt.Errorf("ALREADY_VERIFIED")
	}

	// If READY or WARNING, proceed with UPDATE
	queryUpdate := `
		UPDATE hasil_pemeriksaan
		SET status_verifikasi = TRUE,
		    id_verifikator = $1,
		    catatan_verifikasi = $2,
		    updated_at = NOW()
		WHERE id_hasil_pemeriksaan = $3
	`
	_, err = r.db.Exec(ctx, queryUpdate, idVerifikator, catatan, idHasil)
	if err != nil {
		return nil, fmt.Errorf("update failed: %w", err)
	}

	return &model.VerifikasiPemeriksaanResponse{
		IDHasilPemeriksaan: idHasil,
		DiverifikasiOleh:   idVerifikator,
		StatusVerifikasi:   "Aktif",
		CatatanVerifikasi:  catatan,
	}, nil
}

// GetPemeriksaanPending retrieves unverified examinations using view
func (r *monitoringRepository) GetPemeriksaanPending(ctx context.Context, req model.PemeriksaanPendingRequest) ([]model.PemeriksaanPendingItem, int, error) {
	// Count total
	countQuery := `
		SELECT COUNT(*)
		FROM hasil_pemeriksaan hp
		WHERE hp.status_verifikasi = FALSE
	`

	var total int
	err := r.db.QueryRow(ctx, countQuery).Scan(&total)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to count pending pemeriksaan: %w", err)
	}

	// Query data dengan pagination
	query := `
		SELECT 
			hp.id_hasil_pemeriksaan,
			COALESCE(a.nama_anak, ih.nama_ibu) as nama_pasien,
			ua_petugas.nama as diinput_oleh,
			TO_CHAR(hp.created_at, 'YYYY-MM-DD') as tanggal_input,
			hp.status_gizi,
			hp.status_stunting
		FROM hasil_pemeriksaan hp
		JOIN jadwal_imunisasi ji ON hp.id_jadwal_imunisasi = ji.id_imunisasi
		JOIN pasien p ON ji.id_pasien = p.id_pasien
		LEFT JOIN anak a ON p.id_anak = a.id_anak
		LEFT JOIN ibu_hamil ih ON p.id_ibu_hamil = ih.id_ibu_hamil
		JOIN user_account ua_petugas ON hp.id_petugas_input = ua_petugas.id_user
		WHERE hp.status_verifikasi = FALSE
		ORDER BY hp.created_at DESC
		LIMIT $1 OFFSET $2
	`

	offset := (req.Page - 1) * req.PerPage
	rows, err := r.db.Query(ctx, query, req.PerPage, offset)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to query pending pemeriksaan: %w", err)
	}
	defer rows.Close()

	var results []model.PemeriksaanPendingItem
	for rows.Next() {
		var item model.PemeriksaanPendingItem
		err := rows.Scan(
			&item.IDHasilPemeriksaan,
			&item.NamaPasien,
			&item.DiinputOleh,
			&item.TanggalInput,
			&item.StatusGizi,
			&item.StatusStunting,
		)
		if err != nil {
			return nil, 0, fmt.Errorf("failed to scan pending item: %w", err)
		}
		results = append(results, item)
	}

	return results, total, nil
}

// GetJadwalImunisasiList retrieves immunization schedule list using view
func (r *monitoringRepository) GetJadwalImunisasiList(ctx context.Context, req model.JadwalImunisasiListRequest) ([]model.JadwalImunisasiItem, int, error) {
	var conditions []string
	var args []interface{}
	argCounter := 1

	baseQuery := `
		SELECT 
			ji.id_imunisasi,
			COALESCE(a.nama_anak, ih.nama_ibu) as nama_pasien,
			ji.nama_vaksin,
			TO_CHAR(ji.tanggal_jadwal, 'YYYY-MM-DD') as tanggal_jadwal,
			ji.status_imunisasi
		FROM jadwal_imunisasi ji
		JOIN pasien p ON ji.id_pasien = p.id_pasien
		LEFT JOIN anak a ON p.id_anak = a.id_anak
		LEFT JOIN ibu_hamil ih ON p.id_ibu_hamil = ih.id_ibu_hamil
		WHERE 1=1
	`

	// Filter by pasien
	if req.IDPasien != nil {
		conditions = append(conditions, fmt.Sprintf("ji.id_pasien = $%d", argCounter))
		args = append(args, *req.IDPasien)
		argCounter++
	}

	if len(conditions) > 0 {
		baseQuery += " AND " + strings.Join(conditions, " AND ")
	}

	// Count total
	countQuery := "SELECT COUNT(*) FROM (" + baseQuery + ") AS count_query"
	var total int
	err := r.db.QueryRow(ctx, countQuery, args...).Scan(&total)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to count jadwal imunisasi: %w", err)
	}

	// Query data dengan pagination
	baseQuery += fmt.Sprintf(" ORDER BY ji.tanggal_jadwal DESC LIMIT $%d OFFSET $%d", argCounter, argCounter+1)
	args = append(args, req.PerPage, (req.Page-1)*req.PerPage)

	rows, err := r.db.Query(ctx, baseQuery, args...)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to query jadwal imunisasi: %w", err)
	}
	defer rows.Close()

	var results []model.JadwalImunisasiItem
	for rows.Next() {
		var item model.JadwalImunisasiItem
		err := rows.Scan(
			&item.IDImunisasi,
			&item.NamaPasien,
			&item.NamaVaksin,
			&item.TanggalJadwal,
			&item.StatusImunisasi,
		)
		if err != nil {
			return nil, 0, fmt.Errorf("failed to scan jadwal imunisasi: %w", err)
		}
		results = append(results, item)
	}

	return results, total, nil
}

// CreateJadwalImunisasi calls stored procedure sp__input_jadwal_imunisasi
func (r *monitoringRepository) CreateJadwalImunisasi(ctx context.Context, req model.InputJadwalImunisasiBody, idUser int) (*model.CreateJadwalImunisasiResponse, error) {
	var pResult, pMessage string
	var pIDImunisasi int

	query := `CALL sp__input_jadwal_imunisasi($1, $2, $3, $4)`

	row := r.db.QueryRow(ctx, query,
		req.IDPasien,
		req.NamaVaksin,
		req.TanggalJadwal,
		idUser,
	)

	err := row.Scan(&pResult, &pMessage, &pIDImunisasi)
	if err != nil {
		return nil, fmt.Errorf("SP execution failed: %w", err)
	}

	if pResult != "SUCCESS" {
		return nil, fmt.Errorf("SP returned: %s - %s", pResult, pMessage)
	}

	return &model.CreateJadwalImunisasiResponse{
		IDImunisasi:     pIDImunisasi,
		NamaVaksin:      req.NamaVaksin,
		TanggalJadwal:   req.TanggalJadwal,
		StatusImunisasi: "Belum",
	}, nil
}

// UpdateRealisasiImunisasi updates immunization realization
func (r *monitoringRepository) UpdateRealisasiImunisasi(ctx context.Context, idImunisasi int, tanggalRealisasi string, idUser int) (*model.RealisasiImunisasiResponse, error) {
	query := `
		UPDATE jadwal_imunisasi
		SET tanggal_realisasi = $1,
		    status_imunisasi = 'Sudah',
		    updated_at = NOW()
		WHERE id_imunisasi = $2
	`

	result, err := r.db.Exec(ctx, query, tanggalRealisasi, idImunisasi)
	if err != nil {
		return nil, fmt.Errorf("update failed: %w", err)
	}

	rowsAffected := result.RowsAffected()
	if rowsAffected == 0 {
		return nil, fmt.Errorf("NOT_FOUND")
	}

	return &model.RealisasiImunisasiResponse{
		IDImunisasi:      idImunisasi,
		StatusImunisasi:  "Sudah",
		TanggalRealisasi: tanggalRealisasi,
	}, nil
}
