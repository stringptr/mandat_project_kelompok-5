package model

import "time"

// ============================================================================
// REQUEST STRUCTS (Huma Input)
// ============================================================================

// PasienTindakLanjutListRequest untuk GET /api/v1/tindak-lanjut/pasien
type PasienTindakLanjutListRequest struct {
	Page          int    `query:"page" minimum:"1" default:"1"`
	PerPage       int    `query:"per_page" minimum:"1" maximum:"100" default:"15"`
	Q             string `query:"q"`                                                                                                         // Nama pasien (opsional)
	StatusPasien  string `query:"status_pasien" enum:"Dalam Pemantauan,Membaik,Perlu Rujukan,Selesai Pemantauan"`                           // Filter ENUM (opsional)
}

// CreateTindakLanjutBody untuk POST /api/v1/tindak-lanjut
type CreateTindakLanjutBody struct {
	IDHasilPemeriksaan int     `json:"id_hasil_pemeriksaan" minimum:"1" required:"true" doc:"ID Hasil Pemeriksaan yang menjadi dasar tindak lanjut"`
	JenisTindakan      string  `json:"jenis_tindakan" required:"true" enum:"Konseling Gizi,Jadwal Ulang Pemeriksaan,Rujukan Rumah Sakit,Rujukan Puskesmas" doc:"Jenis tindakan yang akan dilakukan"`
	CatatanMedis       *string `json:"catatan_medis,omitempty" maxLength:"1000" doc:"Catatan medis dari bidan (opsional)"`
	Rekomendasi        *string `json:"rekomendasi,omitempty" maxLength:"1000" doc:"Rekomendasi tindakan lanjutan (opsional)"`
	JadwalKontrol      *string `json:"jadwal_kontrol,omitempty" format:"date" doc:"Tanggal jadwal kontrol berikutnya dalam format YYYY-MM-DD (opsional)"`
	AlasanRujukan      *string `json:"alasan_rujukan,omitempty" maxLength:"1000" doc:"Alasan rujukan, wajib diisi jika jenis_tindakan adalah rujukan"`
	IDFaskes           *int    `json:"id_faskes,omitempty" minimum:"1" doc:"ID Fasilitas Kesehatan tujuan rujukan, wajib diisi jika jenis_tindakan adalah rujukan"`
}

// UpdateStatusRujukanBody untuk PATCH /api/v1/rujukan/{id}/status
type UpdateStatusRujukanBody struct {
	StatusRujukan string `json:"status_rujukan" required:"true" enum:"Menunggu Konfirmasi,Diproses,Diterima,Selesai" doc:"Status rujukan yang baru"`
}

// StatusTindakLanjutListRequest untuk GET /api/v1/tindak-lanjut/status
type StatusTindakLanjutListRequest struct {
	Page          int    `query:"page" minimum:"1" default:"1"`
	PerPage       int    `query:"per_page" minimum:"1" maximum:"100" default:"15"`
	StatusRujukan string `query:"status_rujukan" enum:"Menunggu Konfirmasi,Diproses,Diterima,Selesai"` // Filter ENUM (opsional)
}

// LaporanTindakLanjutRequest untuk GET /api/v1/laporan/tindak-lanjut
type LaporanTindakLanjutRequest struct {
	Bulan      *int `query:"bulan" minimum:"1" maximum:"12" doc:"Bulan laporan (1-12), opsional"`
	Tahun      *int `query:"tahun" minimum:"2020" maximum:"2100" doc:"Tahun laporan, opsional, default tahun berjalan"`
	IDPosyandu *int `query:"id_posyandu" minimum:"1" doc:"ID Posyandu untuk filter wilayah, opsional"`
}

// ============================================================================
// RESPONSE STRUCTS (Huma Output)
// ============================================================================

// PasienTindakLanjutItem representasi satu item pasien yang memerlukan tindak lanjut
type PasienTindakLanjutItem struct {
	IDPasien            int    `json:"id_pasien"`
	NamaPasien          string `json:"nama_pasien"`
	StatusGizi          string `json:"status_gizi"`
	StatusPasien        string `json:"status_pasien"`
	TanggalPemeriksaan  string `json:"tanggal_pemeriksaan"` // Format: YYYY-MM-DD
}

// PasienTindakLanjutListResponse wrapper untuk list pasien dengan pagination
type PasienTindakLanjutListResponse struct {
	Pasien []PasienTindakLanjutItem `json:"pasien"`
}

// HasilMonitoringTerakhir nested struct untuk hasil monitoring terakhir pasien
type HasilMonitoringTerakhir struct {
	StatusGizi     string  `json:"status_gizi"`
	StatusStunting string  `json:"status_stunting"`
	Catatan        *string `json:"catatan,omitempty"`
}

// RiwayatPemeriksaanTindakLanjut representasi satu item riwayat pemeriksaan untuk tindak lanjut
type RiwayatPemeriksaanTindakLanjut struct {
	Tanggal        string  `json:"tanggal"` // Format: YYYY-MM-DD
	BeratBadan     float64 `json:"berat_badan"`
	TinggiBadan    float64 `json:"tinggi_badan"`
	StatusGizi     string  `json:"status_gizi"`
	StatusStunting string  `json:"status_stunting"`
}

// DetailPasienTindakLanjutResponse untuk GET /api/v1/tindak-lanjut/pasien/{id}
type DetailPasienTindakLanjutResponse struct {
	IDPasien               int                               `json:"id_pasien"`
	NamaPasien             string                            `json:"nama_pasien"`
	Usia                   string                            `json:"usia"`
	HasilMonitoringTerakhir HasilMonitoringTerakhir          `json:"hasil_monitoring_terakhir"`
	RiwayatPemeriksaan     []RiwayatPemeriksaanTindakLanjut `json:"riwayat_pemeriksaan"`
}

// CreateTindakLanjutResponse untuk POST /api/v1/tindak-lanjut
type CreateTindakLanjutResponse struct {
	IDTindakLanjut int    `json:"id_tindak_lanjut"`
	IDRujukan      *int   `json:"id_rujukan,omitempty"` // NULL jika bukan rujukan
	StatusPasien   string `json:"status_pasien"`
}

// UpdateStatusRujukanResponse untuk PATCH /api/v1/rujukan/{id}/status
type UpdateStatusRujukanResponse struct {
	IDRujukan     int    `json:"id_rujukan"`
	StatusRujukan string `json:"status_rujukan"`
}

// DetailTindakLanjutResponse untuk GET /api/v1/tindak-lanjut/{id}
type DetailTindakLanjutResponse struct {
	IDTindakLanjut int     `json:"id_tindak_lanjut"`
	StatusPasien   string  `json:"status_pasien"`
	CatatanMedis   *string `json:"catatan_medis,omitempty"`
	Rekomendasi    *string `json:"rekomendasi,omitempty"`
	JadwalKontrol  *string `json:"jadwal_kontrol,omitempty"` // Format: YYYY-MM-DD
	StatusRujukan  *string `json:"status_rujukan,omitempty"` // NULL jika bukan rujukan
	NamaFaskes     *string `json:"nama_faskes,omitempty"`    // NULL jika bukan rujukan
}

// StatusTindakLanjutItem representasi satu item status tindak lanjut pasien
type StatusTindakLanjutItem struct {
	IDPasien       int     `json:"id_pasien"`
	NamaPasien     string  `json:"nama_pasien"`
	StatusPasien   string  `json:"status_pasien"`
	StatusRujukan  *string `json:"status_rujukan,omitempty"`  // NULL jika tidak ada rujukan
	TanggalRujukan *string `json:"tanggal_rujukan,omitempty"` // Format: YYYY-MM-DD, NULL jika tidak ada
}

// StatusTindakLanjutListResponse wrapper untuk list status tindak lanjut dengan pagination
type StatusTindakLanjutListResponse struct {
	Pasien []StatusTindakLanjutItem `json:"pasien"`
}

// LaporanWilayahItem representasi rekap per wilayah
type LaporanWilayahItem struct {
	Wilayah               string `json:"wilayah"`
	JumlahPasienDirujuk   int    `json:"jumlah_pasien_dirujuk"`
	JumlahPasienDiterima  int    `json:"jumlah_pasien_diterima"`
	JumlahPasienDiproses  int    `json:"jumlah_pasien_diproses"`
}

// PeriodeInfo nested struct untuk informasi periode laporan
type PeriodeInfo struct {
	Bulan int `json:"bulan"`
	Tahun int `json:"tahun"`
}

// LaporanTindakLanjutResponse untuk GET /api/v1/laporan/tindak-lanjut
type LaporanTindakLanjutResponse struct {
	Periode    PeriodeInfo          `json:"periode"`
	Laporan    []LaporanWilayahItem `json:"laporan"`
	TotalData  int                  `json:"total_data"`
}

// ============================================================================
// INTERNAL DOMAIN STRUCTS (Untuk Repository/Service Layer)
// ============================================================================

// SPTindakLanjutResult struct untuk mapping hasil Stored Procedure sp_create_tindak_lanjut_rujukan
type SPTindakLanjutResult struct {
	PResult          string // 'SUCCESS', 'PEMERIKSAAN_NOT_FOUND', 'FASKES_NOT_FOUND', 'ALREADY_HAS_TINDAK_LANJUT'
	PMessage         string
	PIdTindakLanjut  int
	PIdRujukan       *int // NULL jika bukan rujukan
}

// TindakLanjutFilter untuk parameter filter di repository
type TindakLanjutFilter struct {
	Page         int
	PerPage      int
	Q            string
	StatusPasien string
}

// StatusTindakLanjutFilter untuk parameter filter status tindak lanjut
type StatusTindakLanjutFilter struct {
	Page          int
	PerPage       int
	StatusRujukan string
}

// LaporanFilter untuk parameter filter laporan
type LaporanFilter struct {
	Bulan      int
	Tahun      int
	IDPosyandu *int
}

// RiwayatPasienRow untuk mapping hasil fn_get_riwayat_pasien
type RiwayatPasienRow struct {
	Tanggal        time.Time
	BeratBadan     float64
	TinggiBadan    float64
	StatusGizi     string
	StatusStunting string
}

// ValidasiStatusRujukanResult untuk hasil fn_validate_status_rujukan
type ValidasiStatusRujukanResult struct {
	IsValid bool
	Message string
}
