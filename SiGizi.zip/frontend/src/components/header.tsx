import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Search, Bell, LogOut, LogIn, ChevronDown, ArrowRight } from 'lucide-react';
import type { Role } from '../App';
import { useAuth } from '../context/AuthContext';
import { NOTIF_PREVIEW, CATEGORY_DOT } from '../screens/notifikasi/data/notifikasi.data';

interface HeaderProps {
  currentRole?: Role;
  onLoginClick: () => void;
  onChangeRole?: (role: Role) => void;
}

const PAGE_TITLES: Record<string, string> = {
  '/': 'Dashboard Overview',
  '/monitoring': 'Monitoring Gizi Ibu dan Anak',
  '/tindak-lanjut': 'Tindak Lanjut',
  '/jadwal-imunisasi': 'Jadwal Imunisasi',
  '/edukasi': 'Edukasi',
  '/user-management': 'User Management',
  '/notifikasi': 'Notifikasi',
};

export function Header({ currentRole, onLoginClick, onChangeRole }: HeaderProps): JSX.Element {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, isLoggedIn, logout } = useAuth();

  const [searchQuery, setSearchQuery] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const pageTitle = PAGE_TITLES[location.pathname] || 'SiGizi';

  // Preview notifikasi sesuai role yang sedang login
  const previewItems = isLoggedIn && currentRole ? (NOTIF_PREVIEW[currentRole] ?? []) : [];
  const unreadCount = previewItems.filter((n) => !n.read).length || previewItems.length;

  const handleLogout = () => {
    setShowProfileMenu(false);
    logout();
    navigate('/');
  };

  return (
    <header className="flex items-center justify-between px-8 py-4 bg-white border-b border-neutral-100 relative z-30">
      {/* Left: page title + role badge/switcher */}
      <div className="flex items-center gap-3">
        <h1 className="text-xl font-bold text-neutral-800 font-headline">{pageTitle}</h1>
        {isLoggedIn && currentRole && (
          <>
            <div className="h-5 w-px bg-neutral-200" />
            {onChangeRole ? (
              <div className="relative flex items-center">
                <select
                  value={currentRole}
                  onChange={(e) => onChangeRole(e.target.value as Role)}
                  className="appearance-none bg-white border border-primary text-primary text-xs font-semibold px-3 py-1.5 pr-8 rounded-lg focus:outline-none cursor-pointer"
                >
                  <option value="Ibu/Wali">Role: Ibu/Wali</option>
                  <option value="Bidan">Role: Bidan</option>
                  <option value="Dinas Kesehatan">Role: Dinas Kesehatan</option>
                  <option value="Kader Posyandu">Role: Kader Posyandu</option>
                </select>
                <span className="absolute right-2.5 pointer-events-none text-primary">
                  <ChevronDown size={14} />
                </span>
              </div>
            ) : (
              <span className="text-xs font-semibold text-primary border border-primary px-2.5 py-1 rounded-lg font-body">
                {currentRole}
              </span>
            )}
          </>
        )}
      </div>

      {/* Right */}
      <div className="flex items-center gap-3">
        {/* Search — hide on monitoring */}
        {isLoggedIn && location.pathname !== '/monitoring' && (
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
            <input
              type="text"
              placeholder="Cari data..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-56 pl-9 pr-4 py-2.5 bg-neutral-50 border border-neutral-200 rounded-xl text-sm text-neutral-700 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-primary-200 font-body"
            />
          </div>
        )}

        {isLoggedIn ? (
          <>
            {/* Notification bell — preview dropdown */}
            <div className="relative">
              <button
                onClick={() => { setShowNotifications(!showNotifications); setShowProfileMenu(false); }}
                className="p-2 text-neutral-500 hover:text-neutral-700 hover:bg-neutral-50 rounded-lg transition-colors relative"
              >
                <Bell size={20} />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 top-full mt-2 w-96 bg-white rounded-2xl shadow-xl border border-neutral-100 overflow-hidden z-50">
                  {/* Header */}
                  <div className="flex items-center justify-between px-5 py-3.5 border-b border-neutral-100">
                    <div className="flex items-center gap-2">
                      <Bell size={15} className="text-neutral-500" />
                      <span className="text-sm font-bold text-neutral-800 font-headline">Notifikasi</span>
                      {unreadCount > 0 && (
                        <span className="text-[10px] font-bold bg-red-500 text-white px-2 py-0.5 rounded-full">
                          {unreadCount} baru
                        </span>
                      )}
                    </div>
                    <button
                      onClick={() => { navigate('/notifikasi'); setShowNotifications(false); }}
                      className="text-xs text-primary font-semibold hover:text-primary-600 transition-colors flex items-center gap-1"
                    >
                      Lihat Semua <ArrowRight size={11} />
                    </button>
                  </div>

                  {/* Preview list */}
                  <div className="divide-y divide-neutral-50 max-h-80 overflow-y-auto">
                    {previewItems.slice(0, 4).map((item) => (
                      <div
                        key={item.id}
                        onClick={() => { navigate('/notifikasi'); setShowNotifications(false); }}
                        className="flex items-start gap-3 px-5 py-3.5 hover:bg-neutral-50 cursor-pointer transition-colors"
                      >
                        {/* Category dot */}
                        <div className="flex-shrink-0 mt-1.5">
                          <span className={`w-2 h-2 rounded-full block ${CATEGORY_DOT[item.category] ?? 'bg-neutral-300'}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-neutral-800 leading-snug truncate">{item.title}</p>
                          {item.description && (
                            <p className="text-xs text-neutral-500 mt-0.5 line-clamp-1 leading-relaxed">{item.description}</p>
                          )}
                          <div className="flex items-center gap-2 mt-1.5">
                            <span className="text-[10px] text-neutral-400">{item.time}</span>
                            {item.tags[0] && (
                              <span
                                className="text-[10px] font-bold px-1.5 py-0.5 rounded"
                                style={{ color: item.tags[0].color, backgroundColor: item.tags[0].bg }}
                              >
                                {item.tags[0].label}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Footer CTA */}
                  <div className="px-5 py-3 bg-neutral-50 border-t border-neutral-100">
                    <button
                      onClick={() => { navigate('/notifikasi'); setShowNotifications(false); }}
                      className="w-full py-2 bg-primary hover:bg-primary-600 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                    >
                      Buka Semua Notifikasi <ArrowRight size={12} />
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Profile avatar + dropdown */}
            <div className="relative">
              <button
                onClick={() => { setShowProfileMenu(!showProfileMenu); setShowNotifications(false); }}
                className="flex items-center gap-2 p-1 hover:bg-neutral-50 rounded-xl transition-colors"
              >
                <div className="w-8 h-8 rounded-full overflow-hidden bg-neutral-200 flex-shrink-0">
                  <img src={user!.avatarUrl} alt={user!.name} className="w-full h-full object-cover" />
                </div>
                <span className="text-sm font-semibold text-neutral-700 font-body hidden sm:inline">
                  {user!.name}
                </span>
              </button>

              {showProfileMenu && (
                <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-xl shadow-lg border border-neutral-100 py-2 z-50">
                  {/* User info */}
                  <div className="px-4 py-3 border-b border-neutral-100">
                    <p className="text-sm font-semibold text-neutral-800 font-body">{user!.name}</p>
                    <p className="text-xs text-neutral-500 font-body mt-0.5">{user!.role}</p>
                  </div>
                  {/* Logout */}
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition-colors font-body"
                  >
                    <LogOut size={15} />
                    Keluar
                  </button>
                </div>
              )}
            </div>
          </>
        ) : (
          /* Not logged in → Login button */
          <button
            onClick={onLoginClick}
            className="flex items-center gap-2 bg-primary hover:bg-primary-600 text-white px-4 py-2 rounded-xl text-sm font-semibold font-body transition-colors"
          >
            <LogIn size={16} />
            Masuk
          </button>
        )}
      </div>

      {/* Click-outside dismiss overlay */}
      {(showNotifications || showProfileMenu) && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => { setShowNotifications(false); setShowProfileMenu(false); }}
        />
      )}
    </header>
  );
}