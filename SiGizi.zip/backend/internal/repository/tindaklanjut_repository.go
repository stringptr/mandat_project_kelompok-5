package repository

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	"myproject/internal/model"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// TindakLanjutRepository interface untuk operasi database modul tindak lanjut
type TindakLanjutRepository interface {
	// GetPasienTindakLanjutList mengambil daftar pasien yang memerlukan tindak lanjut dengan pagination
	GetPasienTindakLanjutList(ctx context.Context, filter model.TindakLanjutFilter) ([]model.PasienTindakLanjutItem, int, error)

	// GetDetailPasienTindakLanjut mengambil detail pasien dan riwayat pemeriksaan
	GetDetailPasienTindakLanjut(ctx context.Context, idPasien int) (*model.DetailPasienTindakLanjutResponse, error)

	// CreateTindakLanjutRujukan membuat tindak lanjut dan rujukan via stored procedure
	CreateTindakLanjutRujukan(ctx context.Context, params CreateTindakLanjutParams) (*model.SPTindakLanjutResult, error)

	// UpdateStatusRujukan mengubah status rujukan dengan validasi transisi
	UpdateStatusRujukan(ctx context.Context, idRujukan int, statusBaru string, idUser int) error

	// ValidateStatusRujukanTransition memvalidasi transisi status rujukan
	ValidateStatusRujukanTransition(ctx context.Context, idRujukan int, statusBaru string) (*model.ValidasiStatusRujukanResult, error)

	// GetDetailTindakLanjut mengambil detail tindak lanjut pasien
	GetDetailTindakLanjut(ctx context.Context, idTindakLanjut int) (*model.DetailTindakLanjutResponse, error)

	// GetStatusTindakLanjutList mengambil status tindak lanjut pasien dengan pagination
	GetStatusTindakLanjutList(ctx context.Context, filter model.StatusTindakLanjutFilter) ([]model.StatusTindakLanjutItem, int, error)

	// GetLaporanTindakLanjut mengambil laporan rekap tindak lanjut dan rujukan
	GetLaporanTindakLanjut(ctx context.Context, filter model.LaporanFilter) ([]model.LaporanWilayahItem, error)
}

// CreateTindakLanjutParams parameter untuk stored procedure
type CreateTindakLanjutParams struct {
	IDHasilPemeriksaan int
	IDBidan            int
	JenisTindakan      string
	CatatanMedis       *string
	Rekomendasi        *string
	JadwalKontrol      *time.Time
	AlasanRujukan      *string
	IDFaskes           *int
}

// tindakLanjutRepository implementasi TindakLanjutRepository
type tindakLanjutRepository struct {
	db *pgxpool.Pool
}

// NewTindakLanjutRepository membuat instance baru TindakLanjutRepository
func NewTindakLanjutRepository(db *pgxpool.Pool) TindakLanjutRepository {
	return &tindakLanjutRepository{db: db}
}

// GetPasienTindakLanjutList implementasi query dari v_pasien_tindak_lanjut
func (r *tindakLanjutRepository) GetPasienTindakLanjutList(ctx context.Context, filter model.TindakLanjutFilter) ([]model.PasienTindakLanjutItem, int, error) {
	// Build query menggunakan Go Jet dengan WHERE dinamis
	// Asumsikan view v_pasien_tindak_lanjut sudah di-generate oleh jet
	// Untuk contoh implementasi, kita gunakan raw query dengan pgx karena view belum di-generate
	// Dalam production, gunakan Go Jet sepenuhnya
	
	var conditions []string
	var args []interface{}
	argCounter := 1

	baseQuery := `
		SELECT 
			id_pasien,
			nama_pasien,
			status_gizi,
			status_pasien,
			TO_CHAR(tanggal_pemeriksaan, 'YYYY-MM-DD') as tanggal_pemeriksaan
		FROM v_pasien_tindak_lanjut
		WHERE 1=1
	`

	// Filter nama pasien
	if filter.Q != "" {
		conditions = append(conditions, fmt.Sprintf("LOWER(nama_pasien) LIKE $%d", argCounter))
		args = append(args, "%"+strings.ToLower(filter.Q)+"%")
		argCounter++
	}

	// Filter status pasien
	if filter.StatusPasien != "" {
		conditions = append(conditions, fmt.Sprintf("status_pasien = $%d", argCounter))
		args = append(args, filter.StatusPasien)
		argCounter++
	}

	// Gabungkan kondisi WHERE
	if len(conditions) > 0 {
		baseQuery += " AND " + strings.Join(conditions, " AND ")
	}

	// Count total untuk pagination
	countQuery := "SELECT COUNT(*) FROM (" + baseQuery + ") AS count_query"
	var total int
	err := r.db.QueryRow(ctx, countQuery, args...).Scan(&total)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to count pasien tindak lanjut: %w", err)
	}

	// Query data dengan pagination
	baseQuery += fmt.Sprintf(" ORDER BY tanggal_pemeriksaan DESC LIMIT $%d OFFSET $%d", argCounter, argCounter+1)
	args = append(args, filter.PerPage, (filter.Page-1)*filter.PerPage)

	rows, err := r.db.Query(ctx, baseQuery, args...)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to query pasien tindak lanjut: %w", err)
	}
	defer rows.Close()

	var results []model.PasienTindakLanjutItem
	for rows.Next() {
		var item model.PasienTindakLanjutItem
		err := rows.Scan(
			&item.IDPasien,
			&item.NamaPasien,
			&item.StatusGizi,
			&item.StatusPasien,
			&item.TanggalPemeriksaan,
		)
		if err != nil {
			return nil, 0, fmt.Errorf("failed to scan pasien tindak lanjut: %w", err)
		}
		results = append(results, item)
	}

	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("error iterating pasien tindak lanjut rows: %w", err)
	}

	return results, total, nil
}

// GetDetailPasienTindakLanjut implementasi query detail pasien dan riwayat
func (r *tindakLanjutRepository) GetDetailPasienTindakLanjut(ctx context.Context, idPasien int) (*model.DetailPasienTindakLanjutResponse, error) {
	// Query detail pasien dari v_detail_pasien_monitoring
	detailQuery := `
		SELECT 
			id_pasien,
			nama_pasien,
			usia,
			status_gizi,
			status_stunting,
			catatan_observasi
		FROM v_detail_pasien_monitoring
		WHERE id_pasien = $1
	`

	var detail model.DetailPasienTindakLanjutResponse
	var catatan sql.NullString

	err := r.db.QueryRow(ctx, detailQuery, idPasien).Scan(
		&detail.IDPasien,
		&detail.NamaPasien,
		&detail.Usia,
		&detail.HasilMonitoringTerakhir.StatusGizi,
		&detail.HasilMonitoringTerakhir.StatusStunting,
		&catatan,
	)

	if err != nil {
		if err == pgx.ErrNoRows {
			return nil, nil // Data tidak ditemukan
		}
		return nil, fmt.Errorf("failed to query detail pasien: %w", err)
	}

	if catatan.Valid {
		detail.HasilMonitoringTerakhir.Catatan = &catatan.String
	}

	// Query riwayat pemeriksaan dari function fn_get_riwayat_pasien
	riwayatQuery := `SELECT * FROM fn_get_riwayat_pasien($1)`
	rows, err := r.db.Query(ctx, riwayatQuery, idPasien)
	if err != nil {
		return nil, fmt.Errorf("failed to query riwayat pasien: %w", err)
	}
	defer rows.Close()

	var riwayat []model.RiwayatPemeriksaanTindakLanjut
	for rows.Next() {
		var item model.RiwayatPemeriksaanTindakLanjut
		var tanggal time.Time

		err := rows.Scan(
			&tanggal,
			&item.BeratBadan,
			&item.TinggiBadan,
			&item.StatusGizi,
			&item.StatusStunting,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan riwayat pasien: %w", err)
		}

		item.Tanggal = tanggal.Format("2006-01-02")
		riwayat = append(riwayat, item)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating riwayat rows: %w", err)
	}

	detail.RiwayatPemeriksaan = riwayat

	return &detail, nil
}

// CreateTindakLanjutRujukan implementasi pemanggilan stored procedure
func (r *tindakLanjutRepository) CreateTindakLanjutRujukan(ctx context.Context, params CreateTindakLanjutParams) (*model.SPTindakLanjutResult, error) {
	// Panggil stored procedure sp_create_tindak_lanjut_rujukan
	// Karena Go Jet tidak support native SP call, gunakan db.ExecContext via pgx
	
	// Convert time pointer to sql.NullTime
	var jadwalKontrol sql.NullTime
	if params.JadwalKontrol != nil {
		jadwalKontrol.Time = *params.JadwalKontrol
		jadwalKontrol.Valid = true
	}

	// Execute stored procedure
	// Note: pgx doesn't support OUT parameters directly in CALL statement
	// We need to use a function wrapper or restructure the SP to return a table
	// For this implementation, we'll use a SELECT from function approach
	
	functionQuery := `
		SELECT * FROM sp_create_tindak_lanjut_rujukan(
			$1::INT, $2::INT, $3::VARCHAR, $4::VARCHAR, $5::VARCHAR, 
			$6::DATE, $7::VARCHAR, $8::INT
		)
	`

	var result model.SPTindakLanjutResult
	var idRujukan sql.NullInt32

	err := r.db.QueryRow(ctx, functionQuery,
		params.IDHasilPemeriksaan,
		params.IDBidan,
		params.JenisTindakan,
		params.CatatanMedis,
		params.Rekomendasi,
		jadwalKontrol,
		params.AlasanRujukan,
		params.IDFaskes,
	).Scan(
		&result.PResult,
		&result.PMessage,
		&result.PIdTindakLanjut,
		&idRujukan,
	)

	if err != nil {
		return nil, fmt.Errorf("failed to execute sp_create_tindak_lanjut_rujukan: %w", err)
	}

	if idRujukan.Valid {
		idRuj := int(idRujukan.Int32)
		result.PIdRujukan = &idRuj
	}

	return &result, nil
}

// ValidateStatusRujukanTransition memvalidasi transisi status rujukan
func (r *tindakLanjutRepository) ValidateStatusRujukanTransition(ctx context.Context, idRujukan int, statusBaru string) (*model.ValidasiStatusRujukanResult, error) {
	// Panggil function fn_validate_status_rujukan
	query := `SELECT * FROM fn_validate_status_rujukan($1, $2)`

	var result model.ValidasiStatusRujukanResult
	err := r.db.QueryRow(ctx, query, idRujukan, statusBaru).Scan(
		&result.IsValid,
		&result.Message,
	)

	if err != nil {
		return nil, fmt.Errorf("failed to validate status rujukan: %w", err)
	}

	return &result, nil
}

// UpdateStatusRujukan implementasi update status rujukan dengan Go Jet
func (r *tindakLanjutRepository) UpdateStatusRujukan(ctx context.Context, idRujukan int, statusBaru string, idUser int) error {
	// Dalam production, gunakan Go Jet untuk UPDATE:
	// stmt := table.Rujukan.UPDATE(table.Rujukan.StatusRujukan, table.Rujukan.UpdatedAt).
	//     SET(statusBaru, postgres.NOW()).
	//     WHERE(table.Rujukan.IDRujukan.EQ(postgres.Int(idRujukan)))
	
	// Untuk sekarang, gunakan query manual dengan pgx
	query := `
		UPDATE rujukan
		SET status_rujukan = $1, updated_at = NOW()
		WHERE id_rujukan = $2
	`

	result, err := r.db.Exec(ctx, query, statusBaru, idRujukan)
	if err != nil {
		return fmt.Errorf("failed to update status rujukan: %w", err)
	}

	if result.RowsAffected() == 0 {
		return sql.ErrNoRows // Data tidak ditemukan
	}

	// Insert notifikasi (inline atau async sesuai kebutuhan)
	// Untuk simplifikasi, skip notifikasi di sini
	// Dalam production, panggil repository notifikasi atau publish ke message queue

	return nil
}

// GetDetailTindakLanjut implementasi query detail tindak lanjut
func (r *tindakLanjutRepository) GetDetailTindakLanjut(ctx context.Context, idTindakLanjut int) (*model.DetailTindakLanjutResponse, error) {
	// Query dari v_detail_tindak_lanjut_pasien
	query := `
		SELECT 
			id_tindak_lanjut,
			status_pasien,
			catatan_medis,
			rekomendasi,
			TO_CHAR(jadwal_kontrol, 'YYYY-MM-DD') as jadwal_kontrol,
			status_rujukan,
			nama_faskes
		FROM v_detail_tindak_lanjut_pasien
		WHERE id_tindak_lanjut = $1
	`

	var detail model.DetailTindakLanjutResponse
	var catatanMedis, rekomendasi, jadwalKontrol, statusRujukan, namaFaskes sql.NullString

	err := r.db.QueryRow(ctx, query, idTindakLanjut).Scan(
		&detail.IDTindakLanjut,
		&detail.StatusPasien,
		&catatanMedis,
		&rekomendasi,
		&jadwalKontrol,
		&statusRujukan,
		&namaFaskes,
	)

	if err != nil {
		if err == pgx.ErrNoRows {
			return nil, nil // Data tidak ditemukan
		}
		return nil, fmt.Errorf("failed to query detail tindak lanjut: %w", err)
	}

	// Map nullable fields
	if catatanMedis.Valid {
		detail.CatatanMedis = &catatanMedis.String
	}
	if rekomendasi.Valid {
		detail.Rekomendasi = &rekomendasi.String
	}
	if jadwalKontrol.Valid {
		detail.JadwalKontrol = &jadwalKontrol.String
	}
	if statusRujukan.Valid {
		detail.StatusRujukan = &statusRujukan.String
	}
	if namaFaskes.Valid {
		detail.NamaFaskes = &namaFaskes.String
	}

	return &detail, nil
}

// GetStatusTindakLanjutList implementasi query status tindak lanjut dengan pagination
func (r *tindakLanjutRepository) GetStatusTindakLanjutList(ctx context.Context, filter model.StatusTindakLanjutFilter) ([]model.StatusTindakLanjutItem, int, error) {
	// Build query dari v_status_tindak_lanjut_pasien
	var conditions []string
	var args []interface{}
	argCounter := 1

	baseQuery := `
		SELECT 
			id_pasien,
			nama_pasien,
			status_pasien,
			status_rujukan,
			TO_CHAR(tanggal_rujukan, 'YYYY-MM-DD') as tanggal_rujukan
		FROM v_status_tindak_lanjut_pasien
		WHERE 1=1
	`

	// Filter status rujukan
	if filter.StatusRujukan != "" {
		conditions = append(conditions, fmt.Sprintf("status_rujukan = $%d", argCounter))
		args = append(args, filter.StatusRujukan)
		argCounter++
	}

	// Gabungkan kondisi WHERE
	if len(conditions) > 0 {
		baseQuery += " AND " + strings.Join(conditions, " AND ")
	}

	// Count total untuk pagination
	countQuery := "SELECT COUNT(*) FROM (" + baseQuery + ") AS count_query"
	var total int
	err := r.db.QueryRow(ctx, countQuery, args...).Scan(&total)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to count status tindak lanjut: %w", err)
	}

	// Query data dengan pagination
	baseQuery += fmt.Sprintf(" ORDER BY tanggal_rujukan DESC LIMIT $%d OFFSET $%d", argCounter, argCounter+1)
	args = append(args, filter.PerPage, (filter.Page-1)*filter.PerPage)

	rows, err := r.db.Query(ctx, baseQuery, args...)
	if err != nil {
		return nil, 0, fmt.Errorf("failed to query status tindak lanjut: %w", err)
	}
	defer rows.Close()

	var results []model.StatusTindakLanjutItem
	for rows.Next() {
		var item model.StatusTindakLanjutItem
		var statusRujukan, tanggalRujukan sql.NullString

		err := rows.Scan(
			&item.IDPasien,
			&item.NamaPasien,
			&item.StatusPasien,
			&statusRujukan,
			&tanggalRujukan,
		)
		if err != nil {
			return nil, 0, fmt.Errorf("failed to scan status tindak lanjut: %w", err)
		}

		if statusRujukan.Valid {
			item.StatusRujukan = &statusRujukan.String
		}
		if tanggalRujukan.Valid {
			item.TanggalRujukan = &tanggalRujukan.String
		}

		results = append(results, item)
	}

	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("error iterating status tindak lanjut rows: %w", err)
	}

	return results, total, nil
}

// GetLaporanTindakLanjut implementasi query laporan dengan agregasi
func (r *tindakLanjutRepository) GetLaporanTindakLanjut(ctx context.Context, filter model.LaporanFilter) ([]model.LaporanWilayahItem, error) {
	// Panggil function fn_rekap_rujukan_periode dan agregasi
	// Dalam production, gunakan Go Jet untuk agregasi GROUP BY
	
	var args []interface{}
	argCounter := 1

	baseQuery := `
		SELECT 
			wilayah,
			jumlah_pasien_dirujuk,
			jumlah_pasien_diterima,
			jumlah_pasien_diproses
		FROM fn_rekap_rujukan_periode($1, $2)
	`

	args = append(args, filter.Bulan, filter.Tahun)
	argCounter = 3

	// Filter id_posyandu jika diberikan
	if filter.IDPosyandu != nil {
		baseQuery += fmt.Sprintf(" WHERE id_posyandu = $%d", argCounter)
		args = append(args, *filter.IDPosyandu)
	}

	baseQuery += " ORDER BY wilayah"

	rows, err := r.db.Query(ctx, baseQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to query laporan tindak lanjut: %w", err)
	}
	defer rows.Close()

	var results []model.LaporanWilayahItem
	for rows.Next() {
		var item model.LaporanWilayahItem

		err := rows.Scan(
			&item.Wilayah,
			&item.JumlahPasienDirujuk,
			&item.JumlahPasienDiterima,
			&item.JumlahPasienDiproses,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan laporan item: %w", err)
		}

		results = append(results, item)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating laporan rows: %w", err)
	}

	return results, nil
}
