package handler

import (
	"context"
	"strings"
)

// JWTClaims struct untuk claims dari JWT
type JWTClaims struct {
	ID     string   `json:"id"`
	IDUser int      `json:"id_user"`
	Roles  []string `json:"roles"`
	NIK    string   `json:"nik"`
	Email  string   `json:"email"`
}

// Helper functions to extract JWT claims from context
// These should be populated by your auth middleware

// getIDUserFromContext mengambil id_user dari context
func getIDUserFromContext(ctx context.Context) int {
	if val := ctx.Value("id_user"); val != nil {
		if idUser, ok := val.(int); ok {
			return idUser
		}
	}
	return 0
}

// getRoleFromContext mengambil role dari context
func getRoleFromContext(ctx context.Context) string {
	if val := ctx.Value("role"); val != nil {
		if role, ok := val.(string); ok {
			return role
		}
	}
	return ""
}

// getUserClaims mengambil claims JWT dari context (disuntikkan middleware)
func getUserClaims(ctx context.Context) *JWTClaims {
	claims, ok := ctx.Value("user_claims").(*JWTClaims)
	if !ok {
		return nil
	}
	return claims
}

// hasRole mengecek apakah user memiliki role tertentu
func hasRole(claims *JWTClaims, role string) bool {
	for _, r := range claims.Roles {
		if strings.EqualFold(r, role) {
			return true
		}
	}
	return false
}
