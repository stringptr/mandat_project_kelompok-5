package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"myproject/internal/config"
	"myproject/internal/handler"
	"myproject/internal/repository"
	"myproject/internal/service"

	"github.com/danielgtaylor/huma/v2"
	"github.com/danielgtaylor/huma/v2/adapters/humachi"
	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"github.com/go-chi/cors"
	"github.com/jackc/pgx/v5/pgxpool"
)

func main() {
	// Load configuration
	cfg := config.Load()

	// Setup database connection pool
	dbPool, err := setupDatabase(cfg.DBMasterConfig)
	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
	}
	defer dbPool.Close()

	log.Println("✅ Database connection established")

	// Initialize repositories
	monitoringRepo := repository.NewMonitoringRepository(dbPool)
	tindakLanjutRepo := repository.NewTindakLanjutRepository(dbPool)
	artikelRepo := repository.NewArtikelRepository(dbPool)

	// Initialize services
	monitoringService := service.NewMonitoringService(monitoringRepo)
	tindakLanjutService := service.NewTindakLanjutService(tindakLanjutRepo)
	artikelService := service.NewArtikelService(artikelRepo)

	// Initialize handlers
	monitoringHandler := handler.NewMonitoringHandler(monitoringService)
	tindakLanjutHandler := handler.NewTindakLanjutHandler(tindakLanjutService)
	artikelHandler := handler.NewArtikelHandler(artikelService)

	// Setup HTTP router with Chi
	router := chi.NewRouter()

	// Middleware
	router.Use(middleware.Logger)
	router.Use(middleware.Recoverer)
	router.Use(middleware.RequestID)
	router.Use(middleware.RealIP)
	router.Use(middleware.Timeout(60 * time.Second))

	// CORS middleware
	router.Use(cors.Handler(cors.Options{
		AllowedOrigins:   []string{"http://localhost:5173", "http://localhost:3000"},
		AllowedMethods:   []string{"GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Accept", "Authorization", "Content-Type", "X-CSRF-Token"},
		ExposedHeaders:   []string{"Link"},
		AllowCredentials: true,
		MaxAge:           300,
	}))

	// Health check endpoint
	router.Get("/health", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("OK"))
	})

	// Setup Huma API
	humaConfig := huma.DefaultConfig("SiGizi API", "1.0.0")

	humaConfig.DocsPath = "/docs"
	humaConfig.Servers = []*huma.Server{
		{URL: "http://localhost:8080", Description: "Local Development"},
	}

	api := humachi.New(router, humaConfig)

	// Register routes
	log.Println("📝 Registering API routes...")
	monitoringHandler.RegisterRoutes(api)
	tindakLanjutHandler.RegisterRoutes(api)
	artikelHandler.RegisterRoutes(api)

	// Start server
	host, port := cfg.Server()
	addr := fmt.Sprintf("%s:%s", host, port)

	server := &http.Server{
		Addr:         addr,
		Handler:      router,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	// Graceful shutdown
	go func() {
		log.Printf("🚀 Server starting on %s", addr)
		log.Printf("📚 API Documentation: http://localhost:%s/docs", port)
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Server failed to start: %v", err)
		}
	}()

	// Wait for interrupt signal
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	log.Println("🛑 Shutting down server...")

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := server.Shutdown(ctx); err != nil {
		log.Printf("Server forced to shutdown: %v", err)
	}

	log.Println("✅ Server exited gracefully")
}

// setupDatabase creates a connection pool to PostgreSQL
func setupDatabase(cfg config.PostgresConfig) (*pgxpool.Pool, error) {
	dsn := cfg.DSN()

	poolConfig, err := pgxpool.ParseConfig(dsn)
	if err != nil {
		return nil, fmt.Errorf("unable to parse database config: %w", err)
	}

	// Connection pool settings
	poolConfig.MaxConns = 25
	poolConfig.MinConns = 5
	poolConfig.MaxConnLifetime = time.Hour
	poolConfig.MaxConnIdleTime = 30 * time.Minute
	poolConfig.HealthCheckPeriod = time.Minute

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	pool, err := pgxpool.NewWithConfig(ctx, poolConfig)
	if err != nil {
		return nil, fmt.Errorf("unable to create connection pool: %w", err)
	}

	// Test connection
	if err := pool.Ping(ctx); err != nil {
		pool.Close()
		return nil, fmt.Errorf("unable to ping database: %w", err)
	}

	return pool, nil
}
