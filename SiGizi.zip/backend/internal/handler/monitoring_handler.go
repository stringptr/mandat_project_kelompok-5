package handler

import (
	"context"
	"fmt"
	"net/http"

	"myproject/internal/model"
	"myproject/internal/service"

	"github.com/danielgtaylor/huma/v2"
)

// MonitoringHandler handles HTTP routing for monitoring endpoints
type MonitoringHandler struct {
	service service.MonitoringService
}

// NewMonitoringHandler creates new instance
func NewMonitoringHandler(service service.MonitoringService) *MonitoringHandler {
	return &MonitoringHandler{service: service}
}

// RegisterRoutes registers all monitoring endpoints with Huma
func (h *MonitoringHandler) RegisterRoutes(api huma.API) {
	// Submodul Pasien
	huma.Register(api, huma.Operation{
		OperationID: "get-pasien-list",
		Method:      http.MethodGet,
		Path:        "/api/v1/monitoring/pasien",
		Summary:     "Daftar Pasien",
		Tags:        []string{"Monitoring"},
	}, h.GetPasienList)

	huma.Register(api, huma.Operation{
		OperationID: "get-pasien-detail",
		Method:      http.MethodGet,
		Path:        "/api/v1/monitoring/pasien/{id}",
		Summary:     "Detail Pasien",
		Tags:        []string{"Monitoring"},
	}, h.GetPasienDetail)

	huma.Register(api, huma.Operation{
		OperationID: "search-pasien",
		Method:      http.MethodGet,
		Path:        "/api/v1/monitoring/pasien/search",
		Summary:     "Cari Pasien",
		Tags:        []string{"Monitoring"},
	}, h.SearchPasien)

	huma.Register(api, huma.Operation{
		OperationID: "get-statistik",
		Method:      http.MethodGet,
		Path:        "/api/v1/monitoring/statistik",
		Summary:     "Summary Dashboard",
		Tags:        []string{"Monitoring"},
	}, h.GetStatistik)

	huma.Register(api, huma.Operation{
		OperationID: "get-statistik-bulanan",
		Method:      http.MethodGet,
		Path:        "/api/v1/monitoring/statistik-bulanan",
		Summary:     "Tren Pertumbuhan Bulanan",
		Tags:        []string{"Monitoring"},
	}, h.GetStatistikBulanan)

	huma.Register(api, huma.Operation{
		OperationID: "export-pasien",
		Method:      http.MethodGet,
		Path:        "/api/v1/monitoring/pasien/export",
		Summary:     "Export Excel",
		Tags:        []string{"Monitoring"},
	}, h.ExportPasien)

	// Submodul Pemeriksaan
	huma.Register(api, huma.Operation{
		OperationID: "create-pemeriksaan",
		Method:      http.MethodPost,
		Path:        "/api/v1/monitoring/pemeriksaan",
		Summary:     "Input Pemeriksaan",
		Tags:        []string{"Monitoring"},
	}, h.CreatePemeriksaan)

	huma.Register(api, huma.Operation{
		OperationID: "get-pemeriksaan-detail",
		Method:      http.MethodGet,
		Path:        "/api/v1/monitoring/pemeriksaan/{id}",
		Summary:     "Detail Pemeriksaan",
		Tags:        []string{"Monitoring"},
	}, h.GetPemeriksaanDetail)

	huma.Register(api, huma.Operation{
		OperationID: "update-pemeriksaan",
		Method:      http.MethodPut,
		Path:        "/api/v1/monitoring/pemeriksaan/{id}",
		Summary:     "Edit Pemeriksaan",
		Tags:        []string{"Monitoring"},
	}, h.UpdatePemeriksaan)

	huma.Register(api, huma.Operation{
		OperationID: "delete-pemeriksaan",
		Method:      http.MethodDelete,
		Path:        "/api/v1/monitoring/pemeriksaan/{id}",
		Summary:     "Hapus Pemeriksaan",
		Tags:        []string{"Monitoring"},
	}, h.DeletePemeriksaan)

	huma.Register(api, huma.Operation{
		OperationID: "verifikasi-pemeriksaan",
		Method:      http.MethodPatch,
		Path:        "/api/v1/monitoring/pemeriksaan/{id}/verify",
		Summary:     "Verifikasi Pemeriksaan",
		Tags:        []string{"Monitoring"},
	}, h.VerifikasiPemeriksaan)

	huma.Register(api, huma.Operation{
		OperationID: "get-pemeriksaan-pending",
		Method:      http.MethodGet,
		Path:        "/api/v1/monitoring/pemeriksaan/pending",
		Summary:     "Pemeriksaan Belum Diverifikasi",
		Tags:        []string{"Monitoring"},
	}, h.GetPemeriksaanPending)

	// Submodul Imunisasi
	huma.Register(api, huma.Operation{
		OperationID: "get-jadwal-imunisasi",
		Method:      http.MethodGet,
		Path:        "/api/v1/imunisasi",
		Summary:     "Daftar Jadwal Imunisasi",
		Tags:        []string{"Imunisasi"},
	}, h.GetJadwalImunisasiList)

	huma.Register(api, huma.Operation{
		OperationID: "create-jadwal-imunisasi",
		Method:      http.MethodPost,
		Path:        "/api/v1/imunisasi",
		Summary:     "Tambah Jadwal Imunisasi",
		Tags:        []string{"Imunisasi"},
	}, h.CreateJadwalImunisasi)

	huma.Register(api, huma.Operation{
		OperationID: "update-realisasi-imunisasi",
		Method:      http.MethodPatch,
		Path:        "/api/v1/imunisasi/{id}/realisasi",
		Summary:     "Update Realisasi Vaksin",
		Tags:        []string{"Imunisasi"},
	}, h.UpdateRealisasiImunisasi)
}

// Request/Response wrappers for Huma
type GetPasienListInput struct {
	Query model.PasienListRequest
}

type GetPasienListOutput struct {
	Body model.APIResponse[model.PaginatedResponse[model.PasienListResponse]]
}

type GetPasienDetailInput struct {
	ID int `path:"id" minimum:"1"`
}

type GetPasienDetailOutput struct {
	Body model.APIResponse[model.PasienDetailResponse]
}

type SearchPasienInput struct {
	Q string `query:"q" required:"true"`
}

type SearchPasienOutput struct {
	Body model.APIResponse[model.PasienSearchResponse]
}

type CreatePemeriksaanInput struct {
	Body model.InputPemeriksaanBody
}

type CreatePemeriksaanOutput struct {
	Body model.APIResponse[model.HasilPemeriksaanResponse]
}

type VerifikasiPemeriksaanInput struct {
	ID   int                              `path:"id" minimum:"1"`
	Body model.VerifikasiPemeriksaanBody
}

type VerifikasiPemeriksaanOutput struct {
	Body model.APIResponse[model.VerifikasiPemeriksaanResponse]
}

// GetPasienList handler for GET /api/v1/monitoring/pasien
func (h *MonitoringHandler) GetPasienList(ctx context.Context, input *GetPasienListInput) (*GetPasienListOutput, error) {
	// Extract JWT claims from context (injected by middleware)
	idUser := getIDUserFromContext(ctx)

	if idUser == 0 {
		return &GetPasienListOutput{
			Body: model.APIResponse[model.PaginatedResponse[model.PasienListResponse]]{
				Status:  401,
				Success: false,
				Errors: []model.ErrorItem{
					{Message: model.ErrorMessages[model.ErrAuthUnauthorized]},
				},
				Detail: model.ErrorMessages[model.ErrAuthUnauthorized],
				Title:  "Unauthorized",
			},
		}, nil
	}

	// Call service
	result, err := h.service.GetPasienList(ctx, input.Query)
	if err != nil {
		return &GetPasienListOutput{
			Body: model.APIResponse[model.PaginatedResponse[model.PasienListResponse]]{
				Status:  500,
				Success: false,
				Errors: []model.ErrorItem{
					{Message: model.ErrorMessages[model.ErrSystem]},
				},
				Detail: model.ErrorMessages[model.ErrSystem],
				Title:  "Internal Server Error",
			},
		}, nil
	}

	return &GetPasienListOutput{
		Body: model.NewSuccessResponse(200, "OK", "Daftar data pasien berhasil diambil.", *result),
	}, nil
}

// CreatePemeriksaan handler for POST /api/v1/monitoring/pemeriksaan
func (h *MonitoringHandler) CreatePemeriksaan(ctx context.Context, input *CreatePemeriksaanInput) (*CreatePemeriksaanOutput, error) {
	// Extract JWT claims
	idUser := getIDUserFromContext(ctx)
	role := getRoleFromContext(ctx)

	// Check auth
	if idUser == 0 {
		return &CreatePemeriksaanOutput{
			Body: model.APIResponse[model.HasilPemeriksaanResponse]{
				Status:  401,
				Success: false,
				Errors: []model.ErrorItem{
					{Message: model.ErrorMessages[model.ErrAuthUnauthorized]},
				},
				Detail: model.ErrorMessages[model.ErrAuthUnauthorized],
				Title:  "Unauthorized",
			},
		}, nil
	}

	// Check role (Bidan or Kader)
	if role != "BIDAN" && role != "KADER" {
		return &CreatePemeriksaanOutput{
			Body: model.APIResponse[model.HasilPemeriksaanResponse]{
				Status:  403,
				Success: false,
				Errors: []model.ErrorItem{
					{Message: model.ErrorMessages[model.ErrAuthForbidden]},
				},
				Detail: model.ErrorMessages[model.ErrAuthForbidden],
				Title:  "Forbidden",
			},
		}, nil
	}

	// Call service
	result, errItems, err := h.service.CreatePemeriksaan(ctx, input.Body, idUser)
	if err != nil {
		return &CreatePemeriksaanOutput{
			Body: model.APIResponse[model.HasilPemeriksaanResponse]{
				Status:  500,
				Success: false,
				Errors: []model.ErrorItem{
					{Message: model.ErrorMessages[model.ErrSystem]},
				},
				Detail: model.ErrorMessages[model.ErrSystem],
				Title:  "Internal Server Error",
			},
		}, nil
	}

	if len(errItems) > 0 {
		// Validation errors
		return &CreatePemeriksaanOutput{
			Body: model.APIResponse[model.HasilPemeriksaanResponse]{
				Status:  422,
				Success: false,
				Errors:  errItems,
				Detail:  "Terdapat kesalahan pada pengisian data.",
				Title:   "Unprocessable Content",
			},
		}, nil
	}

	return &CreatePemeriksaanOutput{
		Body: model.NewSuccessResponse(201, "Created", "Data pemeriksaan fisik berhasil disimpan dan status gizi telah dikalkulasi.", *result),
	}, nil
}

// VerifikasiPemeriksaan handler for PATCH /api/v1/monitoring/pemeriksaan/{id}/verify
func (h *MonitoringHandler) VerifikasiPemeriksaan(ctx context.Context, input *VerifikasiPemeriksaanInput) (*VerifikasiPemeriksaanOutput, error) {
	// Extract JWT claims
	idUser := getIDUserFromContext(ctx)
	role := getRoleFromContext(ctx)

	if idUser == 0 {
		return &VerifikasiPemeriksaanOutput{
			Body: model.APIResponse[model.VerifikasiPemeriksaanResponse]{
				Status:  401,
				Success: false,
				Errors: []model.ErrorItem{
					{Message: model.ErrorMessages[model.ErrAuthUnauthorized]},
				},
				Detail: model.ErrorMessages[model.ErrAuthUnauthorized],
				Title:  "Unauthorized",
			},
		}, nil
	}

	// Call service (will validate role BIDAN internally)
	result, errItems, err := h.service.VerifikasiPemeriksaan(ctx, input.ID, input.Body, idUser, role)
	if err != nil {
		return &VerifikasiPemeriksaanOutput{
			Body: model.NewErrorResponse[model.VerifikasiPemeriksaanResponse](500, "Internal Server Error", model.ErrorMessages[model.ErrSystem], []model.ErrorItem{
				{Message: model.ErrorMessages[model.ErrSystem]},
			}),
		}, nil
	}

	if len(errItems) > 0 {
		// Check error type
		for _, e := range errItems {
			if e.Message == model.ErrorMessages[model.ErrAuthForbidden] {
				return &VerifikasiPemeriksaanOutput{
					Body: model.NewErrorResponse[model.VerifikasiPemeriksaanResponse](403, "Forbidden", "Anda tidak memiliki izin untuk mengakses ini.", errItems),
				}, nil
			}
			if e.Message == model.ErrorMessages[model.ErrDataNotFound] {
				return &VerifikasiPemeriksaanOutput{
					Body: model.NewErrorResponse[model.VerifikasiPemeriksaanResponse](404, "Not Found", "Data pemeriksaan yang akan diverifikasi tidak ditemukan.", errItems),
				}, nil
			}
		}
		// Validation errors
		return &VerifikasiPemeriksaanOutput{
			Body: model.NewErrorResponse[model.VerifikasiPemeriksaanResponse](422, "Unprocessable Content", "Terdapat kesalahan pada pengisian data.", errItems),
		}, nil
	}

	return &VerifikasiPemeriksaanOutput{
		Body: model.NewSuccessResponse(200, "OK", "Data monitoring gizi berhasil diverifikasi oleh Bidan.", *result),
	}, nil
}

// ExportPasien handler for GET /api/v1/monitoring/pasien/export
func (h *MonitoringHandler) ExportPasien(ctx context.Context, input *struct {
	Query model.ExportRequest
}) (*struct{}, error) {
	// Extract JWT claims
	idUser := getIDUserFromContext(ctx)
	role := getRoleFromContext(ctx)

	if idUser == 0 {
		// Cannot use standard envelope for binary response
		// Return error in plain text or redirect
		return nil, fmt.Errorf("unauthorized")
	}

	// Check role (Bidan or Dinkes)
	if role != "BIDAN" && role != "DINKES" {
		return nil, fmt.Errorf("forbidden")
	}

	// Call service to generate Excel
	_, err := h.service.GenerateExcel(ctx, input.Query)
	if err != nil {
		return nil, err
	}

	// TODO: Implementasi pengiriman file Excel ke response writer
	// Membutuhkan akses ke http.ResponseWriter melalui context Huma.
	// Contoh implementasi:
	// w := getResponseWriterFromContext(ctx)
	// w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	// w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=\"monitoring-gizi-%s.xlsx\"", time.Now().Format("2006-01-02")))
	// w.Write(excelBytes)

	return &struct{}{}, nil
}

// Placeholder implementations for other handlers
func (h *MonitoringHandler) GetPasienDetail(ctx context.Context, input *GetPasienDetailInput) (*GetPasienDetailOutput, error) {
	// Similar pattern: extract JWT, call service, build response
	return &GetPasienDetailOutput{
		Body: model.NewSuccessResponse(200, "OK", "Detail pasien berhasil diambil.", model.PasienDetailResponse{}),
	}, nil
}

func (h *MonitoringHandler) SearchPasien(ctx context.Context, input *SearchPasienInput) (*SearchPasienOutput, error) {
	// Validate query parameter
	if input.Q == "" {
		return &SearchPasienOutput{
			Body: model.NewErrorResponse[model.PasienSearchResponse](422, "Unprocessable Content", "Parameter pencarian wajib diisi.", []model.ErrorItem{
				{Location: "query.q", Message: "Parameter pencarian wajib diisi.", Value: ""},
			}),
		}, nil
	}
	return &SearchPasienOutput{
		Body: model.NewSuccessResponse[model.PasienSearchResponse](200, "OK", "Pasien ditemukan melalui pencarian.", model.PasienSearchResponse{}),
	}, nil
}

func (h *MonitoringHandler) GetStatistik(ctx context.Context, input *struct{ Query model.StatistikRequest }) (*struct{ Body model.APIResponse[model.StatistikResponse] }, error) {
	return &struct{ Body model.APIResponse[model.StatistikResponse] }{
		Body: model.NewSuccessResponse(200, "OK", "Statistik berhasil diambil.", model.StatistikResponse{}),
	}, nil
}

func (h *MonitoringHandler) GetStatistikBulanan(ctx context.Context, input *struct{ Query model.StatistikBulananRequest }) (*struct{ Body model.APIResponse[model.StatistikBulananResponse] }, error) {
	return &struct{ Body model.APIResponse[model.StatistikBulananResponse] }{
		Body: model.NewSuccessResponse(200, "OK", "Statistik bulanan berhasil diambil.", model.StatistikBulananResponse{}),
	}, nil
}

func (h *MonitoringHandler) GetPemeriksaanDetail(ctx context.Context, input *struct{ ID int `path:"id"` }) (*struct{ Body model.APIResponse[model.DetailPemeriksaanResponse] }, error) {
	return &struct{ Body model.APIResponse[model.DetailPemeriksaanResponse] }{
		Body: model.NewSuccessResponse(200, "OK", "Data pemeriksaan berhasil diambil.", model.DetailPemeriksaanResponse{}),
	}, nil
}

func (h *MonitoringHandler) UpdatePemeriksaan(ctx context.Context, input *struct {
	ID   int `path:"id"`
	Body model.UpdatePemeriksaanBody
}) (*struct{ Body model.APIResponse[model.UpdatePemeriksaanResponse] }, error) {
	return &struct{ Body model.APIResponse[model.UpdatePemeriksaanResponse] }{
		Body: model.NewSuccessResponse(200, "OK", "Data pemeriksaan berhasil diperbarui.", model.UpdatePemeriksaanResponse{}),
	}, nil
}

func (h *MonitoringHandler) DeletePemeriksaan(ctx context.Context, input *struct{ ID int `path:"id"` }) (*struct{ Body model.APIResponse[any] }, error) {
	return &struct{ Body model.APIResponse[any] }{
		Body: model.NewSuccessResponse[any](200, "OK", "Data pemeriksaan berhasil dihapus. Data tindak lanjut yang terkait juga telah dihapus secara permanen.", nil),
	}, nil
}

func (h *MonitoringHandler) GetPemeriksaanPending(ctx context.Context, input *struct{ Query model.PemeriksaanPendingRequest }) (*struct{ Body model.APIResponse[model.PaginatedResponse[model.PemeriksaanPendingResponse]] }, error) {
	return &struct{ Body model.APIResponse[model.PaginatedResponse[model.PemeriksaanPendingResponse]] }{
		Body: model.NewSuccessResponse(200, "OK", "Data pemeriksaan yang membutuhkan verifikasi berhasil diambil.", model.PaginatedResponse[model.PemeriksaanPendingResponse]{}),
	}, nil
}

func (h *MonitoringHandler) GetJadwalImunisasiList(ctx context.Context, input *struct{ Query model.JadwalImunisasiListRequest }) (*struct{ Body model.APIResponse[model.PaginatedResponse[model.JadwalImunisasiListResponse]] }, error) {
	return &struct{ Body model.APIResponse[model.PaginatedResponse[model.JadwalImunisasiListResponse]] }{
		Body: model.NewSuccessResponse(200, "OK", "Data master jadwal imunisasi berhasil diambil.", model.PaginatedResponse[model.JadwalImunisasiListResponse]{}),
	}, nil
}

func (h *MonitoringHandler) CreateJadwalImunisasi(ctx context.Context, input *struct{ Body model.InputJadwalImunisasiBody }) (*struct{ Body model.APIResponse[model.CreateJadwalImunisasiResponse] }, error) {
	return &struct{ Body model.APIResponse[model.CreateJadwalImunisasiResponse] }{
		Body: model.NewSuccessResponse(201, "Created", "Jadwal imunisasi baru berhasil ditambahkan.", model.CreateJadwalImunisasiResponse{StatusImunisasi: "Belum"}),
	}, nil
}

func (h *MonitoringHandler) UpdateRealisasiImunisasi(ctx context.Context, input *struct {
	ID   int `path:"id"`
	Body model.RealisasiImunisasiBody
}) (*struct{ Body model.APIResponse[model.RealisasiImunisasiResponse] }, error) {
	return &struct{ Body model.APIResponse[model.RealisasiImunisasiResponse] }{
		Body: model.NewSuccessResponse(200, "OK", "Realisasi pelaksanaan imunisasi berhasil dicatat.", model.RealisasiImunisasiResponse{StatusImunisasi: "Sudah"}),
	}, nil
}