package model

import "time"

// ============= REQUEST STRUCTS =============

// PasienListRequest untuk GET /api/v1/monitoring/pasien
type PasienListRequest struct {
	Page         int    `query:"page" default:"1" minimum:"1"`
	PerPage      int    `query:"per_page" default:"15" minimum:"1" maximum:"100"`
	Q            string `query:"q"`
	StatusGizi   string `query:"status_gizi" enum:"Gizi Baik,Gizi Kurang,Gizi Buruk,Risiko Gizi Lebih,Gizi Lebih,Obesitas"`
	IDPosyandu   *int   `query:"id_posyandu"`
}

// InputPemeriksaanBody untuk POST /api/v1/monitoring/pemeriksaan
type InputPemeriksaanBody struct {
	IDJadwalImunisasi       int     `json:"id_jadwal_imunisasi" minimum:"1" required:"true"`
	BeratBadan              float64 `json:"berat_badan" minimum:"1" maximum:"30" required:"true"`
	TinggiBadan             float64 `json:"tinggi_badan" minimum:"40" maximum:"120" required:"true"`
	LingkarKepala           float64 `json:"lingkar_kepala" minimum:"20" maximum:"60" required:"true"`
	TekananDarah            string  `json:"tekanan_darah" maxLength:"20" required:"true"`
	CatatanObservasi        *string `json:"catatan_observasi" maxLength:"1000"`
	RekomendasiGizi         *string `json:"rekomendasi_gizi" maxLength:"1000"`
	CatatanMedis            *string `json:"catatan_medis" maxLength:"1000"`
	JadwalKontrolBerikutnya *string `json:"jadwal_kontrol_berikutnya" format:"date"`
	StatusPasien            *string `json:"status_pasien" enum:"Dalam Pemantauan,Membaik,Perlu Rujukan,Selesai Pemantauan" default:"Dalam Pemantauan"`
}

// UpdatePemeriksaanBody untuk PUT /api/v1/monitoring/pemeriksaan/{id}
type UpdatePemeriksaanBody struct {
	BeratBadan              *float64 `json:"berat_badan" minimum:"1" maximum:"30"`
	TinggiBadan             *float64 `json:"tinggi_badan" minimum:"40" maximum:"120"`
	LingkarKepala           *float64 `json:"lingkar_kepala" minimum:"20" maximum:"60"`
	TekananDarah            *string  `json:"tekanan_darah" maxLength:"20"`
	CatatanObservasi        *string  `json:"catatan_observasi" maxLength:"1000"`
	RekomendasiGizi         *string  `json:"rekomendasi_gizi" maxLength:"1000"`
	CatatanMedis            *string  `json:"catatan_medis" maxLength:"1000"`
	JadwalKontrolBerikutnya *string  `json:"jadwal_kontrol_berikutnya" format:"date"`
}

// VerifikasiPemeriksaanBody untuk PATCH /api/v1/monitoring/pemeriksaan/{id}/verify
type VerifikasiPemeriksaanBody struct {
	Aksi               string  `json:"aksi" enum:"setujui,tolak" required:"true"`
	CatatanVerifikasi  *string `json:"catatan_verifikasi" maxLength:"1000"`
}

// InputJadwalImunisasiBody untuk POST /api/v1/imunisasi
type InputJadwalImunisasiBody struct {
	IDPasien      int    `json:"id_pasien" minimum:"1" required:"true"`
	NamaVaksin    string `json:"nama_vaksin" maxLength:"255" required:"true"`
	TanggalJadwal string `json:"tanggal_jadwal" format:"date" required:"true"`
}

// RealisasiImunisasiBody untuk PATCH /api/v1/imunisasi/{id}/realisasi
type RealisasiImunisasiBody struct {
	TanggalRealisasi string `json:"tanggal_realisasi" format:"date" required:"true"`
}

// StatistikRequest untuk GET /api/v1/monitoring/statistik
type StatistikRequest struct {
	IDPosyandu *int `query:"id_posyandu"`
	Bulan      *int `query:"bulan" minimum:"1" maximum:"12"`
	Tahun      *int `query:"tahun" minimum:"2000" maximum:"2100"`
}

// StatistikBulananRequest untuk GET /api/v1/monitoring/statistik-bulanan
type StatistikBulananRequest struct {
	Tahun      *int `query:"tahun" minimum:"2000" maximum:"2100"`
	IDPosyandu *int `query:"id_posyandu"`
}

// ExportRequest untuk GET /api/v1/monitoring/pasien/export
type ExportRequest struct {
	StatusGizi   *string `query:"status_gizi" enum:"Gizi Baik,Gizi Kurang,Gizi Buruk,Risiko Gizi Lebih,Gizi Lebih,Obesitas"`
	IDPosyandu   *int    `query:"id_posyandu"`
	Bulan        *int    `query:"bulan" minimum:"1" maximum:"12"`
	Tahun        *int    `query:"tahun" minimum:"2000" maximum:"2100"`
}

// PemeriksaanPendingRequest untuk GET /api/v1/monitoring/pemeriksaan/pending
type PemeriksaanPendingRequest struct {
	Page    int `query:"page" default:"1" minimum:"1"`
	PerPage int `query:"per_page" default:"15" minimum:"1" maximum:"100"`
}

// JadwalImunisasiListRequest untuk GET /api/v1/imunisasi
type JadwalImunisasiListRequest struct {
	Page      int  `query:"page" default:"1" minimum:"1"`
	PerPage   int  `query:"per_page" default:"15" minimum:"1" maximum:"100"`
	IDPasien  *int `query:"id_pasien"`
}

// ============= RESPONSE STRUCTS =============

// PasienItem untuk response list pasien
type PasienItem struct {
	IDPasien                int     `json:"id_pasien"`
	NamaPasien              string  `json:"nama_pasien"`
	NIK                     string  `json:"nik"`
	Usia                    string  `json:"usia"`
	JenisPasien             string  `json:"jenis_pasien"`
	NamaPosyandu            string  `json:"nama_posyandu"`
	BeratBadanTerakhir      *float64 `json:"berat_badan_terakhir,omitempty"`
	TinggiBadanTerakhir     *float64 `json:"tinggi_badan_terakhir,omitempty"`
	StatusGiziTerakhir      *string  `json:"status_gizi_terakhir,omitempty"`
	StatusVerifikasiTerakhir *bool   `json:"status_verifikasi_terakhir,omitempty"`
}

// PasienListResponse untuk GET /api/v1/monitoring/pasien
type PasienListResponse struct {
	Pasien []PasienItem `json:"pasien"`
}

// PasienDetailResponse untuk GET /api/v1/monitoring/pasien/{id}
type PasienDetailResponse struct {
	IDPasien              int                    `json:"id_pasien"`
	NamaPasien            string                 `json:"nama_pasien"`
	NIK                   string                 `json:"nik"`
	TanggalLahir          string                 `json:"tanggal_lahir"`
	Usia                  string                 `json:"usia"`
	JenisPasien           string                 `json:"jenis_pasien"`
	NamaPosyandu          string                 `json:"nama_posyandu"`
	RiwayatPemeriksaan    []RiwayatPemeriksaanItem `json:"riwayat_pemeriksaan"`
}

// RiwayatPemeriksaanItem untuk nested riwayat pemeriksaan
type RiwayatPemeriksaanItem struct {
	IDHasilPemeriksaan int     `json:"id_hasil_pemeriksaan"`
	Tanggal            string  `json:"tanggal"`
	BeratBadan         float64 `json:"berat_badan"`
	TinggiBadan        float64 `json:"tinggi_badan"`
	StatusGizi         string  `json:"status_gizi"`
	StatusStunting     string  `json:"status_stunting"`
	StatusVerifikasi   bool    `json:"status_verifikasi"`
}

// PasienSearchResponse untuk GET /api/v1/monitoring/pasien/search
type PasienSearchResponse struct {
	IDPasien     int    `json:"id_pasien"`
	NIK          string `json:"nik"`
	Nama         string `json:"nama"`
	TanggalLahir string `json:"tanggal_lahir"`
	NamaPosyandu string `json:"nama_posyandu"`
}

// StatistikResponse untuk GET /api/v1/monitoring/statistik
type StatistikResponse struct {
	TotalStuntingTerdeteksi int `json:"total_stunting_terdeteksi"`
	TotalRisikoGiziLebih    int `json:"total_risiko_gizi_lebih"`
	TotalGiziBaik           int `json:"total_gizi_baik"`
	TotalGiziKurang         int `json:"total_gizi_kurang"`
	TotalGiziBuruk          int `json:"total_gizi_buruk"`
	TotalPasien             int `json:"total_pasien"`
}

// TrenBulananItem untuk nested tren bulanan
type TrenBulananItem struct {
	Bulan            int `json:"bulan"`
	NamaBulan        string `json:"nama_bulan"`
	TotalStunting    int `json:"total_stunting"`
	TotalGiziBuruk   int `json:"total_gizi_buruk"`
	TotalGiziBaik    int `json:"total_gizi_baik"`
	TotalPemeriksaan int `json:"total_pemeriksaan"`
}

// StatistikBulananResponse untuk GET /api/v1/monitoring/statistik-bulanan
type StatistikBulananResponse struct {
	Tahun        int               `json:"tahun"`
	Ringkasan    RingkasanTahunan  `json:"ringkasan"`
	TrenBulanan  []TrenBulananItem `json:"tren_bulanan"`
}

// RingkasanTahunan untuk nested ringkasan
type RingkasanTahunan struct {
	TotalIbu        int `json:"total_ibu"`
	TotalStunting   int `json:"total_stunting"`
	TotalGiziBuruk  int `json:"total_gizi_buruk"`
	TotalData       int `json:"total_data"`
}

// HasilPemeriksaanResponse untuk POST /api/v1/monitoring/pemeriksaan
type HasilPemeriksaanResponse struct {
	IDHasilPemeriksaan int       `json:"id_hasil_pemeriksaan"`
	StatusStunting     string    `json:"status_stunting"`
	StatusGizi         string    `json:"status_gizi"`
	StatusPasien       string    `json:"status_pasien"`
	CreatedAt          time.Time `json:"created_at"`
}

// AntrometriData untuk nested antropometri
type AntrometriData struct {
	BeratBadan    float64 `json:"berat_badan"`
	TinggiBadan   float64 `json:"tinggi_badan"`
	LingkarKepala float64 `json:"lingkar_kepala"`
	TekananDarah  string  `json:"tekanan_darah"`
}

// StatusKesehatanData untuk nested status kesehatan
type StatusKesehatanData struct {
	StatusGizi     string `json:"status_gizi"`
	StatusStunting string `json:"status_stunting"`
	StatusPasien   string `json:"status_pasien"`
}

// PasienData untuk nested pasien
type PasienData struct {
	IDPasien   int    `json:"id_pasien"`
	Nama       string `json:"nama"`
}

// DetailPemeriksaanResponse untuk GET /api/v1/monitoring/pemeriksaan/{id}
type DetailPemeriksaanResponse struct {
	IDHasilPemeriksaan      int                  `json:"id_hasil_pemeriksaan"`
	Pasien                  PasienData           `json:"pasien"`
	Antropometri            AntrometriData       `json:"antropometri"`
	StatusKesehatan         StatusKesehatanData  `json:"status_kesehatan"`
	CatatanObservasi        *string              `json:"catatan_observasi,omitempty"`
	RekomendasiGizi         *string              `json:"rekomendasi_gizi,omitempty"`
	CatatanMedis            *string              `json:"catatan_medis,omitempty"`
	JadwalKontrolBerikutnya *string              `json:"jadwal_kontrol_berikutnya,omitempty"`
	StatusVerifikasi        bool                 `json:"status_verifikasi"`
	CatatanVerifikasi       *string              `json:"catatan_verifikasi,omitempty"`
}

// UpdatePemeriksaanResponse untuk PUT /api/v1/monitoring/pemeriksaan/{id}
type UpdatePemeriksaanResponse struct {
	IDHasilPemeriksaan int       `json:"id_hasil_pemeriksaan"`
	StatusGiziBaru     string    `json:"status_gizi_baru"`
	UpdatedAt          time.Time `json:"updated_at"`
}

// VerifikasiPemeriksaanResponse untuk PATCH verify
type VerifikasiPemeriksaanResponse struct {
	IDHasilPemeriksaan int     `json:"id_hasil_pemeriksaan"`
	DiverifikasiOleh   int     `json:"diverifikasi_oleh"`
	StatusVerifikasi   string  `json:"status_verifikasi"`
	CatatanVerifikasi  *string `json:"catatan_verifikasi,omitempty"`
}

// PemeriksaanPendingItem untuk list pending
type PemeriksaanPendingItem struct {
	IDHasilPemeriksaan int    `json:"id_hasil_pemeriksaan"`
	NamaPasien         string `json:"nama_pasien"`
	DiinputOleh        string `json:"diinput_oleh"`
	TanggalInput       string `json:"tanggal_input"`
	StatusGizi         string `json:"status_gizi"`
	StatusStunting     string `json:"status_stunting"`
}

// PemeriksaanPendingResponse untuk GET pending
type PemeriksaanPendingResponse struct {
	PemeriksaanPending []PemeriksaanPendingItem `json:"pemeriksaan_pending"`
}

// JadwalImunisasiItem untuk list jadwal
type JadwalImunisasiItem struct {
	IDImunisasi       int     `json:"id_imunisasi"`
	NamaPasien        string  `json:"nama_pasien"`
	NamaVaksin        string  `json:"nama_vaksin"`
	TanggalJadwal     string  `json:"tanggal_jadwal"`
	StatusImunisasi   string  `json:"status_imunisasi"`
}

// JadwalImunisasiListResponse untuk GET /api/v1/imunisasi
type JadwalImunisasiListResponse struct {
	Jadwal []JadwalImunisasiItem `json:"jadwal"`
}

// CreateJadwalImunisasiResponse untuk POST /api/v1/imunisasi
type CreateJadwalImunisasiResponse struct {
	IDImunisasi     int    `json:"id_imunisasi"`
	NamaVaksin      string `json:"nama_vaksin"`
	TanggalJadwal   string `json:"tanggal_jadwal"`
	StatusImunisasi string `json:"status_imunisasi"`
}

// RealisasiImunisasiResponse untuk PATCH realisasi
type RealisasiImunisasiResponse struct {
	IDImunisasi       int    `json:"id_imunisasi"`
	StatusImunisasi   string `json:"status_imunisasi"`
	TanggalRealisasi  string `json:"tanggal_realisasi"`
}

// ExportRow untuk data export Excel
type ExportRow struct {
	No               int
	NamaPasien       string
	NIK              string
	TanggalPemeriksaan string
	BeratBadan       float64
	TinggiBadan      float64
	StatusGizi       string
	StatusStunting   string
	StatusVerifikasi string
	NamaPetugas      string
}
