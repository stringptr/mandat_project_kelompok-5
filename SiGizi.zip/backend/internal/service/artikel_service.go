package service

import (
	"context"
	"fmt"

	"myproject/internal/infrastructure/jet/imunisasi/public/model"
	"myproject/internal/repository"
)

// ArtikelService interface business logic artikel
type ArtikelService interface {
	// GetArtikelList mendapatkan list artikel publik
	GetArtikelList(ctx context.Context, page, perPage int, kategori, search string) ([]repository.ArtikelView, int, error)
	
	// GetArtikelByID mendapatkan detail artikel
	GetArtikelByID(ctx context.Context, id int) (*repository.ArtikelDetailView, error)
	
	// CreateArtikel membuat artikel baru (Bidan only)
	CreateArtikel(ctx context.Context, idPenulis int, judul, isiArtikel string, kategori *string) (int, error)
	
	// UpdateArtikel update artikel Draft (Bidan only, own article)
	UpdateArtikel(ctx context.Context, id, idPenulis int, judul, isiArtikel, kategori *string) error
	
	// DeleteArtikel hapus artikel (Dinkes only)
	DeleteArtikel(ctx context.Context, id int) error
	
	// ReviewArtikel approve/reject artikel (Dinkes only)
	ReviewArtikel(ctx context.Context, idArtikel, idVerifikator int, aksi, catatanReview string) error
	
	// GetArtikelPending mendapatkan artikel pending review (Dinkes only)
	GetArtikelPending(ctx context.Context, page, perPage int) ([]repository.ArtikelPendingView, int, error)
}

type artikelService struct {
	repo repository.ArtikelRepository
}

// NewArtikelService membuat instance service
func NewArtikelService(repo repository.ArtikelRepository) ArtikelService {
	return &artikelService{repo: repo}
}

// GetArtikelList implementasi
func (s *artikelService) GetArtikelList(ctx context.Context, page, perPage int, kategori, search string) ([]repository.ArtikelView, int, error) {
	// Validasi pagination (TSD 7.2)
	if page < 1 {
		page = 1
	}
	if perPage < 1 {
		perPage = 15 // Default
	}
	if perPage > 100 {
		perPage = 100 // Max
	}
	
	return s.repo.GetArtikelList(ctx, page, perPage, kategori, search)
}

// GetArtikelByID implementasi
func (s *artikelService) GetArtikelByID(ctx context.Context, id int) (*repository.ArtikelDetailView, error) {
	artikel, err := s.repo.GetArtikelByID(ctx, id)
	if err != nil {
		return nil, fmt.Errorf("ERR-SYS-01: %w", err)
	}
	
	if artikel == nil {
		return nil, fmt.Errorf("ERR-DATA-02: artikel tidak ditemukan")
	}
	
	return artikel, nil
}

// CreateArtikel implementasi dengan validasi BR-31, BR-32
func (s *artikelService) CreateArtikel(ctx context.Context, idPenulis int, judul, isiArtikel string, kategori *string) (int, error) {
	// Validasi input (BR-31)
	if judul == "" {
		return 0, fmt.Errorf("ERR-VAL-03: judul artikel wajib diisi")
	}
	if len(judul) > 255 {
		return 0, fmt.Errorf("ERR-VAL-03: judul maksimal 255 karakter")
	}
	if isiArtikel == "" {
		return 0, fmt.Errorf("ERR-VAL-03: isi artikel wajib diisi")
	}
	
	// Prepare model
	statusDraft := "Draft"
	artikel := &model.Artikel{
		Judul:         judul,
		IsiArtikel:    isiArtikel,
		Kategori:      kategori,
		StatusArtikel: &statusDraft, // Default status (TSD)
		IDPenulis:     int32(idPenulis),
	}
	
	id, err := s.repo.CreateArtikel(ctx, artikel)
	if err != nil {
		return 0, fmt.Errorf("ERR-SYS-01: gagal membuat artikel: %w", err)
	}
	
	return id, nil
}

// UpdateArtikel implementasi dengan validasi BR-31, BR-32
func (s *artikelService) UpdateArtikel(ctx context.Context, id, idPenulis int, judul, isiArtikel, kategori *string) error {
	// Validasi: artikel harus milik penulis & status Draft
	artikel, err := s.repo.GetArtikelForUpdate(ctx, id, idPenulis)
	if err != nil {
		return fmt.Errorf("ERR-SYS-01: %w", err)
	}
	
	if artikel == nil {
		return fmt.Errorf("ERR-DATA-02: artikel tidak ditemukan atau bukan milik Anda")
	}
	
	// Validasi status harus Draft (BR-32)
	if artikel.StatusArtikel == nil || *artikel.StatusArtikel != "Draft" {
		return fmt.Errorf("ERR-AUTH-03: hanya artikel dengan status Draft yang dapat diedit")
	}
	
	// Validasi input jika ada
	if judul != nil && *judul == "" {
		return fmt.Errorf("ERR-VAL-03: judul tidak boleh kosong")
	}
	if judul != nil && len(*judul) > 255 {
		return fmt.Errorf("ERR-VAL-03: judul maksimal 255 karakter")
	}
	if isiArtikel != nil && *isiArtikel == "" {
		return fmt.Errorf("ERR-VAL-03: isi artikel tidak boleh kosong")
	}
	
	err = s.repo.UpdateArtikel(ctx, id, judul, isiArtikel, kategori)
	if err != nil {
		return fmt.Errorf("ERR-SYS-01: gagal memperbarui artikel: %w", err)
	}
	
	return nil
}

// DeleteArtikel implementasi
func (s *artikelService) DeleteArtikel(ctx context.Context, id int) error {
	err := s.repo.DeleteArtikel(ctx, id)
	if err != nil {
		if err.Error() == "artikel not found" {
			return fmt.Errorf("ERR-DATA-02: artikel tidak ditemukan")
		}
		return fmt.Errorf("ERR-SYS-01: gagal menghapus artikel: %w", err)
	}
	
	return nil
}

// ReviewArtikel implementasi dengan validasi BR-33, BR-34, BR-35
func (s *artikelService) ReviewArtikel(ctx context.Context, idArtikel, idVerifikator int, aksi, catatanReview string) error {
	// Validasi aksi (BR-33)
	if aksi != "setujui" && aksi != "tolak" {
		return fmt.Errorf("ERR-VAL-03: aksi harus 'setujui' atau 'tolak'")
	}
	
	// Validasi: jika tolak, catatan wajib diisi (BR-34)
	if aksi == "tolak" && catatanReview == "" {
		return fmt.Errorf("ERR-VAL-03: catatan review wajib diisi jika artikel ditolak")
	}
	
	// Panggil SP
	result, err := s.repo.ReviewArtikel(ctx, idArtikel, idVerifikator, aksi, catatanReview)
	if err != nil {
		return fmt.Errorf("ERR-SYS-01: gagal melakukan review: %w", err)
	}
	
	// Handle result dari SP
	switch result {
	case "ARTIKEL_NOT_FOUND":
		return fmt.Errorf("ERR-DATA-02: artikel tidak ditemukan")
	case "INVALID_STATUS":
		return fmt.Errorf("ERR-DATA-02: artikel tidak dalam status Menunggu Review")
	case "SUCCESS":
		return nil
	default:
		return fmt.Errorf("ERR-SYS-01: hasil review tidak dikenali: %s", result)
	}
}

// GetArtikelPending implementasi
func (s *artikelService) GetArtikelPending(ctx context.Context, page, perPage int) ([]repository.ArtikelPendingView, int, error) {
	// Validasi pagination (TSD 7.2)
	if page < 1 {
		page = 1
	}
	if perPage < 1 {
		perPage = 15 // Default
	}
	if perPage > 100 {
		perPage = 100 // Max
	}
	
	return s.repo.GetArtikelPending(ctx, page, perPage)
}
